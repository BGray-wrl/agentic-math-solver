# Scaling Bucket — Report

**1080 trial rows** = (model, problem, n) cells across 3 source experiments,
with bootstrap-resampled pass@n.

## Coverage

- **Source experiments:** scaling: 240, scaling_reasoning: 560, scaling_v4flash: 280
- **Reasoning distribution:** default: 520, max: 560

## Headline scaling curves (v4-flash judge)

Mean across-problems of `pass_at_n_mean_v4flash`. Each cell is exhaustively
enumerated over C(M, n) subsets of the available branches.

| source | model | reasoning | n=1 | n=3 | n=5 | n=7 |
|---|---|---|---:|---:|---:|---:|
| scaling | gemma-4-31b-it | default | 0.31 | 0.74 | 1.08 | 1.40 |
| scaling | gpt-oss-120b | default | 0.10 | 0.27 | 0.39 | 0.47 |
| scaling_reasoning | gemma-4-31b-it | max | 1.92 | 2.76 | 3.05 | 3.20 |
| scaling_reasoning | gpt-oss-120b | max | 1.68 | 2.49 | 2.83 | 3.08 |
| scaling_v4flash | deepseek-v4-flash | default | 2.81 | 3.78 | 4.18 | 4.54 |


## Methodology note

The original scaling experiments stored branches sorted by k=0..6 and computed
pass@n as `max(scores[:n])` — a deterministic prefix. We replace this with
**exhaustive enumeration of all C(M, n) size-n subsets** per (model, problem):

| M (branches) | n=1 | n=3 | n=5 | n=7 |
|---:|---:|---:|---:|---:|
| 7  | 7   | 35  | 21  | 1   |
| 9  | 9   | 84  | 126 | 36  |

Per-problem pass@n is the mean over all subsets of `max(score over subset)`;
the population std is the right error bar. This is unbiased and avoids the
correlated-trajectory artifact of the nested estimator.

The `pass_at_n_pass_rate_v4flash` column reports the fraction of subsets
whose max-score ≥ 6, i.e. how often the trial would "pass" at this n.

## How to read the std columns

`std_pass_at_n_v4flash` in `summary.csv` is the std **across problems** of
each problem's subset-mean. It tells you between-problem variability of the
scaling estimate at this n. The within-problem subset std is in
`pass_at_n_std_v4flash` per row of `trials.csv`.
