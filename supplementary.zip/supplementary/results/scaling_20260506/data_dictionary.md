# Scaling Bucket — Data Dictionary

Best-of-N scaling curves with **bootstrap-resampled pass@n** instead of nested
prefix pass@n. Sources: scaling, scaling_reasoning, scaling_v4flash from
`results/dataset_20260505.jsonl`.

## Why bootstrap?

The master scaling experiments computed pass@n as `max(scores[:n])` — a
deterministic prefix of branches sorted by k. This makes pass@1 ⊂ pass@3 ⊂
pass@5 ⊂ pass@7, so per-problem trajectories are monotonic by construction and
understate the variance of the estimator. We replace this with **exhaustive
enumeration** of all C(M, n) size-n subsets per (model, problem) and report the
mean and standard deviation of `max(score over subset)`. This is unbiased and
the std is the right error bar.

For M=7 (scaling, scaling_v4flash), n=1/3/5/7 enumerates 7/35/21/1 subsets.
For M=9 (scaling_reasoning), n=1/3/5/7 enumerates 9/84/126/36 subsets.

## Files

- **`trials.jsonl`** — one row per (source_experiment, model, problem, n).
  Carries `branch_scores_v4flash` etc. so any bespoke n-enumeration is
  reproducible.
- **`trials.csv`** — flat tabular view.
- **`summary.csv`** — one row per (source_experiment, model_short, reasoning, n)
  aggregating across problems.

## `trials.csv` columns

| Column | Type | Meaning |
|---|---|---|
| `experiment` | str | Always `scaling`. |
| `source_experiment` | str | `scaling` / `scaling_reasoning` / `scaling_v4flash`. |
| `model_short`, `model_id` | str | Model. |
| `reasoning` | str | `default` for `scaling` and `scaling_v4flash`; `max` for `scaling_reasoning` (it ran with reasoning='high', the user's max-effort choice for those models). |
| `problem_id`, `level`, `difficulty`, `difficulty_label`, `is_26_research` | — | See architecture data dictionary. |
| `n` | int | Subset size for pass@n: one of 1, 3, 5, 7. |
| `branches_available` | int | Total branches generated for this (model, problem). 7 or 9. |
| `subsets_used` | int | C(branches_available, n). |
| `pass_at_n_mean_v4flash` | float or null | Mean of `max(branch v4flash score over subset)` across all C(M,n) subsets. **Canonical metric.** |
| `pass_at_n_std_v4flash` | float or null | Population std of the same. |
| `pass_at_n_pass_rate_v4flash` | float or null | Fraction of subsets whose max-score ≥ 6 (i.e., the "would the trial pass at this n" rate). |
| `pass_at_n_mean_v4pro`, `pass_at_n_std_v4pro` | float | Same for v4pro judge (only `scaling` source has v4pro inline; others null). |
| `pass_at_n_mean_gemini`, `pass_at_n_std_gemini` | float | Same for gemini judge (only `scaling` source has gemini inline; others null). |

## `summary.csv` columns

| Column | Meaning |
|---|---|
| `source_experiment`, `model_short`, `reasoning`, `n` | Group key. |
| `n_problems` | Number of problems in this group at this n. |
| `mean_pass_at_n_v4flash` | Mean across problems of `pass_at_n_mean_v4flash`. |
| `std_pass_at_n_v4flash` | Population std across problems (between-problem variability). |
| `pass_rate_v4flash` | Mean across problems of `pass_at_n_pass_rate_v4flash`. |
| `mean_score_imo` | Restricted to difficulty=1 problems. |
| `mean_score_research` | Restricted to difficulty ≥ 2 problems. |
| `research_solves` | Count of difficulty ≥ 2 problems with mean score ≥ 6 at this n. |

## Loading recipes

```python
import pandas as pd
df = pd.read_csv("results/scaling_20260506/trials.csv")
import seaborn as sns
sns.lineplot(data=df, x="n", y="pass_at_n_mean_v4flash",
             hue="model_short", style="reasoning")
```
