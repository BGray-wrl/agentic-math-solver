# Supplementary materials

This ZIP accompanies the paper *Comparing Inference-Time Methods for Natural-Language Mathematical Proofs* (NeurIPS 2026 Evaluations & Datasets track).

**Neither the dataset nor the code is the principal contribution of this paper.** The contribution is the empirical evaluation in §§4–6 of the main text. These materials are provided to support reproducibility and reviewer inspection.

## Layout

```
supplementary/
├── README.md                       # this file
├── REPRODUCIBILITY.md              # reproducibility statement
├── LICENSE                         # MIT (code) + CC-BY-4.0 (data)
├── src/                            # pipeline implementation
├── prompts/                        # prompts actually used in experiments
├── experiments/                    # experiment driver scripts (Python)
├── analysis/                       # statistics driver (analysis_v5.py)
├── results/                        # per-experiment summary CSVs + reports
└── r26_candidate_solutions/        # candidate solution text for R26 strict-judge passes
```

## Contents notes

- `src/` is the production pipeline (generator → verifier ↔ reviser → judge) plus utilities.
- `prompts/` includes only the prompt files referenced by `src/` and the experiment scripts. Third-party prompt collections (Aletheia, Huang–Yang, OAI, Epoch) used as starting points for our hardened versions are not redistributed here; they are cited in the paper.
- `experiments/` contains the per-experiment driver scripts. Each has its own date stamp and configuration block. They write outputs to `results/<experiment>/` when run.
- `results/` contains per-experiment `summary.csv`, `trials.csv`, `report.md`, and `data_dictionary.md`. Full per-trial JSONLs (with full solution text, verifier transcripts, revisor exchanges, and raw API logs) are omitted here only because of the 100 MB ZIP cap; CSVs preserve every field used in the §§5–6 analyses. The complete archive will be released publicly upon acceptance.
- `r26_candidate_solutions/` contains the candidate solution text (and only the candidate solution text — no judge transcripts, ground truth, problem statements, or verifier/revisor traces) for every R26 trial whose final solution scored ≥6 under the v4-flash strict judge. 28 trials across 5 problems (FirstProof-10, Erdős-654, Erdős-333, Erdős-397, FirstProof-5). The four additional pass@7 strict candidates referenced in §5.5 of the paper (Erdős-1051, Erdős-659, FirstProof-6) are documented in `results/scaling_20260506/trials.csv` but their full branch text lives in the per-branch generation archive that will be released alongside the camera-ready.

## Benchmarks (problem corpus)

Most of the benchmark problems used in this work come from the third-party corpus collected and curated by Google DeepMind:

> https://github.com/google-deepmind/superhuman

The 60 IMO-ProofBench problems (Luong et al., 2025) and the 10 R26 research-tier extensions (Erdős 333, 397, 654, 659, 1051; FirstProof 4, 5, 6, 10; Epoch FrontierMath Ramsey-hypergraph) are not redistributed in this ZIP. The per-trial CSVs reference them by `problem_id`. See the paper §3.2 and Table 1 for the full mapping; the `superhuman` repository above is the canonical source for the bulk of the corpus.

## Anonymization

This archive has been scrubbed of author paths, names, emails, and account handles. If anything was missed, please flag and we will correct in the camera-ready release.
