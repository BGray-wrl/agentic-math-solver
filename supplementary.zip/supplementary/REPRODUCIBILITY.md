# Reproducibility statement

All code (pipeline, experiment scripts, prompt files, analysis scripts), per-experiment summary and trial CSVs, judge calibration data, and the R26 problem index with difficulty annotations are included anonymized in this supplementary archive.

Full per-trial generation traces (full solution text, verifier/revisor exchanges) and raw API logs are omitted from this ZIP only because of the 100 MB cap; the per-experiment CSVs preserve every field used in the §§5–6 analyses, and the candidate solution text for every R26 trial that scored ≥6 under the v4-flash strict judge is included under `r26_candidate_solutions/`.

**Upon acceptance, the complete code and data — including full per-trial JSONLs, raw API logs, and per-branch generation text — will be released publicly under an open license alongside the camera-ready version.**

Neither the dataset nor the code is the principal contribution of this paper; the contribution is the empirical evaluation in §§4–6.

## Inference

All model calls were issued through OpenRouter (https://openrouter.ai). The pipeline uses `litellm` with OpenRouter as the upstream provider. To reproduce: install dependencies with `uv pip install matplotlib requests python-dotenv litellm`, set `OPENROUTER_API_KEY` in a local `.env`, and run `uv run src/pipeline.py <problem-file>`. Full instructions are in the included `src/` files and per-experiment script headers.

## Statistics

The statistical methodology is implemented in `analysis/analysis_v5.py`. CIs are 5,000-resample percentile bootstrap (problem-clustered for headline contrasts; trial-level alongside in the appendix). p-values are 10,000-permutation sign-flip tests. The numpy random seed used for the headline numbers is `20260507`.

## Datasets used

The 60 IMO-ProofBench problems are reused unmodified from DeepMind's release (Luong et al., 2025). The 10 R26 research-tier problems are drawn from the Erdős repository, the FirstProof open challenge, and Epoch's FrontierMath open-problem set; we provide difficulty annotations only. The bulk of the benchmark corpus is hosted at:

https://github.com/google-deepmind/superhuman
