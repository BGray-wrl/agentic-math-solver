# Candidate solution: Erdos_654 | deepseek-v4-flash | seed_full | reasoning=default

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved (counterexample) – the answer to the problem is **No**.  
**Method sketch:** Construct points on the coordinate axes using radii from two disjoint multiplicative sets (e.g. powers of 2 on the \(x\)-axis and powers of 3 on the \(y\)-axis) together with the origin. The condition for concyclicity reduces to an equality of products that never occurs, so no four points are concyclic. For every point the number of distinct distances to the other points is at most \(3m = \frac34 n + O(1)\) (where \(n=4m+1\)), which is not \((1-o(1))n\).  
**Changes from previous attempt:** The earlier distance analysis made an incorrect claim that sums and differences on the same axis are always distinct, and it omitted the origin from the count. The corrected argument uses a simple upper bound (at most \(2m\) distances on the same axis, at most \(m\) on the perpendicular axis) which is sufficient and avoids the flaw.

---

## Detailed Solution

We show that the statement is **false**. For infinitely many \(n\) we exhibit a set \(S\) of \(n\) points in the plane with no four concyclic such that every point has at most \(\frac34 n + O(1)\) distinct distances to the other points. Since \(\frac34<1\), this contradicts the claim that some point must have at least \((1-o(1))n\) distinct distances.

### 1. Construction

Let \(m\) be a positive integer and set \(n = 4m+1\).  
Define two sequences of positive numbers

\[
a_1,a_2,\dots ,a_m \quad\text{and}\quad b_1,b_2,\dots ,b_m
\]

that satisfy:

* all numbers are distinct;
* the two families are disjoint (no \(a_i\) equals any \(b_j\));
* for any indices \(i,j,k,l\) the equation \(a_i a_j = b_k b_l\) does **not** hold.

A concrete choice is  

\[
a_i = 2^{\,i},\qquad b_i = 3^{\,i}\qquad (i=1,\dots ,m).
\]

Indeed, \(2^{i+j}=3^{k+l}\) would imply that a power of 2 equals a power of 3, which is impossible for positive exponents.

Now define the following points in the plane:

* \(O = (0,0)\);
* for each \(i = 1,\dots ,m\):
  \[
  A_i = (a_i,0),\quad
  B_i = (0,b_i),\quad
  C_i = (-a_i,0),\quad
  D_i = (0,-b_i).
  \]

The set  

\[
S = \{\,O\,\}\cup\{\,A_i,B_i,C_i,D_i : 1\le i\le m\,\}
\]

contains exactly \(1+4m = n\) points.

### 2. No four points are concyclic

Any quadruple that contains three collinear points cannot be concyclic (a circle and a line intersect in at most two points). The only points of \(S\) that lie on a line are those on the same coordinate axis. Therefore we only need to examine quadruples that contain **at most two** points from one axis. The non‑trivial cases are those with exactly two points from the \(x\)-axis and two from the \(y\)-axis (including the possibility that each point comes from a different ray).

Let the points be  

\[
P_1 = (x_1,0),\quad P_2 = (x_2,0),\quad Q_1 = (0,y_1),\quad Q_2 = (0,y_2),
\]

where \(x_1,x_2\in\{\pm a_i\}\) and \(y_1,y_2\in\{\pm b_i\}\). The perpendicular bisector of \(P_1\) and \(P_2\) is the vertical line \(x = (x_1+x_2)/2\); that of \(Q_1\) and \(Q_2\) is the horizontal line \(y = (y_1+y_2)/2\). Hence any circle passing through the four points must have centre at \(((x_1+x_2)/2,\,(y_1+y_2)/2)\). Equating radii gives the condition

\[
x_1x_2 = y_1y_2.
\]

(This is obtained by squaring and simplifying; it holds for all real \(x_1,x_2,y_1,y_2\).)

Now consider the possible sign patterns for the products. Because the numbers \(a_i,b_i\) are positive:

* If both products are positive (i.e. the two \(x\)‑coordinates have the same sign and the two \(y\)‑coordinates have the same sign), the condition becomes \(a_i a_j = b_k b_l\).
* If both products are negative (i.e. the two \(x\)‑coordinates have opposite signs and the two \(y\)‑coordinates have opposite signs), the condition becomes \((-a_i)(a_j)=(-b_k)(b_l)\) or \((-a_i)(-a_j)=(-b_k)(-b_l)\), which again reduces to \(a_i a_j = b_k b_l\).
* If the products have opposite signs, the condition would be \(a_i a_j = -b_k b_l\), impossible for positive numbers.

Thus the only potential concyclicity among such quadruples is when \(a_i a_j = b_k b_l\). With the choice \(a_i=2^i,\;b_j=3^j\) this equation never occurs (the only solution in non‑negative integers would be \(i=j=k=l=0\), but our indices start at \(1\)). Hence no quadruple of this type is concyclic.

Quadruples that contain the origin \(O\) always contain three collinear points (e.g. \(O,A_i,A_j\) lie on the \(x\)-axis; \(O,B_i,B_j\) lie on the \(y\)-axis; or \(O\) together with one point from an axis and two from the other axis still gives three collinear points because the two points from the same axis together with \(O\) are collinear). Therefore they cannot be concyclic.

All other quadruples either contain three collinear points or are covered by the cases above. Consequently **no four points of \(S\) lie on a common circle**.

### 3. Number of distinct distances from each point

We bound the number of distinct distances from any point of \(S\). Recall that \(n=4m+1\).

**From the origin \(O\).**  
Distances to the points on the axes are exactly the radii:  

\[
|OA_i| = a_i,\quad |OC_i| = a_i,\quad |OB_i| = b_i,\quad |OD_i| = b_i.
\]  
All \(a_i\) and \(b_i\) are distinct, so the set of distinct distances from \(O\) has size \(2m = \frac{n-1}{2}\).

**From a point on the positive \(x\)-axis, e.g. \(A_k\) (\(1\le k\le m\)).**  
The points that lie on the \(x\)-axis are: \(O\), \(A_1,\dots,A_m\), \(C_1,\dots,C_m\). That is \(2m+1\) points. Distances from \(A_k\) to these points are:

* \(|A_k O| = a_k\);
* \(|A_k A_i| = |a_k-a_i|\) for \(i\neq k\);
* \(|A_k C_i| = a_k + a_i\) for all \(i\).

All these numbers are positive. The number of **distinct** values among them is certainly at most \(1 + (m-1) + m = 2m\). Hence from the \(x\)-axis points alone we obtain **at most** \(2m\) distinct distances.

The points on the \(y\)-axis are \(B_1,\dots,B_m\) and \(D_1,\dots,D_m\). For each \(i\), \(|A_k B_i| = |A_k D_i| = \sqrt{a_k^2 + b_i^2}\). Because the function \(t\mapsto\sqrt{a_k^2+t^2}\) is strictly increasing for \(t>0\), these \(m\) distances are all distinct. They could coincide with some of the \(x\)-axis distances, but that would only reduce the total count. Therefore the total number of distinct distances from \(A_k\) is at most  

\[
2m + m = 3m.
\]

Since \(n=4m+1\), we have \(3m = \frac34(n-1) = \frac34 n - \frac34\).

By symmetry the same bound holds for \(B_k\), \(C_k\) and \(D_k\) (the roles of the axes are interchangeable, and the origin is included in the count of the “own” axis points). Thus **every point of \(S\) has at most \(3m = \frac34 n + O(1)\) distinct distances to the other points**.

### 4. Conclusion

For infinitely many \(n\) (namely all \(n = 4m+1\) with \(m\ge 1\)) we have constructed a set of \(n\) points in the plane with **no four concyclic** and for which  

\[
\max_{x_i\in S} \bigl(\#\text{distinct distances from }x_i\bigr) \le \frac34 n + O(1).
\]

Because \(\frac34 n\) is not \((1-o(1))n\) (the ratio is bounded away from \(1\) as \(n\to\infty\)), it is **not true** that there must exist a point with at least \((1-o(1))n\) distinct distances. Hence the answer to the problem is **No**.