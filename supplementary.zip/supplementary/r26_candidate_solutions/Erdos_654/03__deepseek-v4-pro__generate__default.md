# Candidate solution: Erdos_654 | deepseek-v4-pro | generate | reasoning=default

v4-flash judge score: 7.0

---

**Summary**

**Verdict:** No  
**Method sketch:** We construct a family of \(n\)-point sets with no four points on a circle such that **every** point has at most \(\frac{3}{4}n+O(1)\) distinct distances to the others. Hence there is no point with \((1-o(1))n\) distinct distances.

---

## Detailed Solution

We show that the answer is **negative** by giving, for every large \(n\), a configuration of \(n\) points in \(\mathbb{R}^2\) with no four concyclic and with maximum number of distinct distances from a point equal to \(\frac{3}{4}n + O(1)\).

**Construction.**  
Let \(m \ge 1\) and \(k \ge 1\) be integers such that \(2m+2k = n\) (we can always round \(m,k\) suitably; the bounds will be asymptotically \(\frac{3}{4}n\)).  
Choose real numbers
\[
0 < u_1 < u_2 < \dots < u_m,\qquad
0 < v_1 < v_2 < \dots < v_k
\]
that are **algebraically independent** over \(\mathbb{Q}\).  
Define two families of points on the coordinate axes:
\[
A = \{(\pm u_i, 0) : 1 \le i \le m\}, \qquad
B = \{(0, \pm v_j) : 1 \le j \le k\}.
\]
The whole set is \(S = A \cup B\); it contains \(2m\) points on the \(x\)-axis and \(2k\) points on the \(y\)-axis, all distinct, with \(|S| = n\).

**1. No four points on a circle.**  
Because a circle can intersect a straight line in at most two points, any circle contains at most two points of \(A\) and at most two points of \(B\). Hence a concyclic quadruple must consist of exactly two points from \(A\) and two from \(B\).  
Take \((a_1,0), (a_2,0) \in A\) and \((0,b_1), (0,b_2) \in B\) with all four points distinct. The condition for them to lie on a common circle is \(a_1a_2 = b_1b_2\) (see e.g. power of a point or a short coordinate computation). In our set the \(x\)-coordinates are \(\pm u_i\) and the \(y\)-coordinates are \(\pm v_j\). Their products are \(\pm u_i u_{i'}\) and \(\pm v_j v_{j'}\). An equality of absolute values would give an algebraic relation among the \(u_i\) and \(v_j\) (e.g. \(u_i u_{i'} = v_j v_{j'}\)), which is impossible because the numbers are algebraically independent.  
All other quadruples contain at least three collinear points (three on an axis) and therefore cannot be concyclic. Hence no four points of \(S\) lie on a common circle.

**2. Distinct distances from a point.**  
Take any point \(P = (u_i, 0) \in A\) (the cases \((-u_i,0)\) and points of \(B\) are analogous).  
*Distances to other points of \(A\):* these are the numbers \(|u_i \pm u_{i'}|\) for \(i' \neq i\) (and the symmetric negatives give the same values). Because the \(u_i\) are algebraically independent, all these \(2m-1\) numbers are distinct; no difference equals a difference or a sum for distinct indices.  
*Distances to \(B\):* these are \(\sqrt{u_i^2 + v_j^2}\) for \(1 \le j \le k\). For a fixed \(i\) and varying \(j\) they are strictly increasing with \(v_j\), hence \(k\) distinct values. Moreover each value appears twice because \((0, v_j)\) and \((0, -v_j)\) give the same distance. Algebraic independence guarantees that none of these \(\sqrt{u_i^2 + v_j^2}\) coincides with any distance to another \(A\)-point.  
Thus the distinct distances from \(P\) are exactly the \(2m-1\) intra‑\(A\) distances plus the \(k\) intra‑\(B\) distances. Their number is
\[
D(P) = 2m-1 + k.
\]
By symmetry, a point \(Q \in B\) sees \(2k-1\) distinct distances inside \(B\) and \(m\) additional distances to \(A\), so
\[
D(Q) = 2k-1 + m.
\]

**3. Asymptotics.**  
We have \(n = 2m+2k\). Choosing \(m = k = \lfloor n/4 \rfloor\) (with possibly one left‑over point on each axis) yields
\[
\max_{X \in S} D(X) = \max(2m+k-1,\, 2k+m-1) = 3\lfloor n/4 \rfloor - 1 \sim \tfrac{3}{4}n.
\]
In particular, for every \(n \ge 4\) we can construct a set with no four concyclic in which **every** point has at most \(\frac{3}{4}n + 1\) distinct distances to the other points. This number is not of the form \((1-o(1))n\) as \(n \to \infty\) (it stays bounded away from \(n\) by a positive fraction).  

Hence the answer to the question is **No**: it is not true that there must exist a point with at least \((1-o(1))n\) distinct distances.