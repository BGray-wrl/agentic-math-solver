# Candidate solution: FirstProof_10 | gpt-oss-120b | generate | reasoning=max

v4-flash judge score: 7.0

---

**Summary**

**Verdict:** Solved – an efficient preconditioned conjugate‑gradient (PCG) method is described.  
**Method sketch:** Exploit the Kronecker structure of the normal equations together with the fact that the sampling operator $S S^{\!T}$ is diagonal and only $q$ entries are observed.  Matrix–vector products are performed by (i) multiplying $W$ from the left by the kernel matrix $K$, (ii) forming the predicted entries only on the observed positions using the rows of the Khatri‑Rao matrix $Z$, (iii) re‑projecting the residual back into a full $n\times r$ matrix and (iv) adding the ridge term.  A cheap Kronecker‑product preconditioner $(G+\lambda I_r)\otimes K$ (with $G=Z_{\Omega}^{\!T}Z_{\Omega}$) is inverted by a Cholesky factor of $K$ and a small $r\times r$ solve.  Each PCG iteration costs $O(qr+n^{2}r)$ (no $O(N)$ work) and only $O(qr+n^{2})$ memory.

---

## Detailed Solution

### 1.  Linear system for the infinite‑dimensional factor  

The mode‑$k$ sub‑problem (all other factor matrices are fixed) can be written as  

\[
\Bigl[(Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)+\lambda(I_r\!\otimes\!K)\Bigr]\,
\operatorname{vec}(W)= (I_r\!\otimes\!K)\operatorname{vec}(B),\tag{1}
\]

with  

* $K\in\mathbb R^{n\times n}$ – symmetric positive‑definite kernel matrix,  
* $Z\in\mathbb R^{M\times r}$ – Khatri‑Rao product of all factors except mode $k$,  
* $W\in\mathbb R^{n\times r}$ – unknown coefficient matrix, $A_k=KW$,  
* $B=T Z\in\mathbb R^{n\times r}$ – MTTKRP (mode‑$k$), and  
* $S\in\mathbb R^{N\times q}$ selects the $q$ observed entries
  ($S^{\!T}\operatorname{vec}(T)$ contains the observations, the remaining
  entries are zero).

The matrix in (1) is symmetric positive definite (SPD) because
\[
(Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)\succeq 0,
\qquad
\lambda(I_r\!\otimes\!K)\succ0 .
\]

Hence a conjugate‑gradient (CG) method is applicable.  Since the size of the
system is $nr\times nr$ (typically $n,r\ll q$) we seek an **iterative**
solver that never builds the $nr\times nr$ matrix explicitly.

---------------------------------------------------------------------

### 2.  Conjugate‑gradient with a preconditioner  

CG solves $A x = b$ with $A$ SPD by repeatedly forming products $A p$ for a
search direction $p$.  A preconditioner $M\approx A$ (SPD and easy to invert)
improves convergence: we actually solve the equivalent system  
\(M^{-1}A x = M^{-1}b\).  In each CG iteration we therefore need

* a matrix‑vector product $y=A v$,
* the action of $M^{-1}$ on a vector.

Both operations can be performed in $O(qr+n^{2}r)$ time, as detailed next.

---------------------------------------------------------------------

### 3.  Efficient matrix–vector product  

Let a vector $v\in\mathbb R^{nr}$ be reshaped as $V\in\mathbb R^{n\times r}$,
i.e. $v=\operatorname{vec}(V)$.  The left‑hand side of (1) applied to $v$ is

\[
\underbrace{(Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)\operatorname{vec}(V)}_{\displaystyle
\text{data term}} \;+\;
\lambda \underbrace{(I_r\!\otimes\!K)\operatorname{vec}(V)}_{\displaystyle =\operatorname{vec}(KV)} .\tag{2}
\]

We compute the two parts separately.

-----------------------------------------------------------------
#### 3.1  The ridge term  

Because $K$ is an $n\times n$ matrix,
\[
(I_r\!\otimes\!K)\operatorname{vec}(V)=\operatorname{vec}(K V).
\]
Thus the ridge contribution is simply $K V$, which costs $O(n^{2}r)$
(once $K$ is factored, applying $K$ or $K^{-1}$ costs $O(n^{2})$ per column).

-----------------------------------------------------------------
#### 3.2  The data term  

Define the set of observed indices

\[
\Omega=\{(i,\;j)\mid 1\le i\le n,\;1\le j\le M,\; (i,j)\text{ observed}\},
\qquad |\Omega| = q .
\]

For each $(i,j)\in\Omega$ denote by $K_{i,:}\in\mathbb R^{1\times n}$ the $i$‑th row of $K$
and by $z_{j}^{\top}\in\mathbb R^{1\times r}$ the $j$‑th row of $Z$.
A well‑known identity for Kronecker products gives

\[
(Z\!\otimes\!K)\operatorname{vec}(V)
   \;=\;\operatorname{vec}(K V Z^{\!\top})\;,
\tag{3}
\]
so that the vector $\mathbf{y}= (Z\!\otimes\!K)\operatorname{vec}(V)$ consists of the
entries 
\[
y_{(i,j)} = K_{i,:} V \; z_{j}^\top
          = \sum_{\ell=1}^{r}\bigl( K_{i,:} V_{:, \ell}\bigr)\,
                        \bigl(z_{j,\ell}\bigr).
\tag{4}
\]

Only the $q$ entries indexed by $\Omega$ are ever used because the
sampling operator $S S^{\!T}$ zeros out all the others.  Consequently we can
evaluate the product $S^{\!T}(Z\!\otimes\!K)\operatorname{vec}(V)$ by scanning the
observed indices and computing the scalar (4) for each of them:

```
for (i,j) in Ω:
    y_obs[e] = (K[i,:]·V)·z_j        # dot‑product of a length‑r vector
```

The cost of this loop is $O(qr)$: for each observed entry we form an inner
product of two length‑$r$ vectors.

Now we must apply the transpose $(Z\!\otimes\!K)^{\!T}$ to the
masked vector.  Using again (3) with the transpose and the symmetry $K^{\!T}=K$,

\[
(Z\!\otimes\!K)^{\!T}\operatorname{vec}(U)
    =\operatorname{vec}\!\bigl(K\;U\;Z\bigr),\qquad
U\in\mathbb R^{n\times M}.                                 \tag{5}
\]

Hence we need the matrix $U$ that contains the observed predictions only.
Let $U_{\Omega}\in\mathbb R^{q}$ be the vector of values $y_{(i,j)}$ computed
above, placed at the appropriate positions of a zero matrix $U\in\mathbb R^{n\times M}$.  
Forming $U$ can be done by a sparse “scatter’’ operation that costs $O(q)$.

The product $K U Z$ in (5) can be evaluated without materialising $U$:
\[
(KU Z)_{i,:}
      =\sum_{j:\,(i,j)\in\Omega} (K_{i,:}V\;z_{j}^{\!\top})\;z_{j}^{\!\top}
      =\sum_{j:\,(i,j)\in\Omega} \alpha_{ij}\;z_{j}^{\!\top},
\quad\text{with }\alpha_{ij}=K_{i,:}V\,z_{j}^{\!\top}.
\]

Thus we accumulate, for each observed entry, the scalar $\alpha_{ij}$ times the
row $z_{j}^{\!\top}$ into the $i$‑th row of an $n\times r$ accumulator.
Algorithmically:

```
M = zeros(n,r)                         # accumulator for K U Z
for (i,j) in Ω:
    alpha   = (K[i,:]·V)·z_j           # same scalar as before
    M[i,:] += alpha * z_j
```

Again the loop costs $O(q r)$ (the addition of a length‑$r$ vector per observation).

Finally we multiply the accumulator by $K$ from the left (the remaining $K$ from (5)):

\[
(KU Z) = K M  \qquad\Longrightarrow\qquad
\text{row }i\text{ of }K M = \sum_{i'} K_{i,i'} M_{i',:},
\]

which costs $O(n^{2}r)$.

Collecting the pieces, the whole data term
$(Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)\operatorname{vec}(V)$
is obtained as  

\[
\operatorname{vec}\!\bigl(KM\bigr),  \qquad M =\text{accumulator described above}.
\]

**Summary of the matrix–vector product** (for a given $V$)

| Step | Operation | Cost |
|------|-----------|------|
| 1 | $W' = K V$ | $O(n^{2}r)$ |
| 2 | For each $(i,j)\in\Omega$: compute $\alpha_{ij}=W'_{i,:}\,z_j$ | $O(qr)$ |
| 3 | Accumulate $M_{i,:}\mathrel{+=}\alpha_{ij}\,z_j$ | $O(qr)$ |
| 4 | $Y = K M$ | $O(n^{2}r)$ |
| 5 | Add ridge term $+\lambda K V$ | $O(n^{2}r)$ |
|**Total**| – | **$O(qr+n^{2}r)$** |

Crucially, **no operation touches the full $N=nM$ entries**; everything is driven by the $q$ observed triples and by dense $n\times n$ kernel matrix $K$.

---------------------------------------------------------------------

### 4.  Right‑hand side  

The right‑hand side in (1) is $(I_r\!\otimes\!K)\operatorname{vec}(B)$ with $B=T Z$.
Only the observed entries of $T$ are needed, so we compute  

\[
B = \sum_{(i,j)\in\Omega} T_{ij}\,e_i\,z_{j}^{\!\top}
\]

by a single pass over the data:

```
B = zeros(n,r)
for (i,j, t_ij) in Ω:
    B[i,:] += t_ij * z_j
```

Cost again $O(qr)$.  Afterwards $K B$ (the factor $K$ from $(I_r\!\otimes\!K)$) is obtained with $O(n^{2}r)$.

---------------------------------------------------------------------

### 5.  Choice of a preconditioner  

A good preconditioner should (i) approximate $A$,
(ii) be cheap to form and invert, and (iii) respect the Kronecker
structure so that the inverse can be applied without $O(N)$ work.

#### 5.1  Kronecker‑product preconditioner  

From (1) we write

\[
A = (Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K) + \lambda(I_r\!\otimes\!K)
   = \sum_{e\in\Omega} (k_{i_e}\!k_{i_e}^{\!\top})\otimes(z_{j_e}z_{j_e}^{\!\top})
     \;+\; \lambda I_r\!\otimes\!K .
\]

If we replace the sum of $q$ rank‑1 Kronecker terms by a *single* Kronecker term
that uses the empirical second‑moment matrix of the $Z$‑rows,
\[
G \;=\; Z_{\Omega}^{\!\top} Z_{\Omega}
   \;=\; \sum_{e\in\Omega} z_{j_e}z_{j_e}^{\!\top}
   \in\mathbb R^{r\times r},
\]
we obtain the **preconditioner**

\[
M \;=\; (G+\lambda I_r)\otimes K.
\tag{6}
\]

Both factors are small: $K\in\mathbb R^{n\times n}$ (dense but $n$ is modest),
$G+\lambda I_r\in\mathbb R^{r\times r}$ (tiny).  Moreover,
\[
M^{-1}= (G+\lambda I_r)^{-1}\otimes K^{-1},
\]
so applying $M^{-1}$ to a vector $v=\operatorname{vec}(V)$ reduces to

1. Solve $K X = V$ column‑wise (use the Cholesky factor of $K$ – $O(n^{2}r)$).
2. Solve $(G+\lambda I_r) Y = X^{\!\top}$ (r‑by‑r system, $O(r^{3})$, or even $O(r^{2})$ per column).

Both steps are **exact** (up to numerical round‑off) and cost $O(n^{2}r+r^{3})$ per CG
iteration; the $r^{3}$ term is negligible because $r\ll n$.

The matrix $G$ is formed once before the CG loop:
\[
G = Z_{\Omega}^{\!\top} Z_{\Omega} \quad\text{(cost } O(q\,r^{2})\text{)}.
\]
Since $q$ may be large but $r$ is tiny, this one‑off cost is acceptable.

#### 5.2  Simpler diagonal (Jacobi) preconditioner  

If an even cheaper preconditioner is desired, we may retain only the
diagonal of $A$:

\[
M_{\text{diag}}(i,\ell) = \bigl(\sum_{e\in\Omega\;:\;i_e=i}
          \|z_{j_e}\|_2^{2}\bigr)K_{ii} + \lambda K_{ii},
\qquad 1\le i\le n,\;1\le\ell\le r .
\]

Applying $M_{\text{diag}}^{-1}$ costs only $O(nr)$.  The diagonal
preconditioner is weaker but still often reduces the CG iteration count
substantially when the data are reasonably well‑scaled.

---------------------------------------------------------------------

### 6.  PCG algorithm for the mode‑$k$ subproblem  

```
Input:   K (n×n), factor matrices for all modes ≠k,
         observed triples Ω = {(i_e , j_e , t_e)}_{e=1}^q,
         rank r, regularisation λ.
Pre‑compute:
    – Cholesky factor L_K such that K = L_K L_K^T.
    – Z_Ω  (q×r)   : rows of Z belonging to the observed column indices.
    – G = Z_Ω^T Z_Ω (r×r).
    – M = (G+λ I_r) ⊗ K   (preconditioner)  and factorise
          (G+λ I_r) = L_G L_G^T.
    – RHS b = vec( K * B ),   B = Σ_{e∈Ω} t_e  e_{i_e} z_{j_e}^T .
Initial guess:  W_0 = 0  ⇒  x_0 = vec(W_0).
r_0 = b – A x_0      (use the matrix‑vector routine of §3)
z_0 = M^{-1} r_0     (solve K‑step with L_K, then r‑step with L_G)
p_0 = z_0

for k = 0,1,…,maxIter
    y_k = A p_k                (matrix‑vector product, §3)
    α_k = (r_k^T z_k) / (p_k^T y_k)
    x_{k+1} = x_k + α_k p_k
    r_{k+1} = r_k – α_k y_k
    if ‖r_{k+1}‖ small → stop
    z_{k+1} = M^{-1} r_{k+1}
    β_k = (r_{k+1}^T z_{k+1}) / (r_k^T z_k)
    p_{k+1} = z_{k+1} + β_k p_k
end
Return  W = reshape(x_{final}, n, r),   A_k = K W.
```

All operations inside the loop are $O(qr+n^{2}r)$ (product) plus $O(n^{2}r+r^{3})$ (preconditioner), with constant‑size vector inner‑products $O(nr)$.

---------------------------------------------------------------------

### 7.  Complexity analysis  

| Quantity | Cost per CG iteration | Remarks |
|----------|----------------------|---------|
| Matrix‑vector product $A p$ | $O(qr + n^{2}r)$ | No $O(N)$ work – only $q$ observed entries and dense kernel $K$ |
| Preconditioner solve $M^{-1} r$ | $O(n^{2}r + r^{3})$ (Kronecker) or $O(nr)$ (Jacobi) | $K$ is factored once, $G+\lambda I_r$ is tiny |
| Vector updates (dot‑products, axpy) | $O(nr)$ | negligible |
| Total per iteration | $O(qr + n^{2}r)$ (dominant term $qr$) | $n^{2}r \ll qr$ when $q\gg n$ |
| One‑off precomputations | $O(qr^{2})$ for $G$ and $O(qr)$ for $B$ | done before CG, cheap for modest $r$ |
| Memory | $O(qr + n^{2})$ | stores $Z_{\Omega}$, $K$, the Cholesky factors and a few $n\times r$ matrices |

If the PCG converges in $k_{\text{CG}}$ iterations (often $k_{\text{CG}}\le 30$ for the
Kronecker preconditioner), the total work is  

\[
O\!\bigl(k_{\text{CG}}\, (qr + n^{2}r)\bigr) \;+\; O(qr^{2}),
\]

which is vastly cheaper than the $O(n^{3}r^{3})$ cost of a dense direct solve and
does **not** involve any $O(N)$ operations.  In practice $qr$ dominates, so the
algorithm scales linearly in the number of observed entries.

---------------------------------------------------------------------

### 8.  Why the method works  

* **SPD system:**  The normal equations (1) are symmetric positive definite,
  guaranteeing convergence of CG.
* **Exact matrix‑vector product:**  By using the identity
  $(Z\!\otimes\!K)\operatorname{vec}(W)=\operatorname{vec}(K W Z^{\!\top})$
  and the fact that $SS^{\!T}$ merely extracts the observed entries,
  we can evaluate $A v$ without ever forming $A$ or the full tensor unfolding.
* **Preconditioner quality:**  The Kronecker preconditioner (6) captures the
  dominant structure – the kernel $K$ and the empirical gram matrix $G$ of the
  observed Khatri‑Rao rows.  Its inverse is available in closed form,
  so the preconditioned system has a spectrum clustered around $1$, and CG
  reaches the required accuracy in a modest number of iterations.
* **Complexity guarantees:**  All per‑iteration operations involve either
  $q$ scalar products of length $r$ or dense $n\times n$ multiplies;
  there is no dependence on the full tensor size $N=nM$.
  Hence the algorithm respects the stipulated $n,r<q\ll N$ regime.

---------------------------------------------------------------------

### 9.  Concluding remarks  

The described PCG scheme solves the infinite‑dimensional mode‑$k$ subproblem
of a CP decomposition with missing data and an RKHS‑constrained factor
without ever constructing the huge $nr\times nr$ normal matrix or the full
tensor unfolding.  By exploiting (i) the Kronecker product structure,
(ii) the sparsity induced by the selection matrix $S$, and (iii) a
Kronecker‑product preconditioner $(G+\lambda I_r)\otimes K$, each CG iteration
costs only $O(qr+n^{2}r)$ and the memory footprint remains $O(qr+n^{2})$.  
Consequently the overall effort is orders of magnitude smaller than the
$O(n^{3}r^{3})$ direct‑solve approach and is scalable to very large
un‐aligned tensors.  The same ideas apply verbatim to any mode with an
RKHS representation, and the preconditioner can be further refined (e.g.
using low‑rank approximations of $K$) if $n$ grows.  This completes the
efficient solution of the mode‑$k$ subproblem.