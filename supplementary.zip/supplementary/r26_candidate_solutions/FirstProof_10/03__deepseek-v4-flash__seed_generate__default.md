# Candidate solution: FirstProof_10 | deepseek-v4-flash | seed_generate | reasoning=default

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved  
**Method sketch:** Use the Kronecker structure and the selection matrix \(S\) to compute matrix-vector products with the system matrix in \(O(qr + n^2r)\) per CG iteration, avoiding any \(O(N)\) operations. Precondition with the expected full‑observation matrix \(P = \frac{q}{N}(Z^{\mathsf T}Z)\otimes K^2 + \lambda I_r\otimes K\), which becomes block diagonal (with \(r\times r\) blocks) in the eigenbasis of \(K\), enabling efficient inversion in \(O(n^2r + nr^2)\) per iteration after an \(O(n^3)\) precomputation.

## Detailed Solution

### 1. Problem restatement

We need to solve for \(\operatorname{vec}(W)\in\mathbb{R}^{nr}\) the linear system  
\[
\bigl[(Z\otimes K)^{\mathsf T}SS^{\mathsf T}(Z\otimes K) + \lambda(I_r\otimes K)\bigr]\operatorname{vec}(W) = (I_r\otimes K)\operatorname{vec}(B),
\]  
where  

* \(K\in\mathbb{R}^{n\times n}\) is a given symmetric positive semidefinite kernel matrix,  
* \(Z\in\mathbb{R}^{M\times r}\) is the Khatri‑Rao product of the factor matrices of the other modes, with \(M = \prod_{i\neq k}n_i\) possibly huge,  
* \(S\in\mathbb{R}^{N\times q}\) selects the \(q\) observed entries (\(N = nM\)), \(q \ll N\),  
* \(B = TZ\) is the MTTKRP matrix (\(n\times r\)),  

and \(n,r < q \ll N\). The system is symmetric positive definite (the first term is positive semidefinite, the second is positive definite because \(K\succ 0\) for a proper kernel). Therefore the conjugate gradient (CG) method is applicable.

We show how to implement a matrix‑vector product with the system matrix and how to choose an efficient preconditioner, both without forming any \(O(N)\) object.

### 2. Efficient matrix‑vector product

Let \(x = \operatorname{vec}(W)\in\mathbb{R}^{nr}\). The product  

\[
A x = (Z\otimes K)^{\mathsf T}SS^{\mathsf T}(Z\otimes K)x + \lambda(I_r\otimes K)x
\]

is computed in three stages.

#### Stage 1: Compute \(y = SS^{\mathsf T}(Z\otimes K)x\)

1. Compute \(KW\) (size \(n\times r\)). Since \(K\) is \(n\times n\) and \(W\) is \(n\times r\), this costs \(O(n^2 r)\).  
   *Remark:* We reshape \(x\) into an \(n\times r\) matrix \(W\) (column‑wise).

2. Using the identity \((Z\otimes K)\operatorname{vec}(W) = \operatorname{vec}(KWZ^{\mathsf T})\), the vector  
   \[
   y_{\text{full}} = (Z\otimes K)x \in \mathbb{R}^{nM}
   \]
   has entries \((KWZ^{\mathsf T})_{i,j}\) for \(i\in[n]\), \(j\in[M]\).  
   Because \(S\) selects only the \(q\) observed positions, we only need the \(q\) entries of \(y_{\text{full}}\) corresponding to the observed indices.

   Let \(\Omega\) be the set of observed pairs \((i,j)\) (mode‑\(k\) index and multi‑index of other modes). For each \((i,j)\in\Omega\),  
   \[
   (KWZ^{\mathsf T})_{i,j} = (KW)_{i,:}\cdot Z_{j,:},
   \]
   an \(r\)-dimensional dot product. Hence we compute \(y_{\text{obs}} = S^{\mathsf T}y_{\text{full}}\) by iterating over \(\Omega\) and accumulating the dot product. This costs \(O(qr)\).

3. The operator \(SS^{\mathsf T}\) simply places the computed values back into an \(n\times M\) matrix \(V\) with zeros elsewhere. However, we do **not** form the full \(V\); we keep the list of observed entries with their values.

#### Stage 2: Compute \((Z\otimes K)^{\mathsf T}(SS^{\mathsf T}y) = (Z\otimes K)^{\mathsf T}\operatorname{vec}(V)\)

Using the transpose identity \((Z\otimes K)^{\mathsf T}=Z^{\mathsf T}\otimes K\) (since \(K=K^{\mathsf T}\)),  
\[
(Z\otimes K)^{\mathsf T}\operatorname{vec}(V) = \operatorname{vec}(KVZ).
\]  
We need the product \(KVZ\) (\(n\times r\)).

1. Compute \(VZ\): For each observed pair \((i,j)\) with value \(v_{ij}\) (the corresponding entry of \(y_{\text{obs}}\)), we add \(v_{ij}Z_{j,:}\) to the \(i\)-th row of an \(n\times r\) accumulator. This costs \(O(qr)\).

2. Multiply the result by \(K\): \(K(VZ)\) costs \(O(n^2 r)\).

#### Stage 3: Add the regularisation term

\[
\lambda(I_r\otimes K)x = \lambda\operatorname{vec}(KW),
\]  
and \(KW\) has already been computed in Stage 1. Hence no extra cost.

**Total cost per CG iteration**: \(O(n^2 r + qr)\).

**Memory**: Only matrices of size \(n\times r\), \(n\times n\), and the list of observed entries (size \(q\)) are stored. No \(O(N)\) storage.

### 3. Preconditioner

A good preconditioner for \(A\) should approximate the matrix while being easy to invert. We choose the **expected full‑observation matrix**

\[
P = \frac{q}{N}(Z^{\mathsf T}Z)\otimes K^2 + \lambda I_r\otimes K.
\]

*Justification*: If all entries were observed (\(S=I_N\)), then  
\[
(Z\otimes K)^{\mathsf T}(Z\otimes K) = (Z^{\mathsf T}Z)\otimes (K^{\mathsf T}K) = (Z^{\mathsf T}Z)\otimes K^2.
\]  
With subsampling, the sampled Gram matrix has expectation \(\frac{q}{N}(Z^{\mathsf T}Z)\otimes K^2\) (assuming uniform random sampling). For large \(q\) this expectation is a natural surrogate. Moreover, the regularisation term is exact.

#### Inversion of \(P\)

Since \(K\) is symmetric positive semidefinite, we compute its eigenvalue decomposition once (cost \(O(n^3)\)):  
\[
K = U\Lambda U^{\mathsf T},\qquad \Lambda = \operatorname{diag}(\lambda_1,\dots,\lambda_n).
\]  
Then  

\[
\begin{aligned}
P &= \frac{q}{N}(Z^{\mathsf T}Z)\otimes (U\Lambda^2 U^{\mathsf T}) + \lambda I_r\otimes (U\Lambda U^{\mathsf T}) \\
  &= (I_r\otimes U)\Bigl[\frac{q}{N}(Z^{\mathsf T}Z)\otimes \Lambda^2 + \lambda I_r\otimes \Lambda\Bigr](I_r\otimes U^{\mathsf T}).
\end{aligned}
\]

The middle matrix is **block diagonal** when the rows are ordered by the eigenindex of \(K\): for each eigenvalue \(\lambda_j\) (\(j=1,\dots,n\)) we have an \(r\times r\) block  

\[
P_j = \frac{q}{N}\lambda_j^2 (Z^{\mathsf T}Z) + \lambda\lambda_j I_r.
\]

Thus, applying \(P^{-1}\) to a vector \(\operatorname{vec}(W)\) proceeds as:

1. Transform \(W\) to the eigenbasis: \(\widetilde W = U^{\mathsf T}W\) (cost \(O(n^2 r)\)).
2. For each \(j=1,\dots,n\), solve the \(r\times r\) system \(P_j (\widetilde W_{j,:})^{\mathsf T} = (\widetilde V_{j,:})^{\mathsf T}\) (where \(\widetilde V\) is the transformed right‑hand side). By precomputing the Cholesky factors (or inverses, since \(r\) is small) of each \(P_j\) once, each solve costs \(O(r^2)\). Total \(O(n r^2)\).
3. Transform back: \(W_{\text{new}} = U\widetilde W\) (cost \(O(n^2 r)\)).

**Preconditioner application cost**: \(O(n^2 r + n r^2)\) per iteration (after the \(O(n^3)\) eigendecomposition and \(O(n r^3)\) block factorisation, both performed once).

### 4. Complexity analysis

| Operation | Complexity | Remarks |
|-----------|------------|---------|
| Eigendecomposition of \(K\) | \(O(n^3)\) | One‑time cost |
| Factorisation of \(P_j\) | \(O(n r^3)\) | One‑time, \(n\) blocks of size \(r\) |
| Computing \(Z^{\mathsf T}Z\) | \(O\bigl(r^2\sum_{i\neq k} n_i\bigr)\) | Using Hadamard products of \(A_i^{\mathsf T}A_i\) |
| Matrix‑vector product with \(A\) | \(O(n^2 r + q r)\) | Per CG iteration |
| Preconditioner application | \(O(n^2 r + n r^2)\) | Per CG iteration |

Since \(n, r, q\) are all much smaller than \(N\) and, typically, \(q \gg n\), the dominant cost per iteration is \(O(q r)\). The number of CG iterations is usually modest (e.g., tens) because the preconditioner captures the essential spectral behaviour. The total cost is therefore linear in \(q\) and independent of \(N\), which is the desired efficiency.

### 5. Why this works

* **Kronecker structure exploitation**: The identities \((Z\otimes K)\operatorname{vec}(W) = \operatorname{vec}(KWZ^{\mathsf T})\) and its transpose allow us to work with the small matrices \(K,W,Z\) and only the observed entries, never forming the full \(nM\)-dimensional vector.
* **Effective preconditioning**: The expected full‑observation matrix \(P\) is a spectrally close approximation to \(A\) when the sampling is nearly uniform and \(q\) is large. It becomes block diagonal in the eigenbasis of \(K\), making its inversion cheap. This accelerates CG convergence dramatically compared to using no preconditioner or a simple diagonal preconditioner.
* **Memory and time efficiency**: All operations are limited to \(O(n^2 r + q r + n r^2)\) per iteration, and the one‑time costs (\(O(n^3)\)) are manageable because \(n\) (the size of mode \(k\)) is assumed moderate. No operation touches the full tensor size \(N\).

Thus, the proposed iterative solver with the preconditioned CG method solves the mode‑\(k\) subproblem efficiently and exactly (up to CG tolerance) without ever assembling or storing large matrices.