# Candidate solution: FirstProof_10 | qwen3.6-35b-a3b | full | reasoning=default

v4-flash judge score: 6.0

---

## Summary

**Verdict:** Solved
**Method sketch:** We solve the mode-$k$ update using Preconditioned Conjugate Gradient (PCG). Matrix-vector products exploit the Kronecker-vectorization duality $\operatorname{vec}(AXB^T)=(B\otimes A)\operatorname{vec}(X)$ and the sparsity of the observation mask $\Omega=SS^T$, reducing the cost to $O(n^2 r + qr)$. We employ a Kronecker-factored preconditioner $P=(Z^T\Omega Z+\lambda I_r)\otimes K$, which captures column correlations and regularization, requires only $O(qr^2)$ to assemble, and applies in $O(n^2 r + nr^2)$ per iteration. This avoids explicit formation of $O((nr)^2)$ matrices and all $O(N)$ operations.

## Detailed Solution

### 1. Linear System & PCG Framework
The mode-$k$ subproblem seeks $W \in \mathbb{R}^{n \times r}$ satisfying:
\[
H \operatorname{vec}(W) = \mathbf{b}, \quad \text{where} \quad H = (Z^T \otimes K) \Omega (Z \otimes K) + \lambda (I_r \otimes K), \quad \mathbf{b} = (I_r \otimes K) \operatorname{vec}(B).
\]
Here $\Omega = SS^T \in \mathbb{R}^{N \times N}$ is a diagonal binary mask with $q$ ones (observed entries) and $N-q$ zeros. Since $H$ is symmetric positive definite (sum of a PSD term and $\lambda(I_r \otimes K)$), the Conjugate Gradient method is applicable. PCG requires:
1. Efficient computation of $y = H v$ for arbitrary $v \in \mathbb{R}^{nr}$.
2. A preconditioner $P \approx H$ such that solving $Px = r$ is cheap.
We design both to avoid $O(N)$ and $O(n^3 r^3)$ complexities.

### 2. Fast Matrix-Vector Product
Let $v = \operatorname{vec}(V)$ with $V \in \mathbb{R}^{n \times r}$. We compute $y = Hv$ in two parts without forming $H$ or any $n \times M$ dense matrix.

**Step A: First term $y_1 = (Z^T \otimes K) \Omega (Z \otimes K) v$**
Using the identity $\operatorname{vec}(AXB^T) = (B \otimes A)\operatorname{vec}(X)$:
1. Compute $Y = KV \in \mathbb{R}^{n \times r}$. Cost: $O(n^2 r)$.
2. Compute intermediate vector $u = (Z \otimes K)v = \operatorname{vec}(YZ^T) \in \mathbb{R}^N$. The matrix $YZ^T \in \mathbb{R}^{n \times M}$ is never formed. Instead, since $\Omega$ only selects $q$ entries, we directly compute the $q$ required values of $YZ^T$ at observed index pairs $\{(i_m, j_m)\}_{m=1}^q$:
   \[
   [YZ^T]_{i_m, j_m} = y_{i_m}^\top z_{j_m},
   \]
   where $y_{i_m}$ is the $i_m$-th row of $Y$ and $z_{j_m}$ is the $j_m$-th row of $Z$. Each inner product costs $O(r)$, total cost $O(qr)$.
3. Store these $q$ values in a sparse $n \times M$ matrix $\tilde{M}$ (or a list of coordinates and values). This represents $\Omega \operatorname{vec}(YZ^T)$.
4. Apply $(Z^T \otimes K)$ to this sparse vector: $(Z^T \otimes K)\operatorname{vec}(\tilde{M}) = \operatorname{vec}(K \tilde{M} Z)$. 
   - Compute $\tilde{M}Z \in \mathbb{R}^{n \times r}$: Since $\tilde{M}$ has only $q$ nonzeros, $(\tilde{M}Z)_{ik} = \sum_{j} \tilde{M}_{ij}Z_{jk}$ sums over $q$ terms. Cost: $O(qr)$.
   - Compute $K(\tilde{M}Z)$: Standard matrix multiplication. Cost: $O(n^2 r)$.
   - Vectorize to get $y_1$. Cost: $O(nr)$.

**Step B: Second term $y_2 = \lambda (I_r \otimes K) v$**
Using the identity again: $(I_r \otimes K)\operatorname{vec}(V) = \operatorname{vec}(KV) = \operatorname{vec}(Y)$. This is already computed in Step A.1. Cost: $O(1)$ reuse.

**Total MatVec Cost:** $O(n^2 r + qr)$. Since $n, r < q$, this simplifies to $O(qr)$. No $O(N)$ or $O((nr)^2)$ terms appear.

### 3. Preconditioner Construction & Application
A standard effective preconditioner for Kronecker-structured systems is the Kronecker-factored approximation:
\[
P = (Z^T \Omega Z + \lambda I_r) \otimes K.
\]
**Why this works:** 
- Captures the column covariance induced by the Khatri-Rao product $Z$ and the observation mask $\Omega$.
- Preserves the Kronecker structure of $H$, allowing $P^{-1}$ to be applied via sequential solves.
- $Z^T \Omega Z \in \mathbb{R}^{r \times r}$ depends only on the $q$ observed rows of $Z$. It can be assembled in $O(qr^2)$ time by computing outer products of the $q$ relevant rows. This avoids $O(M r^2) = O(N r^2/n)$.

**Applying $P^{-1}$ to a vector $r$:** Let $R = \operatorname{mat}(r) \in \mathbb{R}^{n \times r}$. We solve $P x = r$:
\[
((G + \lambda I_r) \otimes K) \operatorname{vec}(X) = \operatorname{vec}(R) \implies K X (G + \lambda I_r)^\top = R,
\]
where $G = Z^T \Omega Z$ and $X = \operatorname{mat}(x)$. The solution proceeds in three steps:
1. **Factorize once:** Compute Cholesky $K = L_K L_K^\top$ ($O(n^3)$) and $G+\lambda I_r = L_G L_G^\top$ ($O(r^3)$). Done globally.
2. **Solve $K Q = R$:** Forward/backward substitution with $L_K$. Since there are $r$ right-hand sides, cost is $O(n^2 r)$.
3. **Solve $(G+\lambda I_r) X^\top = Q^\top$:** Equivalent to $X = Q (G+\lambda I_r)^{-\top}$. Using Cholesky of the $r \times r$ matrix, cost is $O(n r^2)$.
4. Vectorize $X$ to get $x$. Cost: $O(nr)$.

**Total Preconditioner Application Cost:** $O(n^2 r + nr^2)$ per iteration, dominated by $O(n^2 r)$. This is cheaper than the matvec when $q \gg n$.

### 4. Complexity Analysis
- **Per Iteration:** $O(n^2 r + qr)$ for matvec + $O(n^2 r + nr^2)$ for preconditioner solve. Overall: $O(n^2 r + qr)$.
- **Setup:** $O(n^3 + r^3 + qr^2)$ for factorizations and assembling $G$. Done once.
- **Total:** For $k$ PCG iterations, total cost is $O(k(n^2 r + qr) + n^3 + r^3 + qr^2)$. 
- **Avoids:** Explicit formation of $H$ ($O((nr)^2)$), $O(N)$ storage/computation, and $O(n^3 r^3)$ direct solve. All operations scale polynomially in $n, r, q$ and are independent of $M$ and $N$.

### 5. Algorithm Summary
```
Input: K, Z (or factors), observed entries T_obs, indices Omega, lambda, max_iter, tol
Output: W

1. [Setup]
   - Form G = Z^T Omega Z in O(q r^2)
   - Cholesky K = L_K L_K^T, and P_G = G + lambda I_r = L_G L_G^T
   - b_vec = vec(K B); b = b_vec

2. [PCG Initialization]
   w_0 = zeros(nr, 1); r_0 = b; x_0 = P^{-1} r_0 (apply preconditioner steps)
   p_0 = x_0; rho_0 = r_0^T x_0

3. [PCG Loop, t = 0 to max_iter]
   - v_t = H w_t  (using matvec routine: Y=K*mat(w_t); extract q entries of YZ^T; 
                   compute K*(sparse_matrix * Z); add lambda*Y)
   - alpha_t = rho_t / (p_t^T v_t)
   - w_{t+1} = w_t + alpha_t p_t
   - r_{t+1} = r_t - alpha_t v_t
   - If ||r_{t+1}|| < tol, break
   - x_{t+1} = P^{-1} r_{t+1}  (using preconditioner steps)
   - rho_{t+1} = r_{t+1}^T x_{t+1}
   - beta_t = rho_{t+1} / rho_t
   - p_{t+1} = x_{t+1} + beta_t p_t

4. Return W = mat(w_{t+1})
```
This approach rigorously leverages tensor algebra identities, sparsity, and Kronecker preconditioning to solve the infinite-dimensional mode-$k$ subproblem efficiently within the alternating optimization framework.