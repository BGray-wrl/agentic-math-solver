# Candidate solution: FirstProof_10 | gemma-4-31b-it | seed_full | reasoning=max

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved
**Method sketch:** The system is solved using a Preconditioned Conjugate Gradient (PCG) method. We approximate the observed-entry selection matrix $SS^T$ with a scaled identity matrix $\alpha I$, where $\alpha = q/N$. This leads to a preconditioner $P = \alpha (Z^T Z \otimes K^2) + \lambda (I_r \otimes K)$, which can be efficiently inverted by utilizing the spectral decompositions of the $r \times r$ matrix $Z^T Z$ and the $n \times n$ matrix $K$. Matrix-vector products $Av$ are computed by exploiting the sparsity of the observed entries and the properties of Kronecker products, avoiding any $O(N)$ computations.

---

## Detailed Solution

### 1. Problem Setup and System Analysis
We are tasked with solving the linear system:
$$\left[ (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K) \right] \operatorname{vec}(W) = (I_r \otimes K) \operatorname{vec}( B ) $$
where:
- $S S^T \in \mathbb{R}^{N \times N}$ is a diagonal selection matrix (1 if the entry is observed, 0 otherwise).
- $Z \in \mathbb{R}^{M \times r}$ is the Khatri-Rao product of other factor matrices.
- $K \in \mathbb{R}^{n \times n}$ is the PSD RKHS kernel matrix.
- $W \in \mathbb{R}^{n \times r}$ is the unknown.
- $N = nM$ and $q$ is the number of observed entries.

Let $A = (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K)$ and $x = \operatorname{vec}(W)$. Since $K$ and $Z^T Z$ are PSD and $\lambda > 0$, $A$ is symmetric positive definite (SPD), making the Preconditioned Conjugate Gradient (PCG) method an ideal solver.

### 2. The Full-Data Approximation Preconditioner
To avoid the cost of inverting an $nr \times nr$ matrix, we approximate $S S^T$ with $\alpha I$, where $\alpha = q/N$ represents the sampling density. The preconditioner $P$ is:
$$P = (Z \otimes K)^T (\alpha I) (Z \otimes K) + \lambda (I_r \otimes K) = \alpha (Z^T Z \otimes K^T K) + \lambda (I_r \otimes K)$$
Assuming $K$ is symmetric ($K^T = K$):
$$P = \alpha (Z^T Z \otimes K^2) + \lambda (I_r \otimes K)$$
We can factor $P$ as follows:
$$P = [ \alpha (Z^T Z \otimes K) + \lambda (I_r \otimes I_n) ] (I_r \otimes K)$$
To verify:
$$[ \alpha (Z^T Z \otimes K) + \lambda (I_r \otimes I_n) ] (I_r \otimes K) = \alpha (Z^T Z \cdot I_r \otimes K \cdot K) + \lambda (I_r \cdot I_r \otimes I_n \cdot K) = \alpha (Z^T Z \otimes K^2) + \lambda (I_r \otimes K)$$
Thus, the inverse is $P^{-1} = (I_r \otimes K)^{-1} [ \alpha (Z^T Z \otimes K) + \lambda I_{nr} ]^{-1}$.

### 3. Efficient Computation of $P^{-1} v$
Let $Q = \alpha (Z^T Z \otimes K) + \lambda I_{nr}$. Since $Z^T Z \in \mathbb{R}^{r \times r}$ is small, we compute its spectral decomposition $Z^T Z = V \Lambda V^T$.
Then $Q = (V \otimes I_n) [ \alpha (\Lambda \otimes K) + \lambda I_{nr} ] (V^T \otimes I_n)$.
The central matrix $D = \alpha (\Lambda \otimes K) + \lambda I_{nr}$ is block-diagonal with blocks $B_i = \alpha \lambda_i K + \lambda I_n$ for $i=1, \dots, r$.
To compute $P^{-1} v$ for $v = \operatorname{vec}(W)$:
1. **Transform**: $\text{vec}(W_1) = (V^T \otimes I_n) \operatorname{vec}(W) = \operatorname{vec}(V^T W)$. Cost: $O(nr^2)$.
2. **Block Inversion**: Solve $B_i w_{2,i} = w_{1,i}$ for $i=1, \dots, r$. Since $B_i = \alpha \lambda_i K + \lambda I_n$, we can pre-diagonalize $K = U \Sigma U^T$. Then $B_i^{-1} = U (\alpha \lambda_i \Sigma + \lambda I)^{-1} U^T$. Cost: $O(rn^2)$.
3. **Inverse Transform**: $\text{vec}(W_2) = (V \otimes I_n) \operatorname{vec}(W_2)$. Cost: $O(nr^2)$.
4. **Kernel Inverse**: $\text{vec}(W_3) = (I_r \otimes K)^{-1} \operatorname{vec}(W_2) = \operatorname{vec}(K^{-1} W_2)$. Cost: $O(n^2 r)$.

### 4. Computation of the Matrix-Vector Product $Av$
We must compute $Av = (Z^T \otimes K) S S^T (Z \otimes K) \operatorname{vec}(W) + \lambda (I_r \otimes K) \operatorname{vec}(W)$.
1. Let $U = (Z \otimes K) \operatorname{vec}(W) = \operatorname{vec}(K W Z^T)$.
2. Let $U_{\Omega} = S S^T U$. This keeps only the $q$ observed entries of the $n \times M$ matrix $K W Z^T$.
   For $(i,j) \in \Omega$, $(U_{\Omega})_{ij} = \sum_{k=1}^n K_{ik} \sum_{l=1}^r W_{kl} (Z^T)_{lj}$.
   Cost: $O(qnr)$.
3. Compute $(Z^T \otimes K) \operatorname{vec}(U_{\Omega}) = \operatorname{vec}(K U_{\Omega} Z)$.
   The product $U_{\Omega} Z$ is an $n \times r$ matrix where $(U_{\Omega} Z)_{ik} = \sum_{j: (i,j) \in \Omega} (U_{\Omega})_{ij} Z_{jk}$.
   Cost: $O(qr)$ for the multiplication and $O(n^2 r)$ for the multiplication by $K$.
4. Add $\lambda \operatorname{vec}(K W)$. Cost: $O(n^2 r)$.

Total cost per iteration for $Av$: $O(qnr + n^2 r)$.

### 5. Complexity Analysis
- **Pre-computation**: 
  - $Z^T Z$: Using the property of Khatri-Rao products, $Z^T Z$ is the Hadamard product of the Gram matrices of the factors $A_i$. Cost: $O(\sum n_i r^2)$.
  - Spectral decomposition of $K$ and $Z^T Z$: $O(n^3 + r^3)$.
- **Per Iteration**:
  - Matrix-vector product $Av$: $O(qnr + n^2 r)$.
  - Preconditioner application $P^{-1} v$: $O(rn^2 + nr^2)$.
- **Constraint Check**: Since $n, r < q \ll N$, the complexity per iteration is dominated by $O(qnr)$, which is independent of $N$. No operation of order $O(N)$ is performed.