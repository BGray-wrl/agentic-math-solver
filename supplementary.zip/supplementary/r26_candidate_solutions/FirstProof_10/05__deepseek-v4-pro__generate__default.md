# Candidate solution: FirstProof_10 | deepseek-v4-pro | generate | reasoning=default

v4-flash judge score: 7.0

---

## Summary
**Verdict:** Solved  
**Method sketch:** The large linear system is reinterpreted as a matrix equation in the unknown \(W\). Matrix‑vector products with the system matrix are done without forming the full Kronecker product or the tensor unfolding, by iterating only over the \(q\) observed entries. A Kronecker‑structured preconditioner (the complete‑data Hessian) is inverted efficiently via eigenvalue decompositions of the kernel matrix \(K\) and of the small \(r\times r\) matrix \(Z^{\mathsf T}\!Z\). PCG then solves the system in \(O\big((n^2+q)r\big)\) per iteration with a small number of iterations.

---

## Detailed Solution

### 1. Reformulation as a matrix equation

We have the linear system of size \(nr\times nr\)
\[
\bigl[(Z\otimes K)^{\mathsf T}SS^{\mathsf T}(Z\otimes K)+\lambda (I_r\otimes K)\bigr]\operatorname{vec}(W)=(I_r\otimes K)\operatorname{vec}(B),
\]
with \(B=TZ\).  
Using \(\operatorname{vec}(K W Z^{\mathsf T})=(Z\otimes K)\operatorname{vec}(W)\), the fact that \(SS^{\mathsf T}\) simply keeps the observed entries and sets the rest to zero, and \((Z\otimes K)^{\mathsf T}=Z^{\mathsf T}\otimes K\) (since \(K\) is symmetric), the whole equation is exactly the matrix equation
\[
K\,P_\Omega(K W Z^{\mathsf T})\,Z + \lambda K W \;=\; K B .
\tag{1}
\]
Here \(P_\Omega(\cdot)\) denotes the projection that retains entries on the observed index set \(\Omega\) and zeros the others. The right‑hand side \(B\) is \(B = P_\Omega(T)Z\), where \(T\) is the mode‑\(k\) unfolding of the tensor with missing entries set to zero.

### 2. Matrix‑vector products without forming large arrays

To apply a conjugate gradient method we must be able to compute the left‑hand side of (1) for a given \(V\in\mathbb{R}^{n\times r}\).  
The operator is
\[
\mathcal{M}(V) = K\,P_\Omega(K V Z^{\mathsf T})\,Z + \lambda K V .
\]

**Step‑by‑step computation of \(\mathcal{M}(V)\):**
1. **Multiply by the kernel matrix:** \(U = K V\).  
   *Cost:* \(O(n^2 r)\) (dense \(K\); can be reduced for structured kernels).
2. **Apply \(P_\Omega(\cdot)Z\):**  
   Initialize \(D = 0 \in \mathbb{R}^{n\times r}\).  
   For each observed entry \((i,j)\in\Omega\) (where \(i\in\{1,\dots,n\}\) and \(j\) indexes the multi‑index of the other modes):
   - Compute the row \(\mathbf{z}_j = Z(j,:)\in\mathbb{R}^{1\times r}\).  
     Because \(Z\) is the Khatri–Rao product of the fixed factor matrices \(\{A_m\}_{m\neq k}\), for the given multi‑index we form \(\mathbf{z}_j\) as the element‑wise product of the corresponding rows.  
     *Cost:* \(O(rd)\) (\(d\) is the number of modes).
   - Compute the scalar \(s = U_{i,:}\,\mathbf{z}_j^{\mathsf T} = \sum_{f=1}^r U_{i,f} Z_{j,f}\).  
     *Cost:* \(O(r)\).
   - Accumulate \(D_{i,:} \leftarrow D_{i,:} + s\,\mathbf{z}_j\).  
     *Cost:* \(O(r)\).
3. **Final kernel multiplication:** \(\mathcal{M}(V) = K D + \lambda U\).  
   *Cost:* \(O(n^2 r)\).

Total cost per CG iteration: \(O(n^2 r + q r d)\). The tensor order \(d\) is small, so the dominant term is \(O\bigl((n^2+q)r\bigr)\).

**Right‑hand side:**  
\(B = P_\Omega(T)Z\) is computed in the same way: initialise \(B=0\), for each \((i,j)\in\Omega\) add \(T_{i,j}\,\mathbf{z}_j\) to the \(i\)-th row of \(B\). Then the right‑hand side of (1) is \(K B\). Cost \(O(q r + n^2 r)\).

Crucially, the full unfolding \(T\) (size \(N=n M\)) and the full matrix \(Z\) (\(M\times r\)) are never formed. Only the \(q\) observed entries are touched, and \(q\ll N\).

### 3. Preconditioner

If all entries were observed, \(SS^{\mathsf T}=I_N\) and the system would become
\[
\mathcal{P}(W) = K(K W Z^{\mathsf T})Z + \lambda K W
\quad\Longleftrightarrow\quad
\mathcal{P} = (Z^{\mathsf T}Z)\otimes K^2 + \lambda I_r\otimes K .
\]
This complete‑data Hessian captures the Kronecker structure and is an excellent preconditioner for the incomplete‑data problem. It is symmetric positive definite ( \(\lambda>0\), \(K\) psd).

**Applying \(\mathcal{P}^{-1}\) efficiently:**
1. *Pre‑computations (once per mode‑\(k\) subproblem):*
   - Eigendecomposition of the kernel matrix: \(K = Q_K \Lambda_K Q_K^{\mathsf T}\), \(\Lambda_K = \operatorname{diag}(\alpha_1,\dots,\alpha_n)\).  
     *Cost:* \(O(n^3)\).
   - Form \(G = Z^{\mathsf T}Z\) **without** building \(Z\):  
     Using the property \((\odot_{m\neq k} A_m)^{\mathsf T}(\odot_{m\neq k} A_m) = \bigodot_{m\neq k} (A_m^{\mathsf T}A_m)\) (Hadamard product), we compute each \(r\times r\) matrix \(A_m^{\mathsf T}A_m\) and then their element‑wise product.  
     *Cost:* \(O\bigl((\sum_{m\neq k} n_m) r^2\bigr)\).
   - Eigendecomposition of \(G\): \(G = Q_Z \Lambda_Z Q_Z^{\mathsf T}\), \(\Lambda_Z = \operatorname{diag}(\beta_1,\dots,\beta_r)\).  
     *Cost:* \(O(r^3)\).
2. *For a given residual matrix \(R\in\mathbb{R}^{n\times r}\) (vec(\(R\)) in CG):*
   \[
   \begin{aligned}
   R_1 &= Q_K^{\mathsf T} R\, Q_Z, \quad &&\text{Cost } O(n^2 r + n r^2),\\
   (R_2)_{i,f} &= \frac{(R_1)_{i,f}}{\beta_f \alpha_i^2 + \lambda \alpha_i}, \quad &&\text{Cost } O(nr),\\
   \mathcal{P}^{-1}(R) &= Q_K R_2 Q_Z^{\mathsf T}, \quad &&\text{Cost } O(n^2 r + n r^2).
   \end{aligned}
   \]
   Thus applying the preconditioner costs \(O(n^2 r + n r^2)\) per iteration.

### 4. Complexity and justification

**Per outer (mode‑\(k\)) subproblem:**
- **Setup:** \(O\bigl(n^3 + r^3 + (\sum_{m\neq k} n_m) r^2\bigr)\). This is acceptable because \(n,r < q \ll N\).
- **Each PCG iteration:** \(O\bigl((n^2+q)r + n r^2\bigr)\). With \(r\) small and typically \(n^2 \lesssim q\), the dominant term is \(O(q r)\).
- The number of iterations of PCG is greatly reduced by the preconditioner. Because \(\mathcal{P}\) is the exact Hessian of the fully observed problem, it spectrally approximates the true Hessian when the missing pattern is not too pathological; the eigenvalues of \(\mathcal{P}^{-1}\mathcal{M}\) cluster around 1.

Compare this with a direct solver that would cost \(O(n^3 r^3)\) and require explicitly forming a matrix of size \(nr\times nr\) (which in turn would involve \(O(N)\) operations if done crudely). Our method completely avoids any operation of order \(N\) or \(M\), and reduces the polynomial dependence on \(r\) from cubic to linear.

**Why it works:**  
The operator \(\mathcal{M}\) is applied by iterating only over the \(q\) observed entries, using the fact that \((K V Z^{\mathsf T})Z\) collapses to a sum over \(\Omega\) of rank‑one contributions. The preconditioner decouples the Kronecker dimensions via diagonalisation of the small matrices \(K\) and \(Z^{\mathsf T}Z\), making its inverse almost as cheap as a matrix‑vector product. The regularisation \(\lambda>0\) guarantees positive definiteness and robust PCG convergence.