# Candidate solution: FirstProof_10 | gemini-3-flash-preview | full | reasoning=default

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved
**Method sketch:** We solve the structured linear system $Hx=b$ using Preconditioned Conjugate Gradient (PCG). By exploiting the Khatri-Rao structure of $Z$ and the sparsity of the observation pattern $S$, we compute matrix-vector products $H \operatorname{vec}(W)$ in $O(qr + nr^2 + n^2r)$ time, avoiding the $O(N)$ or $O(nr^3)$ costs. We employ a block-diagonal preconditioner based on the ridge-regularized kernel, which can be inverted in $O(nr^3 + n^3)$ or approximated via the Woodbury identity.

---

## Detailed Solution

### 1. Matrix Structure and Problem Reformulation
The system to solve is $H \mathbf{w} = \mathbf{g}$, where $\mathbf{w} = \operatorname{vec}(W)$, and:
$$H = (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K)$$
$$\mathbf{g} = (I_r \otimes K) \operatorname{vec}(B)$$
Note that $S S^T$ is an $N \times N$ diagonal matrix where $(S S^T)_{ii} = 1$ if entry $i$ is observed and $0$ otherwise. Let $\Omega \subset \{1,\dots,n\} \times \{1,\dots,M\}$ be the set of indices of the observed entries in the mode-$k$ unfolding $T$. Then the term $(Z \otimes K)^T S S^T (Z \otimes K)$ represents the Gaussian information matrix associated with the weighted least squares fit over observed entries.

### 2. Efficient Matrix-Vector Multiplication
Applying $H$ to a vector $\mathbf{u} = \operatorname{vec}(U)$ (where $U \in \mathbb{R}^{n \times r}$) is the core of the CG algorithm. Let $V = KU$.
1.  **Interaction with $(Z \otimes K)$**: The product $(Z \otimes K) \operatorname{vec}(U)$ is equivalent to $\operatorname{vec}(V Z^T)$.
2.  **Sparsity Masking**: Let $Y = V Z^T$. The operation $S S^T \operatorname{vec}(Y)$ sets $Y_{ij} = 0$ if $(i,j) \notin \Omega$. Let this masked matrix be $\mathcal{P}_\Omega(Y)$.
3.  **Adjoint Operation**: $(Z \otimes K)^T \operatorname{vec}(\mathcal{P}_\Omega(Y)) = \operatorname{vec}(K^T \mathcal{P}_\Omega(Y) Z) = \operatorname{vec}(K \mathcal{P}_\Omega(Y) Z)$.
4.  **Regularization**: $\lambda (I_r \otimes K) \operatorname{vec}(U) = \operatorname{vec}(\lambda K U)$.

**Algorithm for $H \mathbf{u}$:**
1. Compute $V = KU$ ($O(n^2 r)$).
2. For each observed entry $(i, j) \in \Omega$, compute $y_{ij} = \sum_{p=1}^r V_{ip} Z_{jp}$. This is the "forward" step. Total cost $O(qr)$.
3. Compute $Q = \mathcal{P}_\Omega(Y) Z$, where $Q_{iq} = \sum_{j: (i,j) \in \Omega} y_{ij} Z_{jq}$. This is the "backward" step. Total cost $O(qr)$.
4. Compute $R = KQ + \lambda V$ ($O(n^2 r)$).
5. Output $\operatorname{vec}(R)$.

**Total cost per iteration:** $O(qr + n^2 r)$. Since $q \gg n, r$, this is significantly faster than $O(n^3 r^3)$.

### 3. Preconditioner Selection
The system is often ill-conditioned due to the kernel $K$ and the sparsity of observations. A standard choice for tensor completion is the **block-diagonal preconditioner** (ignoring the cross-mode correlations in the sampling pattern). 
Define $D = \text{diag}(Z^T Z) \in \mathbb{R}^{r \times r}$. We approximate $S S^T \approx \frac{q}{NM} I_N$ or more accurately, we look at the expected value of the information matrix. A robust choice is:
$$P = (\text{diag}(Z^T Z) \otimes K^2) + \lambda (I_r \otimes K) = (D \otimes K^2) + \lambda (I_r \otimes K)$$
Since $D$ is diagonal ($D_{pp} = \sigma_p$), this factors into $r$ independent $n \times n$ blocks:
$$P_p = \sigma_p K^2 + \lambda K = K(\sigma_p K + \lambda I_n)$$
To apply $P^{-1}$ to $\operatorname{vec}(R)$, for each $p=1 \dots r$, we solve:
$$K(\sigma_p K + \lambda I_n) \mathbf{w}_p = \mathbf{r}_p \implies \mathbf{w}_p = (\sigma_p K + \lambda I_n)^{-1} K^{-1} \mathbf{r}_p$$
By substituting $V = KU$, the original system was actually $K(\dots)W$, so the $K^{-1}$ usually cancels out in the preconditioning step of the weighted space. If $K$ is ill-conditioned, we use the preconditioner $P_p = \sigma_p K + \lambda I_n$. 

### 4. Complexity Analysis
*   **Memory:** We only store $Z$ ($M \times r$, potentially sampled to $q \times r$), $K$ ($n \times n$), and $W$ ($n \times r$). We avoid $O(N)$ and $O(n^2 r^2)$.
*   **Computation (Per Iteration):**
    *   **MTTKRP-like products:** $O(qr)$ to compute entries of $Y$ at $\Omega$ and $O(qr)$ to contract back with $Z$.
    *   **Kernel products:** $O(n^2 r)$ for $KU$.
    *   **Preconditioner solve:** $O(r \cdot n^2)$ if we pre-factorize $P_p$ or $O(r \cdot n^3)$ once at the start.
*   **Total Complexity:** $O(I \cdot (qr + n^2 r))$, where $I$ is the number of CG iterations. 
*   **Comparison:** The standard solver is $O(n^3 r^3)$. Given $n, r < q \ll N$, our approach is $O(qr + n^2 r)$, which is linear in the number of observed entries $q$ and quadratic in the small dimension $n$.

### 5. Why this works
This works because the Khatri-Rao structure allows us to evaluate the operator $H$ using the property $\operatorname{vec}(AXB) = (B^T \otimes A) \operatorname{vec}(X)$. By restricting the middle operation to the set $\Omega$, we never form the $N \times N$ matrix $S S^T$ nor the Kronecker product $(Z \otimes K)$. The preconditioning handles the stiffness of the RKHS kernel $K$, ensuring fast convergence of the CG algorithm.