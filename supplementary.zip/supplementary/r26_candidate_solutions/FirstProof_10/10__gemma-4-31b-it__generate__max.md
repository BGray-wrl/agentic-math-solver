# Candidate solution: FirstProof_10 | gemma-4-31b-it | generate | reasoning=max

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved
**Method sketch:** The system is solved using the Preconditioned Conjugate Gradient (PCG) method. The matrix-vector product $Hv$ is computed efficiently by leveraging the sparsity of the selection matrix $S$ and the properties of the Kronecker product, reducing the complexity from $O(n^3 r^3)$ to $O(qnr)$ per iteration. A block-diagonal preconditioner $P = \lambda(I_r \otimes K)$ is used to capture the RKHS structure and accelerate convergence.

---

## Detailed Solution

### 1. Analysis of the Linear System
The system we need to solve is:
$$\left[ (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K) \right] \operatorname{vec}(W) = (I_r \otimes K) \operatorname{vec}(B)$$
where:
- $W \in \mathbb{R}^{n \times r}$ is the unknown.
- $Z \in \mathbb{R}^{M \times r}$ is the Khatri-Rao product of other factor matrices.
- $K \in \mathbb{R}^{n \times n}$ is the PSD RKHS kernel matrix.
- $S S^T \in \mathbb{R}^{N \times N}$ is a diagonal mask matrix where $(S S^T)_{ii} = 1$ if the $i$-th entry of the tensor is observed, and $0$ otherwise.
- $B = TZ \in \mathbb{R}^{n \times r}$ is the MTTKRP.

Let $H = (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K)$. $H$ is a symmetric positive definite (SPD) matrix of size $nr \times nr$. Solving this system using a direct solver costs $O(n^3 r^3)$. To avoid this and the $O(N)$ cost of forming $H$, we use the PCG method.

### 2. Efficient Matrix-Vector Product (MatVec)
Let $v = \operatorname{vec}(W)$. We need to compute $Hv$ efficiently. Using the property $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$, we have:
$$(Z \otimes K) \operatorname{vec}(W) = \operatorname{vec}(K W Z^T)$$
Let $X = K W Z^T \in \mathbb{R}^{n \times M}$. The term $S S^T \operatorname{vec}(X)$ effectively masks $X$, keeping only observed entries. Let $\Omega = \{ (i, j) \mid \text{entry } (i, j) \text{ of the unfolded tensor } T \text{ is observed} \}$, where $|\Omega| = q$. Then:
$$S S^T \operatorname{vec}(X) = \operatorname{vec}(Y), \quad \text{where } Y_{ij} = \begin{cases} X_{ij} & (i, j) \in \Omega \\ 0 & \text{otherwise} \end{cases}$$
Now we apply $(Z \otimes K)^T = (Z^T \otimes K)$:
$$(Z^T \otimes K) \operatorname{vec}(Y) = \operatorname{vec}(K Y (Z^T)^T) = \operatorname{vec}(K Y Z)$$
The matrix $Y Z \in \mathbb{R}^{n \times r}$ can be written as a sum over observed entries:
$$Y Z = \sum_{j=1}^M Y_{:,j} z_j^T = \sum_{(i, j) \in \Omega} Y_{ij} e_i z_j^T$$
where $z_j^T$ is the $j$-th row of $Z$ and $e_i$ is the $i$-th canonical basis vector. Then:
$$K Y Z = \sum_{(i, j) \in \Omega} Y_{ij} (K e_i) z_j^T$$
where $K e_i$ is the $i$-th column of $K$. 

**Algorithm for MatVec $Hv$:**
1. **Project $W$:** Compute $W_{proj} = K W \in \mathbb{R}^{n \times r}$. Complexity: $O(n^2 r)$.
2. **Compute Observed Entries:** For each $(i, j) \in \Omega$, compute $Y_{ij} = (W_{proj})_{i, \cdot} \cdot z_j$. Complexity: $O(qr)$.
3. **Accumulate Result:** Compute $W_{new} = \sum_{(i, j) \in \Omega} Y_{ij} (K e_i) z_j^T$. Complexity: $O(qnr)$.
4. **Regularization:** Add $\lambda K W$ to $W_{new}$. Complexity: $O(n^2 r)$.
5. **Output:** $Hv = \operatorname{vec}(W_{new})$.

Since $q \gg n, r$, the total complexity per MatVec is $O(qnr)$. We avoid $O(N)$ by only iterating over $\Omega$ and computing rows $z_j$ on the fly or storing only the $q$ unique rows used.

### 3. Preconditioner Choice
The system is dominated by the RKHS structure and the regularization term $\lambda (I_r \otimes K)$. A natural choice for the preconditioner is:
$$P = \lambda (I_r \otimes K)$$
$P$ is a block-diagonal matrix consisting of $r$ blocks of $K$. Because $K$ is the Gram matrix of the RKHS, this preconditioner accounts for the intrinsic geometry of the infinite-dimensional mode.

**Applying the Preconditioner:**
To solve $P z = r$ for a residual vector $r = \operatorname{vec}(R)$:
$$\lambda (I_r \otimes K) \operatorname{vec}(Z_{sol}) = \operatorname{vec}(R) \implies \lambda K Z_{sol} = R \implies Z_{sol} = \frac{1}{\lambda} K^{-1} R$$
This requires inverting $K$ (or performing a Cholesky decomposition), costing $O(n^3)$ once, and $O(n^2 r)$ per PCG iteration.

### 4. Complexity Analysis
- **Preprocessing:** Cholesky factorization of $K$ takes $O(n^3)$. Computing $B = TZ$ takes $O(qr)$.
- **Per Iteration:**
    - MatVec $Hv$: $O(qnr)$.
    - Preconditioner solve $P^{-1} r$: $O(n^2 r)$.
    - CG vector operations: $O(nr)$.
- **Total Complexity:** $O(n^3 + \text{iters} \cdot qnr)$.

Given $n, r < q \ll N$, this is significantly more efficient than the $O(n^3 r^3)$ direct solver and avoids the $O(N)$ cost of explicitly handling the full tensor or the Kronecker product $Z \otimes K$.