# Candidate solution: FirstProof_10 | gpt-oss-120b | seed_generate | reasoning=max

v4-flash judge score: 6.0

---

**Summary**

**Verdict:** Solved  

**Method sketch:**  Solve the normal‐equation  
\[
\Big[(Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)+\lambda (I_r\!\otimes\!K)\Big]\operatorname{vec}(W)
   = (I_r\!\otimes\!K)\operatorname{vec}(B)
\]  
with a preconditioned conjugate‑gradient (PCG) method.  
Use the block‑diagonal preconditioner  

\[
P = I_r\!\otimes\!K,
\qquad P^{-1}=I_r\!\otimes\!K^{-1},
\]

which can be applied by solving \(r\) independent linear systems with the SPD kernel
\(K\) (e.g. a Cholesky factorisation).  
A matrix‑vector product with the Kronecker matrix \((Z\!\otimes\!K)\) is performed
*matrix‑free*: first compute \(X=KW\), then for each observed entry
\((i,j)\) form the scalar \(\langle X_{i,:},Z_{j,:}\rangle\).  The transpose
product \((Z\!\otimes\!K)^{\!T}\) is obtained by accumulating those scalars back
into an \(n\times r\) matrix and left‑multiplying by \(K\).  Each PCG iteration
therefore costs  

\[
\mathcal O(qr+ n^{2}r) \;(\text{or } \mathcal O(qr+n\log n\, r)\text{ for fast kernels}),
\]

never touching the full tensor of size \(N\).  The total work is
\(\mathcal O\big((qr+n^{2}r)\,{\rm #iter}\big)\) plus a one‑off
\(\mathcal O(n^{3})\) factorisation of \(K\).

---

**Detailed Solution**

--------------------------------------------------------------------
### 1.  The linear system

For the mode‑\(k\) update we have the regularised kernel‑ridge regression

\[
\min_{W\in\mathbb R^{n\times r}}
\Big\|S^{\!T}\operatorname{vec}(KWZ^{\!T})-\operatorname{vec}(T_S)\Big\|_{2}^{2}
      +\lambda\|KW\|_{F}^{2},
\]

where \(T_S\) contains the observed entries of the mode‑\(k\) unfolding
\(T\in\mathbb R^{n\times M}\) (all missing entries are set to zero) and
\(Z\in\mathbb R^{M\times r}\) is the Khatri–Rao product of the *other* factor
matrices.  
Setting the gradient to zero yields the normal equations

\[
\Big[(Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)
       +\lambda (I_r\!\otimes\!K)\Big]\operatorname{vec}(W)
   = (I_r\!\otimes\!K)\operatorname{vec}(B),\qquad B:=TZ .
\tag{1}
\]

Denote the left‑hand side matrix by \(A\) and the right‑hand side by
\(b\).  Both are of size \(nr\times nr\), but they are *never* formed
explicitly.

--------------------------------------------------------------------
### 2.  SPD property and preconditioner

*Symmetry and positive definiteness.*  
\(K\) is symmetric positive–definite (SPD), \(S S^{\!T}\) is a diagonal mask with
entries \(0\) or \(1\), and \((Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)\) is therefore
symmetric positive‑semi‑definite.  Adding \(\lambda (I_r\!\otimes\!K)\) with
\(\lambda>0\) makes \(A\) strictly SPD, so the conjugate‑gradient method is
applicable.

*Choice of preconditioner.*  
A natural preconditioner is the block‑diagonal part of \(A\),

\[
P := I_r\!\otimes\!K,
\qquad 
P^{-1}=I_r\!\otimes\!K^{-1}.
\tag{2}
\]

\(P\) contains exactly the regularisation term; it is cheap to apply because it
decouples across the \(r\) columns of \(W\).  If \(K=LL^{\!T}\) is a Cholesky
factorisation (computed once, \(\mathcal O(n^{3})\)), then applying \(P^{-1}\) to a
vector \(\operatorname{vec}(V)\) amounts to solving \(r\) systems
\(K u_{(:,\ell)} = v_{(:,\ell)}\) with forward‑/backward substitution,
cost \(\mathcal O(n^{2}r)\).

--------------------------------------------------------------------
### 3.  Matrix‑vector product with \(A\) (matrix‑free)

Let a vector \(v\in\mathbb R^{nr}\) be reshaped as a matrix
\(W\in\mathbb R^{n\times r}\) (i.e. \(v=\operatorname{vec}(W)\)).  We must compute

\[
Av = (Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)v
            +\lambda (I_r\!\otimes\!K)v .
\tag{3}
\]

The two terms are handled separately.

--------------------------------------------------------------------
#### 3.1  The regularisation term

\[
\lambda (I_r\!\otimes\!K)v = \operatorname{vec}\big(\lambda K W\big) .
\tag{4}
\]

This requires a left multiplication of \(W\) by \(K\) – an \(\mathcal O(n^{2}r)\)
operation (or \(\mathcal O(n\log n \, r)\) if a fast kernel convolution can be
used).

--------------------------------------------------------------------
#### 3.2  The data‑fit term  

Define the *full* matrix
\[
Y := KWZ^{\!T}\in\mathbb R^{n\times M}.
\tag{5}
\]
Then, by the Kronecker‑vec identity,
\[
(Z\!\otimes\!K)v = \operatorname{vec}(Y) .
\tag{6}
\]

**Step 1 – multiply by the mask.**  
\(S^{\!T}\operatorname{vec}(Y)\) extracts the entries of \(Y\) that correspond to the
observed tensor elements.  Let the set of observed multi–indices be
\(\mathcal O=\{(i_{t},j_{t})\}_{t=1}^{q}\) where \(i_{t}\in\{1,\dots,n\}\) is the
mode‑\(k\) index and \(j_{t}\in\{1,\dots,M\}\) is the index of the
flattened complementary modes.  Denote by \(h\in\mathbb R^{q}\) the
vector of these extracted values:

\[
h_{t}=Y_{i_{t},j_{t}}
     =\bigl(KW\bigr)_{i_{t},:}\; Z_{j_{t},:}^{\!T}
     =\bigl\langle (KW)_{i_{t},:},\,Z_{j_{t},:}\bigr\rangle .
\tag{7}
\]

Thus we need the matrices

* \(X = KW\in\mathbb R^{n\times r}\) (cost \(\mathcal O(n^{2}r)\)),  
* the rows \(Z_{j_{t},:}\) for the \(q\) observed complementary indices.

The latter are obtained *on‑the‑fly* from the factor matrices:
for each observation the Khatri–Rao row equals the element‑wise product of the
corresponding rows of the (finite‑dimensional) factor matrices,
\[
Z_{j_{t},:}= A_{1}(i_{t}^{(1)},:)\*\cdots\*
               A_{k-1}(i_{t}^{(k-1)},:)\*
               A_{k+1}(i_{t}^{(k+1)},:)\*\cdots\* A_{d}(i_{t}^{(d)},:),
\]
so computing all \(q\) rows costs \(\mathcal O(qdr)\) once per outer ALS
iteration and is negligible compared with the CG loop.

Having \(X\) and the \(Z\)-rows, the scalars \(h_{t}\) are inner products
\(\langle X_{i_{t},:}, Z_{j_{t},:}\rangle\), each \(\mathcal O(r)\).  Hence

\[
\text{cost}(h)=\mathcal O(qr).
\tag{8}
\]

**Step 2 – apply \((Z\!\otimes\!K)^{\!T}\) to the masked vector.**  
Let \(\widetilde Y\in\mathbb R^{n\times M}\) be the sparse matrix that coincides
with \(Y\) on the observed entries and is zero elsewhere, i.e.

\[
\widetilde Y_{i_{t},j_{t}} = h_{t},\qquad
\widetilde Y_{i,j}=0\;(i,j)\notin\mathcal O .
\tag{9}
\]

Using again the Kronecker‑vec identity,

\[
(Z\!\otimes\!K)^{\!T}\operatorname{vec}(\widetilde Y)
   = \operatorname{vec}\bigl(K\,\widetilde Y\,Z\bigr).
\tag{10}
\]

The product \(\widetilde Y Z\) is cheap because \(\widetilde Y\) has only
\(q\) non‑zero entries:

\[
(\widetilde Y Z)_{i,:}
   =\sum_{t:\,i_{t}=i} h_{t}\;Z_{j_{t},:}\in\mathbb R^{r}.
\tag{11}
\]

Thus we initialise an \(n\times r\) accumulator \(C=0\) and for each observed
pair \((i_{t},j_{t})\) perform the update

\[
C_{i_{t},:}\;\; \mathrel{+=}\; h_{t}\,Z_{j_{t},:}.
\tag{12}
\]

The cost of forming \(C=\widetilde Y Z\) is again \(\mathcal O(qr)\).

Finally we multiply on the left by \(K\):

\[
K\,C\;=\;K(\widetilde Y Z),\qquad
\operatorname{vec}(K\,C)= (Z\!\otimes\!K)^{\!T}S\,h .
\tag{13}
\]

This costs \(\mathcal O(n^{2}r)\).

**Result of the data‑fit term.**  
Putting Steps 1–2 together yields

\[
(Z\!\otimes\!K)^{\!T}SS^{\!T}(Z\!\otimes\!K)v
      =\operatorname{vec}\bigl(K\,C\bigr),
\tag{14}
\]
where \(C\) has been built from the observed entries only.

--------------------------------------------------------------------
#### 3.3  Full matrix‑vector product

Collecting (4) and (14),

\[
Av
  = \operatorname{vec}\!\bigl( K\,C + \lambda K W\bigr),
\qquad
\begin{cases}
W = \operatorname{mat}(v) ,\\[2pt]
X = K W ,\\[2pt]
h_{t}= \langle X_{i_{t},:}, Z_{j_{t},:}\rangle ,\\[2pt]
C\;:=\; \displaystyle\sum_{t=1}^{q} h_{t}\,e_{i_{t}} Z_{j_{t},:}^{\!T}.
\end{cases}
\tag{15}
\]

The dominant operations are

* two dense multiplications by \(K\)  (\(\mathcal O(n^{2}r)\) each),
* two loops over the observed entries  (\(\mathcal O(qr)\) each).

No operation ever touches the full tensor of size \(N=nM\), and we only need the
rows \(Z_{j_{t},:}\) for the observed indices.

--------------------------------------------------------------------
### 4.  Right‑hand side

The right‑hand side of (1) is

\[
b = (I_r\!\otimes\!K)\operatorname{vec}(B) = \operatorname{vec}(K B),
\tag{16}
\]

where \(B=T Z\) is the MTTKRP.  Because \(T\) is known only on the observed
entries, \(B\) can be assembled exactly as in (12) *once* per ALS sweep:

\[
B_{i,:}= \sum_{t:\,i_{t}=i} T_{i_{t},j_{t}}\;Z_{j_{t},:}.
\tag{17}
\]

Thus forming \(b\) costs \(\mathcal O(qr) + \mathcal O(n^{2}r)\).

--------------------------------------------------------------------
### 5.  Preconditioned CG algorithm

Let \(A\) and \(b\) be defined as above, and let \(P\) be the preconditioner (2).
The PCG iteration proceeds as usual:

```
w0 = 0;
r0 = b - A w0;
solve   P z0 = r0          // r linear solves with K
p0 = z0;
for t = 0,1,2,… until convergence
    αt = (rt' zt) / (pt' A pt);
    wt+1 = wt + αt pt;
    rt+1 = rt - αt A pt;
    solve   P zt+1 = rt+1;
    βt = (rt+1' zt+1)/(rt' zt);
    pt+1 = zt+1 + βt pt;
end
```

*Application of \(A\) to a vector* uses the matrix‑free routine (15).  
*Application of \(P^{-1}\)* consists of solving \(K u = v\) for each column of
the reshaped vector; with the Cholesky factor \(K=LL^{\!T}\) this is forward and
backward substitution, \(\mathcal O(n^{2}r)\).

Because \(A\) is SPD, PCG converges in at most \(nr\) iterations; in practice the
regularisation term \(\lambda\) renders the spectrum clustered and only a modest
number (typically 10–30) of iterations is required to reach high accuracy.

--------------------------------------------------------------------
### 6.  Complexity analysis

| Operation                                   | Cost per PCG iteration |
|---------------------------------------------|------------------------|
| Compute \(X = K W\)                         | \(\mathcal O(n^{2}r)\)  |
| Form inner products \(h_{t}\)               | \(\mathcal O(qr)\)      |
| Accumulate \(C = \sum h_{t} e_{i_{t}}Z_{j_{t}}^{T}\) | \(\mathcal O(qr)\) |
| Multiply \(K C\)                            | \(\mathcal O(n^{2}r)\)  |
| Add regularisation term \(\lambda K W\)     | \(\mathcal O(n^{2}r)\)  |
| Preconditioner solve \(P^{-1}r\)            | \(\mathcal O(n^{2}r)\)  |
| Vector inner products (CG scalars)          | \(\mathcal O(nr)\)      |
| **Total**                                   | \(\boxed{\mathcal O(qr + n^{2}r)}\) |

Since \(n,r\ll q\ll N\) and the algorithm never constructs the full unfolding
\(T\) (size \(nM=N\)), the overall work per outer ALS cycle is

\[
\underbrace{\mathcal O\bigl(n^{3}\bigr)}_{\text{factor }K}
\;+\;
\underbrace{\mathcal O\bigl(qr\bigr)}_{\text{build }B,b}
\;+\;
\underbrace{\mathcal O\bigl((qr+n^{2}r)\,{\rm #iter}\bigr)}_{\text{PCG}} .
\]

If the kernel admits a fast multiplication (e.g. a convolutional kernel),
the factor \(n^{2}\) can be replaced by \(n\log n\), further reducing the
per‑iteration cost to \(\mathcal O(qr+n\log n\,r)\).

Memory requirements are modest:

* store the kernel matrix \(K\) (or its Cholesky factor) – \(\mathcal O(n^{2})\);
* store the \(q\) observed rows \(Z_{j_{t},:}\) – \(\mathcal O(qr)\);
* keep a few \(n\times r\) temporary matrices.

No storage proportional to the full tensor size \(N\) is needed.

--------------------------------------------------------------------
### 7.  Why the method works

* The identity \(\operatorname{vec}(KWZ^{\!T}) = (Z\!\otimes\!K)\operatorname{vec}(W)\)
  gives an exact representation of the Kronecker product action without ever
  forming the huge matrix \(Z\!\otimes\!K\).
* The selection matrix \(S\) merely extracts a subset of entries; therefore
  computing \(S^{\!T}(Z\!\otimes\!K)v\) reduces to evaluating the scalar
  products \(\langle (KW)_{i,:}, Z_{j,:}\rangle\) at the observed index pairs.
* The transpose action \((Z\!\otimes\!K)^{\!T}\) is the adjoint of the forward
  operation and can be realised by the accumulation in (12) followed by a left
  multiplication with \(K\).
* The preconditioner \(P=I\otimes K\) captures the dominant part of \(A\); after
  preconditioning the eigenvalues of \(P^{-1}A = I + P^{-1}(Z\!\otimes\!K)^{\!T}
    S S^{\!T} (Z\!\otimes\!K)\) are clustered around 1, which explains the rapid
  convergence of CG.
* All steps involve only the observed entries (\(q\) of them) and the
  \(n\times n\) kernel matrix, guaranteeing a computational complexity that
  depends on \(q, n, r\) but **not** on the total number of tensor entries \(N\).

--------------------------------------------------------------------
### 8.  Concluding remarks

The described procedure solves the mode‑\(k\) subproblem for an infinite‑dimensional
RKHS factor within an alternating‑least‑squares framework:

* A block‑diagonal preconditioner derived from the ridge‑regularisation term
  yields inexpensive preconditioner solves.
* The matrix‑vector product with the large Kronecker matrix is carried out
  matrix‑free by exploiting the structure of the selection operator and the
  Khatri–Rao product, leading to a cost per CG iteration of
  \(\mathcal O(qr + n^{2}r)\) (or \(\mathcal O(qr + n\log n\,r)\) for fast kernels).
* No operation scales with the full tensor size \(N\), satisfying the requirement
  \(n,r<q\ll N\).

Consequently, the PCG method dramatically reduces the computational burden
compared with a direct solver (\(\mathcal O(n^{3}r^{3})\)) while retaining
exactness (up to the CG tolerance) and stability thanks to the SPD nature of
the system.  This makes the alternating optimisation feasible even when the
mode‑\(k\) factor lives in an infinite‑dimensional RKHS and the data are highly
incomplete.  