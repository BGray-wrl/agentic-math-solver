# Candidate solution: FirstProof_10 | gemma-4-31b-it | full | reasoning=default

v4-flash judge score: 6.0

---

---

## Summary

**Verdict:** Solved
**Method sketch:** We reformulate the linear system as a linear operator $L$ to avoid explicit matrix construction and $O(N)$ costs. Matrix-vector products are computed by exploiting the structure of the Khatri-Rao product and the sparsity of the selection matrix $S$ in $O(qr + n^2r)$ time. We use a Jacobi preconditioner based on the correct diagonal entries of $L$, which account for the kernel-induced coupling across rows.
**Changes from previous attempt:** Fixed the critical error in the calculation of the diagonal elements for the Jacobi preconditioner. The previous attempt incorrectly assumed that the observed entry at index $i$ only depended on the variable $V_{im}$, whereas the RKHS structure implies it depends on all $V_{lm}$ via the kernel $K_{il}$.

## Detailed Solution

### 1. Reformulating the Linear System
We are tasked with solving the system:
$$ \left[ (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K) \right] \operatorname{vec}(W) = (I_r \otimes K) \operatorname{vec}(B) $$
Let $L = (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K)$. We seek $\mathbf{w} = \operatorname{vec}(W) \in \mathbb{R}^{nr}$ such that $L \mathbf{w} = \mathbf{b}$, where $\mathbf{b} = \operatorname{vec}(KB)$.

To solve this efficiently without forming the $nr \times nr$ matrix $L$ or any $O(N)$ structures, we use the **Preconditioned Conjugate Gradient (PCG)** method. PCG only requires the ability to compute the product $L\mathbf{v}$ for any $\mathbf{v} = \operatorname{vec}(V)$ and the application of a preconditioner $P^{-1}\mathbf{v}$.

### 2. Efficient Matrix-Vector Product $L\mathbf{v}$
The operator $L$ consists of a data term $\mathcal{D}(\mathbf{v}) = (Z \otimes K)^T S S^T (Z \otimes K) \mathbf{v}$ and a regularization term $\mathcal{R}(\mathbf{v}) = \lambda (I_r \otimes K) \mathbf{v}$.

#### A. The Regularization Term
Using the property $(I_r \otimes K) \operatorname{vec}(V) = \operatorname{vec}(KV)$, we have:
$$\mathcal{R}(\mathbf{v}) = \operatorname{vec}(\lambda KV)$$
Since $K \in \mathbb{R}^{n \times n}$ and $V \in \mathbb{R}^{n \times r}$, this multiplication costs $O(n^2 r)$.

#### B. The Data Term
Let $\mathbf{v} = \operatorname{vec}(V)$. We compute the product in stages:
1. **Forward Pass**: Compute $\mathbf{u} = (Z \otimes K) \mathbf{v}$. 
   Using the identity $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$, we have:
   $$(Z \otimes K) \operatorname{vec}(V) = \operatorname{vec}(K V Z^T)$$
   Let $X = K V Z^T \in \mathbb{R}^{n \times M}$. We cannot form $X$ explicitly ($O(N)$). However, we only need $S S^T \operatorname{vec}(X)$, which is the vectorization of $X$ restricted to observed entries $\mathcal{I}$.
   - First, compute $Y = KV \in \mathbb{R}^{n \times r}$ ($O(n^2 r)$).
   - For each observed entry $(i, j) \in \mathcal{I}$, compute $x_{ij} = (Y Z^T)_{ij} = \sum_{m=1}^r Y_{im} Z_{jm}$ ($O(qr)$).
   
2. **Backward Pass**: Compute $(Z \otimes K)^T \operatorname{vec}(\tilde{X})$, where $\tilde{X}$ is the matrix containing only observed entries $x_{ij}$ and zeros elsewhere.
   $$(Z \otimes K)^T \operatorname{vec}(\tilde{X}) = (Z^T \otimes K) \operatorname{vec}(\tilde{X}) = \operatorname{vec}(K \tilde{X} Z)$$
   - Compute $P = \tilde{X} Z \in \mathbb{R}^{n \times r}$. The entry $P_{lk} = \sum_{j: (l,j) \in \mathcal{I}} x_{lj} Z_{jk}$. Since there are $q$ observed entries, this costs $O(qr)$.
   - Compute the result $\operatorname{vec}(KP)$ ($O(n^2 r)$).

**Total cost per iteration:** $O(qr + n^2 r)$.

### 3. Choice of Preconditioner
The system is often ill-conditioned due to the kernel matrix $K$. A **Jacobi Preconditioner** $P = \operatorname{diag}(L)$ is efficient because $P^{-1}$ is trivial to apply. We must correctly derive the diagonal elements.

Let $\mathbf{w} = \operatorname{vec}(W)$. An element $w_{lm}$ corresponds to the $m$-th component of the $l$-th row of $W$. The diagonal entry $L_{(l,m), (l,m)}$ is $\frac{\partial (L \mathbf{w})_{(l,m)}}{\partial w_{lm}}$.
The data term for a single observed entry $(i, j)$ is $(KVZ^T)_{ij} = \sum_{l'=1}^n \sum_{m'=1}^r K_{il'} V_{l'm'} Z_{jm}$.
The derivative with respect to $V_{lm}$ is $K_{il} Z_{jm}$.
Summing over all observed entries $\mathcal{I}$ and adding the regularization term $\lambda (I_r \otimes K)$, the diagonal element is:
$$ L_{(l,m), (l,m)} = \sum_{(i,j) \in \mathcal{I}} (K_{il} Z_{jm})^2 + \lambda K_{ll} $$
This calculation can be performed once at the start:
- $\sum_{i: (i,j) \in \mathcal{I}} K_{il}^2$ takes $O(qn)$ or $O(q)$ if pre-calculated.
- The total cost to form $\operatorname{diag}(L)$ is $O(qr + n^2)$, which is acceptable.

### 4. Complexity Analysis
- **Standard Direct Solver:** $O(n^3 r^3)$ time and $O(n^2 r^2)$ space.
- **PCG Approach:**
  - **Time per iteration:** $O(qr + n^2 r)$.
  - **Space complexity:** $O(q + n^2 + nr)$, which is independent of $N$.
- **Constraints:** Since $n, r < q \ll N$, we avoid all $O(N)$ operations. The iterative approach reduces the cubic dependence on $nr$ to linear iterations of quadratic/linear costs.

---