# Candidate solution: FirstProof_10 | deepseek-v4-pro | full | reasoning=default

v4-flash judge score: 7.0

---

**Summary**  
**Verdict:** Solved  
**Method sketch:** We reformulate the \(nr\times nr\) system as \(\mathbf{A}\operatorname{vec}(\mathbf{W}) = \mathbf{b}\) and solve it via a preconditioned conjugate gradient (PCG) method. Matrix‑vector products with \(\mathbf{A}\) are computed efficiently by exploiting the Kronecker product identity \(( \mathbf{Z}\otimes \mathbf{K} )\operatorname{vec}(\mathbf{P}) = \operatorname{vec}( \mathbf{K}\mathbf{P}\mathbf{Z}^\mathsf{T})\) and the sparsity of the observed entries, requiring only \(\mathcal{O}(n^2r + qr)\) operations per iteration. The chosen preconditioner is \(\mathbf{M} = (\mathbf{Z}^\mathsf{T}\mathbf{Z} + \lambda \mathbf{I}_r) \otimes \mathbf{K}\); it is symmetric positive definite, captures the Kronecker structure of the problem, and can be inverted in \(\mathcal{O}(n^2r + nr^2)\) time using precomputed Cholesky factorizations of the small matrices \(\mathbf{K}\) and \(\mathbf{Z}^\mathsf{T}\mathbf{Z} + \lambda \mathbf{I}_r\). The overall scheme completely avoids any computation of order \(N\).

---

**Detailed Solution**

---

### 1. Notation and setup

We are solving for the matrix \(\mathbf{W} \in \mathbb{R}^{n \times r}\) in the mode‑\(k\) subproblem  

\[
\bigl[ (\mathbf{Z}\otimes \mathbf{K})^\mathsf{T}\mathbf{S}\mathbf{S}^\mathsf{T}(\mathbf{Z}\otimes \mathbf{K}) + \lambda (\mathbf{I}_r \otimes \mathbf{K}) \bigr] \operatorname{vec}(\mathbf{W})
= (\mathbf{I}_r\otimes \mathbf{K})\operatorname{vec}(\mathbf{B}),
\tag{1}
\]

where  

* \(\mathbf{K} \in \mathbb{R}^{n \times n}\) is the symmetric positive semidefinite kernel matrix for mode \(k\),  
* \(\mathbf{Z} \in \mathbb{R}^{M \times r}\) is the Khatri–Rao product of the factor matrices of all modes except \(k\),  
* \(\mathbf{S} \in \mathbb{R}^{N \times q}\;(N = nM)\) selects the \(q\) observed entries from the vectorised mode‑\(k\) unfolding,  
* \(\mathbf{B} = \mathbf{T}\mathbf{Z}\) is the MTTKRP of the sparse tensor unfolding \(\mathbf{T}\) (missing entries set to zero) with \(\mathbf{Z}\),  
* \(\lambda > 0\) is a regularisation parameter, so the system matrix is symmetric positive definite.

Define  

\[
\mathbf{A} = \mathbf{J}^\mathsf{T}\mathbf{J} + \lambda (\mathbf{I}_r \otimes \mathbf{K}), \qquad
\mathbf{J} = \mathbf{S}^\mathsf{T}(\mathbf{Z}\otimes \mathbf{K}), \qquad
\mathbf{b} = (\mathbf{I}_r\otimes \mathbf{K})\operatorname{vec}(\mathbf{B}).
\]

We wish to solve \(\mathbf{A}\mathbf{x} = \mathbf{b}\) with \(\mathbf{x} = \operatorname{vec}(\mathbf{W})\) and \(\mathbf{A} \in \mathbb{R}^{nr \times nr}\).

---

### 2. Matrix‑vector products with \(\mathbf{A}\)

For an iterative Krylov solver we only need to compute \(\mathbf{A}\mathbf{p}\) for a given vector \(\mathbf{p} = \operatorname{vec}(\mathbf{P})\) with \(\mathbf{P} \in \mathbb{R}^{n \times r}\).  

#### 2.1. Action of \(\mathbf{J}\)

\[
\mathbf{J}\mathbf{p} = \mathbf{S}^\mathsf{T}(\mathbf{Z}\otimes \mathbf{K})\mathbf{p}
= \mathbf{S}^\mathsf{T}\operatorname{vec}\!\bigl( \mathbf{K}\mathbf{P}\mathbf{Z}^\mathsf{T} \bigr).
\]

*Step 1.* Compute \(\mathbf{Q} = \mathbf{K}\mathbf{P}\) (size \(n \times r\)). Cost: \(\mathcal{O}(n^2 r)\).  
*Step 2.* Let \(\mathbf{U} = \mathbf{Q}\mathbf{Z}^\mathsf{T}\) (\(n \times M\)). The matrix \(\mathbf{S}^\mathsf{T}\!\operatorname{vec}(\mathbf{U})\) extracts the \(q\) observed entries. For each observed tensor entry we are given its mode‑\(k\) index \(i\) and the multi‑index \(j\) of the remaining modes; the row \(\mathbf{Z}(j,:)\) can be formed on the fly (or precomputed in \(\mathcal{O}(qr(d-1))\) time) because \(\mathbf{Z}\) is a Khatri–Rao product of small factor matrices. The entry value is \(\mathbf{U}_{i,j} = \mathbf{Q}(i,:)\cdot \mathbf{Z}(j,:)^\mathsf{T}\). Computing all \(q\) entries costs \(\mathcal{O}(qr)\).  
Result: \(\mathbf{v} = \mathbf{J}\mathbf{p} \in \mathbb{R}^{q}\).

#### 2.2. Action of \(\mathbf{J}^\mathsf{T}\)

\[
\mathbf{J}^\mathsf{T}\mathbf{v}
= (\mathbf{Z}\otimes \mathbf{K})^\mathsf{T}\mathbf{S}\mathbf{v}.
\]

\(\mathbf{S}\mathbf{v}\) is a vector of length \(N\) that is zero except at the observed positions, where it equals the entries of \(\mathbf{v}\). Let \(\mathbf{Y} \in \mathbb{R}^{n \times M}\) be the matrix such that \(\operatorname{vec}(\mathbf{Y}) = \mathbf{S}\mathbf{v}\); then  

\[
(\mathbf{Z}\otimes \mathbf{K})^\mathsf{T}\operatorname{vec}(\mathbf{Y})
= \operatorname{vec}\!\bigl( \mathbf{K}\mathbf{Y}\mathbf{Z} \bigr).
\]

*Step 3.* Form \(\mathbf{C} = \mathbf{Y}\mathbf{Z}\) (size \(n \times r\)). Since \(\mathbf{Y}\) has at most \(q\) non‑zeros, we simply iterate over the observed entries: for each entry with index \((i,j)\) and value \(v\), add \(v\, \mathbf{Z}(j,:)\) to the \(i\)-th row of \(\mathbf{C}\). Cost: \(\mathcal{O}(qr)\).  
*Step 4.* Compute \(\mathbf{K}\mathbf{C}\). Cost: \(\mathcal{O}(n^2 r)\).  
Result: \(\mathbf{J}^\mathsf{T}\mathbf{v} = \operatorname{vec}(\mathbf{K}\mathbf{C})\).

#### 2.3. Full product

The regularisation term gives \(\lambda(\mathbf{I}_r\otimes \mathbf{K})\mathbf{p}
= \lambda \operatorname{vec}(\mathbf{K}\mathbf{P}) = \lambda \operatorname{vec}(\mathbf{Q})\). Hence  

\[
\mathbf{A}\mathbf{p} = \operatorname{vec}\!\bigl( \mathbf{K}\mathbf{C} + \lambda \mathbf{Q} \bigr).
\]

Total cost per matrix‑vector product: \(\mathcal{O}(n^2 r + qr)\), which is independent of the huge dimension \(M\) (and therefore of \(N = nM\)).

---

### 3. Preconditioner

A good preconditioner \(\mathbf{M} \approx \mathbf{A}\) must be symmetric positive definite and allow cheap solution of \(\mathbf{M}\mathbf{z} = \mathbf{r}\). We choose  

\[
\boxed{\;\mathbf{M} = (\mathbf{Z}^\mathsf{T}\mathbf{Z} + \lambda \mathbf{I}_r) \otimes \mathbf{K}\;}.
\]

*Justification.*  
If the tensor were fully observed (\(\mathbf{S}\mathbf{S}^\mathsf{T} = \mathbf{I}_N\)), the data term would become  

\[
(\mathbf{Z}\otimes \mathbf{K})^\mathsf{T}(\mathbf{Z}\otimes \mathbf{K})
= (\mathbf{Z}^\mathsf{T}\mathbf{Z}) \otimes \mathbf{K}^2,
\]

and the system matrix would be \((\mathbf{Z}^\mathsf{T}\mathbf{Z}) \otimes \mathbf{K}^2 + \lambda (\mathbf{I}_r \otimes \mathbf{K})\). By replacing \(\mathbf{K}^2\) with \(\mathbf{K}\) we obtain a single Kronecker product that still captures the essential row‑ and column‑space structures. In practice it clusters eigenvalues and greatly accelerates convergence of the conjugate gradient method.

*Precomputation.*  
– The Gram matrix \(\mathbf{G} = \mathbf{Z}^\mathsf{T}\mathbf{Z}\) is computed from the factor matrices of the other modes without ever forming \(\mathbf{Z}\) explicitly:

\[
\mathbf{Z}^\mathsf{T}\mathbf{Z}
= (\mathbf{A}_d^\mathsf{T}\mathbf{A}_d) \odot \cdots \odot
  (\mathbf{A}_{k+1}^\mathsf{T}\mathbf{A}_{k+1}) \odot
  (\mathbf{A}_{k-1}^\mathsf{T}\mathbf{A}_{k-1}) \odot \cdots \odot
  (\mathbf{A}_1^\mathsf{T}\mathbf{A}_1),
\]

where \(\odot\) is Hadamard (element‑wise) product. Each \(\mathbf{A}_i^\mathsf{T}\mathbf{A}_i\) is \(r \times r\) and costs \(\mathcal{O}(n_i r^2)\); the overall cost is \(\mathcal{O}\bigl((\sum_{i\neq k} n_i) r^2\bigr)\).  
– Form \(\mathbf{C} = \mathbf{G} + \lambda \mathbf{I}_r\) (size \(r \times r\)) and compute its Cholesky factorisation \(\mathbf{C} = \mathbf{L}_C\mathbf{L}_C^\mathsf{T}\) in \(\mathcal{O}(r^3)\).  
– Compute the Cholesky factorisation of \(\mathbf{K}\) (or, if \(\mathbf{K}\) is singular, use a small ridge; here we assume \(\mathbf{K}\) is positive definite after regularisation). Cost: \(\mathcal{O}(n^3)\).

*Applying \(\mathbf{M}^{-1}\).*  
Because \(\mathbf{M}\) is a Kronecker product,  

\[
\mathbf{M}^{-1} = \mathbf{C}^{-1} \otimes \mathbf{K}^{-1}.
\]

For a residual vector \(\mathbf{r} = \operatorname{vec}(\mathbf{R})\) we compute  

\[
\mathbf{M}^{-1}\mathbf{r} = \operatorname{vec}\!\bigl( \mathbf{K}^{-1}\,\mathbf{R}\,\mathbf{C}^{-1} \bigr).
\]

Concretely:  
1. Solve \(\mathbf{K}\mathbf{X} = \mathbf{R}\) for \(\mathbf{X}\) (using the precomputed Cholesky factor; cost \(\mathcal{O}(n^2 r)\) since we solve for \(r\) right‑hand sides).  
2. Multiply \(\mathbf{X}\,\mathbf{C}^{-1}\) (cost \(\mathcal{O}(n r^2)\)).  

Total cost per preconditioner application: \(\mathcal{O}(n^2 r + n r^2)\).

---

### 4. Preconditioned Conjugate Gradient (PCG) algorithm

The PCG method solves \(\mathbf{A}\mathbf{x} = \mathbf{b}\) by generating a sequence of search directions with the aid of the preconditioner \(\mathbf{M}\).

**Initialisation:**  
* \(\mathbf{x}_0 = \mathbf{0}\) (or a warm start).  
* \(\mathbf{r}_0 = \mathbf{b} - \mathbf{A}\mathbf{x}_0\), \(\mathbf{z}_0 = \mathbf{M}^{-1}\mathbf{r}_0\), \(\mathbf{p}_0 = \mathbf{z}_0\).  

**For \(k = 0,1,2,\dots\) until convergence:**
* \(\alpha_k = \dfrac{\mathbf{r}_k^\mathsf{T}\mathbf{z}_k}{\mathbf{p}_k^\mathsf{T}\mathbf{A}\mathbf{p}_k}\)  
* \(\mathbf{x}_{k+1} = \mathbf{x}_k + \alpha_k \mathbf{p}_k\)  
* \(\mathbf{r}_{k+1} = \mathbf{r}_k - \alpha_k \mathbf{A}\mathbf{p}_k\)  
* \(\mathbf{z}_{k+1} = \mathbf{M}^{-1}\mathbf{r}_{k+1}\)  
* \(\beta_{k+1} = \dfrac{\mathbf{r}_{k+1}^\mathsf{T}\mathbf{z}_{k+1}}{\mathbf{r}_k^\mathsf{T}\mathbf{z}_k}\)  
* \(\mathbf{p}_{k+1} = \mathbf{z}_{k+1} + \beta_{k+1} \mathbf{p}_k\)

The dominant costs per iteration are the matrix‑vector product \(\mathbf{A}\mathbf{p}_k\) (\(\mathcal{O}(n^2 r + qr)\)) and the preconditioner application \(\mathbf{M}^{-1}\mathbf{r}_{k+1}\) (\(\mathcal{O}(n^2 r + n r^2)\)). All steps are free of \(\mathcal{O}(N)\) work.

---

### 5. Complexity analysis

* Precomputation:  
  * \(\mathbf{K}\) Cholesky: \(\mathcal{O}(n^3)\)  
  * \(\mathbf{Z}^\mathsf{T}\mathbf{Z}\) and \(\mathbf{C}^{-1}\): \(\mathcal{O}\bigl((\sum_{i\neq k} n_i) r^2 + r^3\bigr)\)  
  * Right‑hand side \(\mathbf{b} = \operatorname{vec}(\mathbf{K}\mathbf{B})\): compute \(\mathbf{B}\) by sparse MTTKRP: \(\mathcal{O}(qr)\), then multiply by \(\mathbf{K}\): \(\mathcal{O}(n^2 r)\).  

* Per PCG iteration:  
  * \(\mathbf{A}\mathbf{p}\): \(\mathcal{O}(n^2 r + qr)\)  
  * Preconditioner solve: \(\mathcal{O}(n^2 r + n r^2)\)  
  * Vector operations (dot products, axpy): \(\mathcal{O}(nr)\)  

* Memory:  
  * Storing the observed indices and precomputed rows of \(\mathbf{Z}\): \(\mathcal{O}(qr)\) (dominant term involving \(q\)).  

All quantities depend only on \(n, r, q\) and the dimensions of the other factor matrices (which are themselves small compared to \(N\)). No step scales with \(N = nM\).

---

### 6. Why this works

The key ideas that keep the method scalable are:  

1. **Kronecker product identities** turn multiplications by \(\mathbf{Z}\otimes \mathbf{K}\) into operations with small matrices \(\mathbf{K}\) and \(\mathbf{Z}\).  
2. **Sparsity of the observations** restricts all work involving the tall dimension \(M\) to exactly the \(q\) observed entries.  
3. The **preconditioner** is a single Kronecker product whose factors are the small matrices \(\mathbf{K}\) and \(\mathbf{Z}^\mathsf{T}\mathbf{Z} + \lambda \mathbf{I}_r\). Its inverse is applied by a few dense linear algebra operations of sizes \(n\) and \(r\). This captures the dominant eigendirections of \(\mathbf{A}\) and ensures rapid convergence of CG without ever forming the full \(nr \times nr\) matrix.  

Thus, the full system is solved exactly (to numerical precision) at a cost that is linear in the number of observed entries \(q\) and polynomial only in the small dimensions \(n\) and \(r\), completely avoiding the intractable \(N\).