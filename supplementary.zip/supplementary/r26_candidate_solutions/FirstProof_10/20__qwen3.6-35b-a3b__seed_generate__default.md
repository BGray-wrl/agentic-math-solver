# Candidate solution: FirstProof_10 | qwen3.6-35b-a3b | seed_generate | reasoning=default

v4-flash judge score: 6.0

---

## Summary

**Verdict:** Solved
**Method sketch:** We apply a preconditioned conjugate gradient (PCG) solver to the mode-$k$ subproblem by replacing explicit matrix assembly with an observation-indexed matrix-vector product. This product loops over the $q$ observed indices, reuses cached kernel-vector products $KV$, and accumulates contributions to form $Lv$ in $O(n^2 r + qr)$ time. A diagonal preconditioner mimicking the local regularization strength is chosen to maintain positive definiteness and enable $O(nr)$ application, ensuring the per-iteration cost avoids any $O(N)$ operations.

## Detailed Solution

### 1. PCG Framework & System Properties
The mode-$k$ subproblem reduces to solving the symmetric linear system
\[
L \operatorname{vec}(W) = b,
\]
where $L = (Z \otimes K)^\top S S^\top (Z \otimes K) + \lambda (I_r \otimes K) \in \mathbb{R}^{nr \times nr}$ and $b = (I_r \otimes K)\operatorname{vec}(B) = \operatorname{vec}(KB)$. Since $K$ is positive semi-definite (psd) and $\lambda > 0$, $L$ is symmetric positive definite (SPD). This guarantees that the Conjugate Gradient (CG) method converges monotonically. PCG requires only two operations per iteration:
1. Matrix-vector product $Lv$ for any $v \in \mathbb{R}^{nr}$.
2. Preconditioner application $P^{-1}v$.

Explicit formation of $L$ costs $O(Nnr) = O(n^2 M r)$, which is prohibitive. We bypass this by exploiting the Kronecker structure and the sparsity of the observation mask $\Omega = SS^\top$.

### 2. Observation-Indexed Matrix-Vector Product
Let $v \in \mathbb{R}^{nr}$ be an arbitrary vector. Reshape $v$ into $V \in \mathbb{R}^{n \times r}$ such that $v = \operatorname{vec}(V)$. Using the identity $\operatorname{vec}(AXB^\top) = (B \otimes A)\operatorname{vec}(X)$, we have:
\[
(Z \otimes K)v = \operatorname{vec}(K V Z^\top) \in \mathbb{R}^{N}.
\]
The matrix-vector product $Lv$ splits into two terms:
\[
Lv = \lambda (I_r \otimes K)v + (Z \otimes K)^\top \Omega (Z \otimes K)v.
\]

**Step 2.1: Regularization Term**
$\lambda (I_r \otimes K)v = \lambda \operatorname{vec}(KV)$. Computing $U = KV$ costs $O(n^2 r)$.

**Step 2.2: Weighted Least-Squares Term**
Let $y = (Z \otimes K)v = \operatorname{vec}(K V Z^\top)$. We only need entries of $y$ at observed indices $\mathcal{O} = \{(i_j, m_j)\}_{j=1}^q$. By the mixed-product property:
\[
y_{(i_j, m_j)} = (K V Z^\top)_{i_j, m_j} = (KV)_{i_j, :} Z_{m_j, :}^\top = U_{i_j, :} Z_{m_j, :}^\top.
\]
We loop over $j=1,\dots,q$ to compute scalars $y_j = U_{i_j, :} Z_{m_j, :}^\top$. This takes $O(qr)$ time. Let $\tilde{y} \in \mathbb{R}^N$ be the vector with $\tilde{y}_{(i_j, m_j)} = y_j$ and zeros elsewhere.

Next, compute $(Z \otimes K)^\top \tilde{y} = \operatorname{vec}(K \tilde{T} Z)$, where $\tilde{T} \in \mathbb{R}^{n \times M}$ is the mode-$k$ unfolding of $\tilde{y}$. Forming $\tilde{T} Z$ exploits the sparsity of $\tilde{T}$:
\[
(\tilde{T} Z)_{i, :} = \sum_{m=1}^M \tilde{T}_{i, m} Z_{m, :}^\top = \sum_{j: i_j = i} y_j Z_{m_j, :}^\top.
\]
Accumulating these contributions over all $q$ observed entries costs $O(qr)$. Denote $R = \tilde{T} Z \in \mathbb{R}^{n \times r}$. Finally, compute $K R$, costing $O(n^2 r)$. Thus, the weighted term evaluates to $\operatorname{vec}(KR)$ in $O(n^2 r + qr)$.

**Algorithm for $Lv$:**
1. Reshape $v \to V$.
2. Compute $U = KV$ ($O(n^2 r)$).
3. Initialize $R = 0_{n \times r}$.
4. For $j=1$ to $q$: $y_j \leftarrow U_{i_j,:} Z_{m_j,:}^\top$; $R \leftarrow R + y_j \cdot \mathbf{e}_{i_j} Z_{m_j,:}^\top$ ($O(qr)$).
5. Compute $V_{\text{upd}} = K R$ ($O(n^2 r)$).
6. Return $Lv = \lambda \operatorname{vec}(KV) + \operatorname{vec}(V_{\text{upd}})$.

**Why this works:** The Kronecker structure allows us to swap the order of $K$ and $Z$ applications via $\operatorname{vec}$ identities. By looping over observed indices, we never form $N \times nr$ or $N \times N$ matrices. The kernel $K$ is applied only to $n \times r$ blocks, and $Z$ rows are accessed only at observed coordinates.

### 3. Preconditioner Design & Application
A natural preconditioner should approximate the local scaling of $L$ while being cheap to invert. We choose the **diagonal preconditioner**:
\[
P = \lambda I_{nr} + \operatorname{diag}(L).
\]
**Justification:**
- $P$ is diagonal and strictly positive definite, guaranteeing easy $O(nr)$ application.
- It captures the local regularization strength $\lambda K_{ii}$ and the empirical curvature from observed entries.
- For kernel-regularized problems, the diagonal often dominates the off-diagonal correlations induced by missing data, providing a robust and inexpensive approximation to $L$.

**Construction of $\operatorname{diag}(L)$:**
The diagonal entries correspond to pairs $(i, c)$ where $i \in \{1,\dots,n\}$ and $c \in \{1,\dots,r\}$:
\[
P_{(i,c),(i,c)} = \lambda K_{ii} + \sum_{j=1}^q K_{i_j, i}^2 Z_{m_j, c}^2.
\]
We compute this by initializing $D = \lambda \operatorname{vec}(\operatorname{diag}(K)) \mathbf{1}_r^\top \in \mathbb{R}^{nr}$, then looping over $j=1,\dots,q$ and adding $K_{i_j, i}^2 Z_{m_j, c}^2$ to $D_{(i,c)}$ for all $i,c$. This takes $O(qnr)$ time, performed once per outer ALS iteration. Alternatively, if $M$ is moderately sized, one may use the Kronecker preconditioner $P = (Z^\top Z + \lambda I_r) \otimes K$, applied via solves with $K$ and a small $r \times r$ matrix, but the diagonal choice strictly adheres to the $O(N)$-free constraint.

**Application of $P^{-1}$:**
Given $v \in \mathbb{R}^{nr}$, compute $P^{-1}v$ via element-wise division: $v_i \leftarrow v_i / P_{ii}$. Cost: $O(nr)$.

### 4. PCG Integration & Convergence
The PCG algorithm proceeds as follows for $t = 0, 1, \dots, T_{\max}$:
1. Reshape residual $r_t$ to $R_t$.
2. Compute $p_t = P^{-1} r_t$ ($O(nr)$).
3. Compute $\alpha_t = \frac{r_t^\top p_t}{p_t^\top L p_t}$. Evaluate $L p_t$ using the observation-indexed mat-vec ($O(n^2 r + qr)$).
4. Update $x_{t+1} = x_t + \alpha_t p_t$, $r_{t+1} = r_t - \alpha_t L p_t$.
5. Update search direction $p_{t+1} = P^{-1} r_{t+1} + \beta_t p_t$.

**Convergence:** CG converges in at most $nr$ steps. The number of iterations to reach tolerance $\epsilon$ scales as $O(\sqrt{\kappa(P^{-1}L)} \log(1/\epsilon))$, where $\kappa$ is the condition number. The diagonal preconditioner clusters eigenvalues near 1, significantly reducing $\kappa$ compared to the identity, accelerating convergence without adding per-iteration complexity.

### 5. Complexity Analysis
Let $n, r, q$ be fixed, with $n, r < q \ll N$ and $M = N/n$.

| Operation | Cost | Notes |
|-----------|------|-------|
| **Mat-Vec $Lv$** | $O(n^2 r + qr)$ | Dominated by $KV$, loop over $q$ entries, $KR$. |
| **Preconditioner Application** | $O(nr)$ | Element-wise division. |
| **Diagonal Construction** | $O(qnr)$ | One-time per ALS outer iteration. |
| **Kernel/Cholesky (optional)** | $O(n^3)$ | If using Kronecker $P$, computed once. |
| **Per-Iteration Total** | **$O(n^2 r + qr)$** | **Strictly avoids $O(N)$**. |
| **Outer Loop Setup** | $O(Mr^2 + n^3)$ | Form $Z$, compute kernel products. Done once per CP step. |

The method successfully replaces the $O(n^3 r^3)$ direct solve and $O(Nnr)$ assembly with an iterative scheme where each CG iteration costs $O(n^2 r + qr)$. Since $q \ll N$, the per-iteration cost is independent of the full tensor size $N$ and scales only with the observed data and kernel dimension. This matches the requested observation-indexed strategy and yields a rigorous, scalable solution for infinite-dimensional RKHS-regularized CP decomposition.