# Candidate solution: FirstProof_10 | qwen3.6-35b-a3b | generate | reasoning=default

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved
**Method sketch:** Reformulate the $nr \times nr$ system in matrix form to enable implicit matrix-vector products that exploit the sparse observation mask and Kronecker structure, costing $O((n^2+q)r)$ per iteration. Use $M = I_r \otimes K$ as a preconditioner to align with the RKHS geometry and regularizer, enabling efficient triangular solves via a precomputed Cholesky factor of $K$. The resulting preconditioned conjugate gradient (PCG) method avoids $O(N)$ operations entirely and converges rapidly under standard assumptions on the kernel and data mask.

## Detailed Solution

### 1. System Reformulation and Notation Clarification
Let $x = \operatorname{vec}(W) \in \mathbb{R}^{nr}$ and $b = (I_r \otimes K)\operatorname{vec}(B) = \operatorname{vec}(KB)$. The system is $Ax = b$ with
$$A = (Z \otimes K)^\top S S^\top (Z \otimes K) + \lambda (I_r \otimes K).$$
Note that $\Omega \coloneqq S S^\top \in \mathbb{R}^{N \times N}$ is a diagonal mask matrix with $\Omega_{ii} = 1$ if the $i$-th tensor entry is observed, and $0$ otherwise. We do not form $\Omega$ explicitly; instead, we store the $q$ observed indices as a list $\mathcal{I} = \{(i_m, j_m)\}_{m=1}^q$, where $i_m \in \{1,\dots,n\}$ and $j_m \in \{1,\dots,M\}$.

Using the identity $\operatorname{vec}(AXB) = (B^\top \otimes A)\operatorname{vec}(X)$, we can interpret the action of $A$ on a matrix $W$ directly:
- $(Z \otimes K)\operatorname{vec}(W) = \operatorname{vec}(K W Z^\top)$.
- $\Omega \operatorname{vec}(Y)$ zeroes out entries of $Y$ not in $\mathcal{I}$, yielding $\operatorname{vec}(\tilde{Y})$ where $\tilde{Y}_{ij} = (K W Z^\top)_{ij}$ if $(i,j) \in \mathcal{I}$, else $0$.
- $(Z^\top \otimes K)\operatorname{vec}(\tilde{Y}) = \operatorname{vec}(K \tilde{Y} Z)$.
- $\lambda (I_r \otimes K)\operatorname{vec}(W) = \lambda \operatorname{vec}(K W)$.

Thus, the matrix-vector product $y = Ax$ is equivalent to reshaping $x \to W$, computing
$$y = \operatorname{vec}\left( K \tilde{Y} Z + \lambda K W \right),$$
and then vectorizing the result. This structure allows us to compute $Ax$ without forming $A$ or using $O(N)$ storage/computation.

### 2. Efficient Implicit Matrix-Vector Product
Given a query vector $x = \operatorname{vec}(W)$, we compute $y = Ax$ in $O((n^2 + q)r)$ operations:

1. **Compute $X = K W$** ($n \times r$): Dense matrix multiplication. Cost: $O(n^2 r)$.
2. **Compute masked product $\tilde{Y}$** ($n \times M$): For each observed index $(i_m, j_m) \in \mathcal{I}$, compute the dot product:
   $$(\tilde{Y})_{i_m, j_m} = \sum_{p=1}^r X_{i_m, p} Z_{j_m, p}.$$
   Since $Z$ is $M \times r$, we only need access to row $j_m$ of $Z$. This costs $O(q r)$. All unobserved entries are implicitly zero.
3. **Compute $U = \tilde{Y} Z$** ($n \times r$): 
   $$U_{i,k} = \sum_{j=1}^M (\tilde{Y})_{i,j} Z_{j,k}.$$
   Because $\tilde{Y}$ is nonzero only at observed positions, the sum reduces to observed $j$'s for each row $i$. Total operations equal the number of observed entries times $r$, i.e., $O(q r)$.
4. **Compute $V = K U$** ($n \times r$): Dense matrix multiplication. Cost: $O(n^2 r)$.
5. **Assemble $y$**: $y = \operatorname{vec}(V + \lambda X)$. Cost: $O(n r)$.

**Total per iteration:** $O((n^2 + q)r)$. This strictly avoids $O(M)$ and $O(N)$ terms.

### 3. Preconditioner Choice and Application
The system matrix $A$ is symmetric positive definite (SPD) assuming $K \succ 0$ and $\lambda > 0$. A natural and highly effective preconditioner is
$$M = I_r \otimes K.$$
**Justification:**
- $M$ matches the regularization term in $A$, effectively normalizing the RKHS metric where $K$ defines the geometry.
- In RKHS-constrained optimization, the condition number of $A$ is dominated by the spectrum of $K$. Preconditioning with $K$ clusters the eigenvalues of $M^{-1}A$ near $1$ (for the regularizer) and bounds the data-driven part, drastically accelerating CG convergence.
- $M$ is SPD and its action is trivial to compute: $M^{-1} \operatorname{vec}(V) = \operatorname{vec}(K^{-1} V)$.

**Application of $M^{-1}$:**
Solve $K C = V$ for $C = K^{-1} V$. Since $K$ is fixed throughout the iterations, we compute its Cholesky decomposition $K = L L^\top$ once in $O(n^3)$. Applying $M^{-1}$ then requires forward/backward substitution on each of the $r$ columns of $V$, costing $O(n^2 r)$ total.

### 4. Preconditioned Conjugate Gradient Algorithm
We solve $Ax = b$ using PCG with preconditioner $M$. The algorithm proceeds as follows:

1. **Precomputation:**
   - Compute Cholesky factor $L$ of $K$: $O(n^3)$.
   - Compute RHS: $b = \operatorname{vec}(K B)$. Cost: $O(n^2 r)$.
   - Initialize $x_0 = 0$, residual $r_0 = b$.
   - Compute $p_0 = M^{-1} r_0$ by solving $K P_0 = R_0$ for matrix $R_0 = \operatorname{mat}(r_0)$. Cost: $O(n^2 r)$.
2. **Iteration $k = 0, 1, \dots$ until convergence:**
   - Compute $q_k = A p_k$ using the implicit mat-vec routine. Cost: $O((n^2+q)r)$.
   - Compute $\alpha_k = \frac{r_k^\top M^{-1} r_k}{p_k^\top q_k}$. Solve $K D_k = R_k$ for $M^{-1} r_k$, cost $O(n^2 r)$.
   - Update: $x_{k+1} = x_k + \alpha_k p_k$.
   - Update residual: $r_{k+1} = r_k - \alpha_k q_k$.
   - Compute $d_k = M^{-1} r_{k+1}$ (solve $K D_{k+1} = R_{k+1}$). Cost: $O(n^2 r)$.
   - Compute $\beta_k = \frac{d_k^\top r_{k+1}}{r_k^\top M^{-1} r_k}$.
   - Update direction: $p_{k+1} = d_k + \beta_k p_k$.
   - Check convergence on $\|r_{k+1}\|$ or residual norm.

### 5. Complexity Analysis
- **Explicit Formation & Direct Solve:** Forming $A$ explicitly requires $O(N r^2 + n^3 r^3)$ operations and storage (dominated by $Z \otimes K$ and $S S^T$). Solving the dense system costs $O(n^3 r^3)$. Both are infeasible for large $N$.
- **PCG Precomputation:** $O(n^3 + n^2 r)$ (Cholesky + RHS).
- **Per Iteration Cost:** $O((n^2 + q)r)$ for mat-vec, $O(n^2 r)$ for preconditioner application, $O(nr)$ for vector updates. Total: $O((n^2 + q)r)$.
- **Total Cost:** For $k$ iterations, $O(n^3 + k(n^2 + q)r)$.

Given the constraints $n, r < q \ll N$, the per-iteration cost scales linearly with $q$ and quadratically with $n$, completely avoiding dependence on $M$ or $N$. The method is thus optimal for large-scale unaligned tensor CP decomposition with RKHS constraints. Convergence is typically linear with a small constant ($k \ll nr$) due to the well-chosen preconditioner matching the problem's intrinsic geometry.