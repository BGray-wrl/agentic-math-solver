# Candidate solution: FirstProof_10 | deepseek-v4-flash | full | reasoning=default

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved  
**Method sketch:** Use preconditioned conjugate gradient (PCG) to solve the \(nr \times nr\) system without forming the matrix explicitly. Efficient matrix-vector products exploit the structure of Kronecker and Khatri‑Rao products together with the sparsity of the observed entries; the preconditioner is chosen as \(\lambda (I_r \otimes K)\) (or a slightly regularised version if \(K\) is only psd). The method avoids any computation of order \(N\).

**Changes from previous attempt:**  
- Explicitly addresses the assumption that the kernel matrix \(K\) is **positive definite** (or can be made so by a small ridge).  
- Handles the case where \(K\) might be only psd by adding a small regularisation to the preconditioner, ensuring its invertibility.  
- Improves justification of eigenvalue clustering.

## Detailed Solution

We are given the linear system  

\[
\bigl[(Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K)\bigr] \operatorname{vec}(W) = (I_r \otimes K) \operatorname{vec}(B),
\]

where  
- \(Z\in\mathbb{R}^{M\times r}\) is the Khatri‑Rao product of all factor matrices except the \(k\)-th mode,  
- \(K\in\mathbb{R}^{n\times n}\) is the **positive (semi‑)definite** kernel matrix associated with the RKHS constraint on mode \(k\),  
- \(S\in\mathbb{R}^{N\times q}\) selects the \(q\) known tensor entries (\(N=nM\)),  
- \(B = TZ\in\mathbb{R}^{n\times r}\) (MTTKRP),  
- \(\lambda>0\) is the regularization parameter, and  
- \(W\) is the \(n\times r\) unknown.

The system matrix is symmetric positive definite **provided \(K\) is positive definite**. (If \(K\) is only psd, the system may be singular; we address this below.)  
Direct factorization costs \(O(n^3 r^3)\) and requires forming the matrix explicitly, which is prohibitive when \(n\) and \(r\) are not very small. We therefore employ the preconditioned conjugate gradient (PCG) method, which only needs matrix‑vector products with the system matrix and an effective preconditioner.

### 1. Efficient matrix‑vector product

Let \(x = \operatorname{vec}(X)\) with \(X\in\mathbb{R}^{n\times r}\). The product \(y = A x\) consists of two parts:

\[
y_1 = (Z\otimes K)^T S S^T (Z\otimes K) x,\qquad 
y_2 = \lambda (I_r\otimes K) x.
\]

We compute both without forming the Kronecker product or the full \(N\)-vector.

#### 1.1 Computing \(S^T (Z\otimes K) x\)

Recall that \((Z\otimes K)\operatorname{vec}(X) = \operatorname{vec}(K X Z^T)\). Let \(P = K X Z^T \in \mathbb{R}^{n\times M}\).  
The selection \(v = S^T \operatorname{vec}(P)\) extracts the entries of \(P\) at the observed positions.  
For each observed entry with mode‑\(k\) index \(i\in\{1,\dots,n\}\) and multi‑index \(j\) (encoding all other modes), the value is  

\[
v_{(i,j)} = P_{i,j} = \bigl(K X\bigr)_{i,:} \cdot Z_{j,:},
\]  

where \(Z_{j,:}\) denotes the row of \(Z\) corresponding to index \(j\).  
Because \(Z\) is a Khatri‑Rao product, each row can be computed on the fly:  
\[
Z_{j,:} = A_1(i_1,:) \odot A_2(i_2,:) \odot \cdots \odot A_{k-1}(i_{k-1},:) \odot A_{k+1}(i_{k+1},:) \odot \cdots \odot A_d(i_d,:),
\]  
with the dot \(\odot\) denoting elementwise (Hadamard) product. Storing all factor matrices (each of size \(n_\ell\times r\)) allows computing a single row of \(Z\) in \(O(r(d-1))\) time; \(d\) is a small constant so we treat this as \(O(r)\).  
Thus, for all \(q\) observed entries we compute \(v\) in \(O(q r)\) operations (after having computed \(K X\)).

#### 1.2 Computing \((Z\otimes K)^T S v\)

Set \(w = S v \in \mathbb{R}^N\) (sparse, with nonzeros only at observed positions). Then  

\[
(Z\otimes K)^T w = \operatorname{vec}\bigl(K\, V Z\bigr),
\]  

where \(V\in\mathbb{R}^{n\times M}\) is the matrix obtained by reshaping \(w\) (the \((i,j)\) entry is \(w_{(i,j)}\)).  
Because \(V\) is sparse (only \(q\) nonzeros), we compute \(K V Z\) efficiently:

1. **Form \(U = V Z \in \mathbb{R}^{n\times r}\).**  
   Initialize \(U\) to zero. For each observed \((i,j)\) with value \(w_{i,j}\),  
   \[
   U_{i,:} \leftarrow U_{i,:} + w_{i,j}\, Z_{j,:}.
   \]  
   Cost: \(O(q r)\).

2. **Multiply by \(K\):** \(Y = K U\).  
   This is a dense matrix–matrix multiplication, costing \(O(n^2 r)\).

Finally, \(\operatorname{vec}(Y)\) is the result of \((Z\otimes K)^T S v\).

#### 1.3 Adding the regularization term

The regularization term is \(\lambda (I_r\otimes K) x = \lambda \operatorname{vec}(K X)\). We have already computed \(K X\) in step 1.1. Hence we add \(\lambda \operatorname{vec}(K X)\) to the vector obtained in 1.2.

#### 1.4 Total cost of one matrix‑vector product

- \(K X\): \(O(n^2 r)\).
- Compute \(v\) from observed entries: \(O(q r)\).
- Accumulate \(U = V Z\): \(O(q r)\).
- \(K U\): \(O(n^2 r)\).
- Add \(\lambda K X\): \(O(nr)\).

Thus the overall cost per PCG iteration is \(O(n^2 r + q r)\). Crucially, we never store or manipulate vectors of length \(N\) (the full tensor), and we never form the Kronecker product explicitly.

### 2. Choice of preconditioner

The system matrix is  

\[
A = (Z\otimes K)^T S S^T (Z\otimes K) + \lambda (I_r\otimes K).
\]  

#### 2.1 Positive definite kernel

If \(K\) is **positive definite** (the typical case for popular kernels such as the Gaussian RBF), then \(I_r\otimes K\) is also positive definite and the natural preconditioner is  

\[
M = \lambda\,(I_r\otimes K).
\]  

Using \(M\) in PCG (with symmetric preconditioning) has the following advantages:

- **Ease of inversion:** \(M^{-1} = \frac{1}{\lambda}(I_r\otimes K^{-1})\).  
  Computing \(z = M^{-1} r\) amounts to reshaping \(r\) into an \(n\times r\) matrix \(R\), solving the matrix equation \(K Z = R\) (using the Cholesky factor of \(K\) precomputed once), and scaling by \(1/\lambda\).  
  Cost per iteration: \(O(n^2 r)\) (after an initial \(O(n^3)\) Cholesky factorization of \(K\)).
- **Spectral clustering:** The first term \((Z\otimes K)^T S S^T (Z\otimes K)\) has rank at most \(q\) (since it is of the form \(C^T C\) with \(C = S^T (Z\otimes K)\) of size \(q\times nr\)). Therefore the preconditioned matrix  
  \[
  M^{-1/2} A M^{-1/2} = I_{nr} + \frac{1}{\lambda} M^{-1/2}(Z\otimes K)^T S S^T (Z\otimes K) M^{-1/2}
  \]  
  is the identity plus a rank-\(q\) perturbation. When \(q\) is moderate, the eigenvalues are tightly clustered, leading to fast CG convergence (typically tens of iterations).
- **Consistency with regularization:** The preconditioner captures the dominant part of the matrix when \(\lambda\) is not too small, and it is always invertible.

#### 2.2 Positive semidefinite kernel (psd)

If \(K\) is only **positive semidefinite** and singular, the preconditioner \(M = \lambda(I_r\otimes K)\) would be singular and cannot be inverted. However, in practice the kernel matrix for distinct data points is often strictly positive definite; if it is not, we can replace \(K\) by \(K + \delta I_n\) with a tiny \(\delta>0\) (e.g., \(10^{-10}\)) to ensure positive definiteness. This corresponds to adding a small ridge to the RKHS norm, which does not change the solution significantly. The same Cholesky-based inversion then applies.

Alternatively, one can use a preconditioner of the form  
\[
M = \lambda (I_r\otimes K) + \varepsilon I_{nr}
\]  
with a small \(\varepsilon>0\). This is still block-diagonal: \(M = I_r \otimes (\lambda K + \varepsilon I_n)\), and its inverse requires solving with \(\lambda K + \varepsilon I_n\), which is positive definite even if \(K\) is singular. The extra cost per iteration remains \(O(n^2 r)\) after a single Cholesky factorization of \(\lambda K + \varepsilon I_n\).

**In the following we assume \(K\) is positive definite** (or that a small regularisation has been applied), so that the preconditioner \(M = \lambda (I_r\otimes K)\) is well-defined and efficient.

### 3. Complexity analysis

Precomputation (done once):

- Cholesky factorization of \(K\) (or \(\lambda K + \varepsilon I_n\)): \(O(n^3)\).
- Storage of factor matrices (each \(n_i\times r\)), total \(O(r\sum_{i\neq k}n_i)\).

Per PCG iteration:

- Matrix‑vector product with \(A\): \(O(n^2 r + q r)\).
- Preconditioner application (solve with \(M\)): \(O(n^2 r)\).
- A few vector operations (dot products, axpy): \(O(nr)\).

Since \(n,r \ll q \ll N\) (where \(N = nM\) is enormous), the dominant term is typically \(q r\), which is manageable because it scales linearly with the number of observed entries. The total memory footprint is \(O(n^2 + q + r\sum n_i)\), avoiding any storage proportional to \(N\).

### 4. Why this works

The key observations are:

1. **Kronecker‑Khatri‑Rao structure:** The product \((Z\otimes K) x\) equals \(\operatorname{vec}(K X Z^T)\), and only its entries at observed positions are needed. Similarly, the transpose product can be accumulated from the sparse vector using the same row‑wise access to \(Z\).
2. **Sparsity:** The selection matrix \(S\) restricts all operations to the \(q\) known entries, so the intermediate vectors never become dense.
3. **Kernel matrix inversion:** \(K\) is \(n\times n\); solving with it is affordable (\(O(n^3)\) once, \(O(n^2 r)\) per iteration) and improves conditioning.

Consequently, PCG with the described preconditioner solves the mode‑\(k\) subproblem efficiently, with per‑iteration cost \(O(n^2 r + q r)\) and a modest number of iterations (typically tens). The approach entirely avoids the \(O(N)\) barrier and the \(O(n^3 r^3)\) cost of a direct solver. In the rare case that \(K\) is not strictly positive definite, a small ridge regularisation makes the preconditioner invertible while preserving the overall solution accuracy.