# Candidate solution: FirstProof_10 | gemma-4-31b-it | seed_generate | reasoning=max

v4-flash judge score: 6.0

---

## Summary

**Verdict:** Solved
**Method sketch:** We employ a Preconditioned Conjugate Gradient (PCG) solver to avoid forming the large $nr \times nr$ system matrix. The matrix-vector product is computed by leveraging the Kronecker identity $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$ and treating the selection matrix $SS^T$ as a masking operation on the entries of the matrix $KWZ^T$. To avoid $O(N)$ or $O(M)$ complexity, we precompute local Gram matrices $G^{(i)}$ for the observed entries, reducing the cost of the "mask-and-multiply" step to $O(qr^2 + nr^2)$. We use the regularization term $\lambda(I_r \otimes K)$ as the basis for the preconditioner $P = \frac{1}{\lambda}(I_r \otimes K^{-1})$, which clusters the eigenvalues of the system.

---

## Detailed Solution

### 1. Analysis of the System Matrix
The linear system is given by $A \operatorname{vec}(W) = b$, where:
$$ A = (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K), \quad b = (I_r \otimes K) \operatorname{vec}(B) $$
Since $K$ is a positive semi-definite (PSD) kernel matrix, it is symmetric ($K^T = K$). Using the property $(A \otimes B)^T = A^T \otimes B^T$, we rewrite the system matrix as:
$$ A = (Z^T \otimes K) S S^T (Z \otimes K) + \lambda (I_r \otimes K) $$
The size of $A$ is $nr \times nr$. A direct solve would cost $O(n^3 r^3)$, which is prohibitive. Instead, we use the PCG method, which requires only the ability to compute the matrix-vector product $Av$ and the application of a preconditioner $Pv$.

### 2. Efficient Computation of the Matrix-Vector Product
Let $v = \operatorname{vec}(W)$ for some $W \in \mathbb{R}^{n \times r}$. We compute $Av$ in two terms.

**Term 2: Regularization**
Using the identity $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$:
$$ \lambda (I_r \otimes K) \operatorname{vec}(W) = \operatorname{vec}(\lambda K W I_r^T) = \operatorname{vec}(\lambda K W) $$
This requires a matrix multiplication $KW$, costing $O(n^2 r)$.

**Term 1: Data Fidelity**
Let $y_1 = (Z \otimes K) \operatorname{vec}(W)$. By the identity:
$$ y_1 = \operatorname{vec}(K W Z^T) $$
Let $Y = K W Z^T \in \mathbb{R}^{n \times M}$. The operation $S S^T y_1$ corresponds to keeping only the observed entries of the tensor. Let $\Omega$ be the set of indices $(i, j)$ of the observed entries in the mode-$k$ unfolding $T$. We define the masked matrix $\tilde{Y} \in \mathbb{R}^{n \times M}$ such that:
$$ \tilde{Y}_{ij} = \begin{cases} Y_{ij} & \text{if } (i, j) \in \Omega \\ 0 & \text{otherwise} \end{cases} $$
Then $S S^T y_1 = \operatorname{vec}(\tilde{Y})$. Now we compute the final part of Term 1:
$$ (Z^T \otimes K) \operatorname{vec}(\tilde{Y}) = \operatorname{vec}(K \tilde{Y} Z) $$
To avoid $O(M)$ complexity, we analyze $\tilde{Y} Z \in \mathbb{R}^{n \times r}$. The $(i, l)$-th entry is:
$$ (\tilde{Y} Z)_{il} = \sum_{j=1}^M \tilde{Y}_{ij} Z_{jl} = \sum_{j \in \Omega_i} Y_{ij} Z_{jl} = \sum_{j \in \Omega_i} \left( \sum_{k=1}^r (KW)_{ik} Z_{jk} \right) Z_{jl} $$
where $\Omega_i = \{j \mid (i, j) \in \Omega\}$. Rearranging the summations:
$$ (\tilde{Y} Z)_{il} = \sum_{k=1}^r (KW)_{ik} \left( \sum_{j \in \Omega_i} Z_{jk} Z_{jl} \right) $$
Let $G^{(i)} \in \mathbb{R}^{r \times r}$ be the Gram matrix of the rows of $Z$ corresponding to observed entries for mode index $i$: $G^{(i)}_{kl} = \sum_{j \in \Omega_i} Z_{jk} Z_{jl}$.
Then the $i$-th row of $\tilde{Y} Z$ is computed as:
$$ (\tilde{Y} Z)_{i, :} = (KW)_{i, :} G^{(i)} $$
Finally, we multiply by $K$ on the left, costing $O(n^2 r)$.

### 3. Preconditioner Choice
The system is dominated by the regularization term $\lambda(I_r \otimes K)$ when $\lambda$ is significant or the observed data is sparse. We choose the preconditioner $P$ to be the inverse of the regularization term:
$$ P = [\lambda(I_r \otimes K)]^{-1} = \frac{1}{\lambda} (I_r \otimes K^{-1}) $$
Applying $P$ to a vector $v = \operatorname{vec}(R)$ is efficient:
$$ P \operatorname{vec}(R) = \operatorname{vec}\left( \frac{1}{\lambda} K^{-1} R \right) $$
This involves solving $r$ linear systems with $K$ (or precomputing $K^{-1}$), costing $O(n^3 + n^2 r)$.
The preconditioned operator is:
$$ PA = \frac{1}{\lambda} (I_r \otimes K^{-1}) [(Z^T \otimes K) S S^T (Z \otimes K) + \lambda (I_r \otimes K)] = \frac{1}{\lambda} (Z^T \otimes I_n) S S^T (Z \otimes K) + I_{nr} $$
The identity term $I_{nr}$ ensures that the eigenvalues are clustered around 1, which significantly accelerates the convergence of CG.

### 4. Complexity Analysis
Assume $n_{iter}$ is the number of iterations until convergence.

*   **Precomputation:**
    *   $K^{-1}$: $O(n^3)$
    *   Gram matrices $G^{(i)}$: For each $i$, we sum $Z_{jk} Z_{jl}$ over $j \in \Omega_i$. Total cost: $\sum_i |\Omega_i| r^2 = O(q r^2)$.
*   **Per Iteration:**
    *   $KW$: $O(n^2 r)$
    *   $\tilde{Y} Z$ (using $G^{(i)}$): $n$ rows $\times$ ($r \times r$ multiplication) $\to O(n r^2)$
    *   $K (\tilde{Y} Z)$: $O(n^2 r)$
    *   Preconditioner $P v$: $O(n^2 r)$
    *   Total per iteration: $O(n^2 r + n r^2)$.
*   **RHS computation:** $(I_r \otimes K) \operatorname{vec}(B) = \operatorname{vec}(KB)$, costing $O(n^2 r)$.

**Total Complexity:** $O(n^3 + q r^2 + n_{iter}(n^2 r + n r^2))$.
Since $n, r < q \ll N$, this approach completely avoids $O(N)$ and $O(M)$ operations, providing a massive speedup over standard solvers.