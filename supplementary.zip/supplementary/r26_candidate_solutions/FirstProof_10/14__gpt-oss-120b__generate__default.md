# Candidate solution: FirstProof_10 | gpt-oss-120b | generate | reasoning=default

v4-flash judge score: 6.0

---

**Answer –  a CG‑solver that never touches the full tensor**

---------------------------------------------------------------------

### 1.  The linear system that has to be solved

For the \(k\)‑th mode we write the CP factor as  
\[
A_{k}=KW ,\qquad K\in\mathbb R^{n\times n}\;(K\succeq0),\qquad  
W\in\mathbb R^{n\times r}\; \text{unknown}. 
\]

With the other factor matrices fixed we obtain the normal‑equations  

\[
\Big[(Z\!\otimes\! K)^{\!T}S S^{\!T}(Z\!\otimes\! K)
        +\lambda (I_{r}\!\otimes\!K)\Big]\operatorname{vec}(W)
   \;=\;(I_{r}\!\otimes\!K)\operatorname{vec}(B)                     \tag{1}
\]

where  

* \(Z\in\mathbb R^{M\times r},\ M=\prod_{i\neq k}n_{i}\)  is the Khatri–Rao product of the *other* factor matrices;  

* \(\operatorname{vec}(\cdot)\) stacks columns;  

* \(S\in\mathbb R^{N\times q}\;(N=nM)\) selects the \(q\) observed entries
  (the rest of the entries of the mode‑\(k\) unfolding are set to zero).

The unknown vector has length \(nr\) (typically a few thousand) while
\(N\) can be astronomically large.  Direct solution would require
\(O((nr)^{3})\) flops and the explicit formation of the \(nr\times nr\)
matrix – completely unaffordable.

---------------------------------------------------------------------

### 2.  Solving (1) with pre‑conditioned Conjugate Gradient (PCG)

The matrix in (1) is **symmetric positive definite** (SPD) because it is a
sum of two SPD terms.  Hence the linear system can be solved with the
Conjugate Gradient (CG) method.  CG only needs *matrix–vector products*
with the coefficient matrix; it never needs the matrix itself.  If we
provide a good preconditioner, the number of CG iterations will be
small (often < 30).

Consequently the whole algorithm consists of the following steps

| step | cost (dominant term) | what is done |
|------|----------------------|--------------|
| (a)  | \(O(n^{2}r)\) (once) | Cholesky factorisation of \(K\) (or an eigendecomposition) |
| (b)  | \(O(r^{3})\) (once)  | Form the \(r\times r\) matrix \(G:=Z^{T}Z=\bigodot_{i\neq k}A_{i}^{T}A_{i}\) and compute \(G_{\lambda}=G+\lambda I_{r}\) |
| (c)  | \(O(r^{3})\) (once)  | Compute the inverse (or a Cholesky factor) of \(G_{\lambda}\) |
| (d)  | per CG iteration  \(\;\;O(qr+n^{2}r)\) | One matrix–vector product with the left‑hand side of (1) and one pre‑conditioner solve |

All remaining operations are of lower order and therefore negligible.

---------------------------------------------------------------------

### 3.  Efficient matrix–vector product  

For a given vector \(x=\operatorname{vec}(W)\) we must compute  

\[
y:=\Big[(Z\!\otimes\!K)^{T}S S^{T}(Z\!\otimes\!K)+\lambda (I_{r}\!\otimes\!K)\Big]x .
\tag{2}
\]

The two terms are handled separately.

---------------------------------------------------------------------
#### 3.1   The regularisation term  

Because \((I_{r}\!\otimes\!K)\operatorname{vec}(W)=\operatorname{vec}(KW)\),

```
   reshape x → W (n×r)
   U = K·W                     # O(n² r)  (K already factorised)
   vec(λU)                     # λ·vec(U)
```

---------------------------------------------------------------------
#### 3.2   The data‑fitting term  

Let  

\[
M:= (Z\!\otimes\!K)x   \;\in\;\mathbb R^{nM}   \quad\Longleftrightarrow\quad
    M = \operatorname{mat}\big((Z\!\otimes\!K)x\big) \in\mathbb R^{n\times M}.
\]

A useful identity for a Kronecker product is  

\[
(Z\!\otimes\!K)\operatorname{vec}(W)=\operatorname{vec}(K\,W\,Z^{T}),
\tag{3}
\]

hence  

\[
M = K\,W\,Z^{T}\, .
\]

We never form the whole \(n\times M\) matrix \(M\); we only need the
\(q\) entries that are *selected* by \(S^{T}\).  The observed positions are
conveniently indexed by a pair \((i,j)\) with  

* \(i\in\{1,\dots ,n\}\) – the row (mode‑\(k\) index);  

* \(j\in\{1,\dots ,M\}\) – the column that corresponds to the
  multi‑index of all other modes.

Denote by  

* \(a_{i}^{\top}=K_{i,:}W\in\mathbb R^{1\times r}\) the \(i\)-th row of the
  intermediate matrix \(K\,W\);  

* \(z_{j}\in\mathbb R^{r}\) the \(j\)-th row of \(Z\) (i.e. the
  \(j\)-th Khatri‑Rao vector).

Then for an observed entry \((i,j)\)

\[
M_{ij}=a_{i}^{\top}z_{j}= \bigl(KW\bigr)_{i,:}\;z_{j}.
\tag{4}
\]

Hence the vector \(S^{T} M\) of length \(q\) is obtained by

```
   A = K·W                         # n×r    (O(n² r))
   for each observed pair (i,j)    # q of them
        s = A[i,:]·Z[j,:]          # scalar dot‑product, O(r)
        store s as entry (i,j) of SM
```

Overall cost: \(O(n^{2}r + q r)\).

---------------------------------------------------------------------
Now we have the *selected* values \(s_{ij}\).  
The next step is to apply \((Z\!\otimes\!K)^{T}\) to the sparse matrix
that contains exactly these values at the same positions.  Using (3) again,

\[
(Z\!\otimes\!K)^{T}\operatorname{vec}(M_{\text{obs}})=
\operatorname{vec}\!\bigl(K^{T}M_{\text{obs}}Z\bigr)=
\operatorname{vec}\!\bigl(K\,M_{\text{obs}}Z\bigr) .
\]

The sparse matrix \(M_{\text{obs}}\in\mathbb R^{n\times M}\) has at most
\(q\) non‑zero elements, each equal to \(s_{ij}\).  Multiplying it with \(Z\)
costs only \(O(q r)\):

```
   C = zeros(n,r)                 # accumulator
   for each observed pair (i,j) with value s_ij
        C[i,:] += s_ij * Z[j,:]   # O(r)
   # now C = M_obs * Z   (n×r)
   result = K·C                    # O(n² r)
```

Thus the whole product \((Z\!\otimes\!K)^{T}S S^{T}(Z\!\otimes\!K)x\) is
computed in  

\[
\boxed{O\bigl(n^{2}r+qr\bigr)} .
\]

No operation touches the full size \(N=nM\) and no intermediate
\(n\times M\) matrix is ever formed.

---------------------------------------------------------------------

### 4.  Choice of preconditioner  

A cheap and very effective preconditioner exploits the *Kronecker
structure* that would appear if we ignored the selection matrix:

\[
P \;:=\; \bigl(Z^{T}Z+\lambda I_{r}\bigr)\;\otimes\;K .
\tag{5}
\]

*Why this matrix?*  
If all entries of the tensor were observed (\(S=I\)), the coefficient
matrix in (1) would be exactly the Kronecker product \((Z^{T}Z\otimes K)
+\lambda(I_{r}\otimes K)=P\).  The missing entries only perturb this
matrix locally, therefore \(P\) is a *spectrally close* approximation.

#### 4.1  Computing the factors of \(P\)

* **\(K\).**   It is already assembled; a Cholesky factorisation
\(K=LL^{T}\) costs \(O(n^{3})\) once.

* **\(Z^{T}Z\).**   Because \(Z\) is a Khatri–Rao product,
\[
Z^{T}Z = \bigodot_{i\neq k} (A_{i}^{T}A_{i}) ,
\]
the Hadamard (element‑wise) product of the \(r\times r\) Gram matrices of
the *other* factor matrices.  Each Gram matrix requires \(O(n_{i}r^{2})\)
operations, and the element‑wise product costs \(O(dr^{2})\); all are
tiny compared with the size of the data.

* **\(G_{\lambda}=Z^{T}Z+\lambda I_{r}\).**   Invert it once (or compute a
Cholesky factor) – \(O(r^{3})\).

#### 4.2  Applying \(P^{-1}\)

For any vector \(v=\operatorname{vec}(X)\) with \(X\in\mathbb R^{n\times r}\),

\[
P^{-1}v
   = \operatorname{vec}\!\bigl(K^{-1}X\;G_{\lambda}^{-1}\bigr)
   = \operatorname{vec}\!\bigl(L^{-T}\bigl(L^{-1}X\bigl) G_{\lambda}^{-1}\bigr) .
\]

Thus a pre‑conditioner solve consists of

```
   X = reshape(v)               # n×r
   X = solve(L, X)              # L^{-1}X  (forward substitution)   O(n² r)
   X = X·G_lambda^{-1}         # multiply by (Z^TZ+λI)^{-1}    O(r³)
   X = solve(L^T, X)            # L^{-T}X (back substitution)    O(n² r)
   return vec(X)
```

Overall cost of a pre‑conditioner application:  

\[
O\bigl(n^{2}r+r^{3}\bigr) .
\]

Because \(n\) and \(r\) are tiny (e.g. \(n\le 10^{3}, r\le 50\)), this is
negligible compared with the dominant \(O(qr)\) cost of the matrix–vector
product.

---------------------------------------------------------------------

### 5.  Full PCG algorithm (pseudocode)

```
# -----------------------------------------------------------
# Pre‑processing (once)
# -----------------------------------------------------------
L = chol(K)                     # K = L L^T ,  O(n³)
G = I_r
for i = 1,…,d, i ≠ k
      G = G ∘ (A_i.T @ A_i)    # ∘ = element‑wise product, O(n_i r²)
G_lambda = G + λ·I_r
C = chol(G_lambda)             # G_lambda = C C^T , O(r³)

# -----------------------------------------------------------
# CG iteration
# -----------------------------------------------------------
# initialise
W = zeros(n,r)                 # or any warm start
x = vec(W)
b = vec(K @ B)                 # right‑hand side, O(n² r)

r = b - matvec(x)              # residual
z = precond_solve(r)           # apply P^{-1}
p = z
rho_old = r.T @ z

for it = 1,…,maxit
      q = matvec(p)                        # O(q r + n² r)
      alpha = rho_old / (p.T @ q)
      x = x + alpha * p
      r = r - alpha * q
      if norm(r) < tol: break
      z = precond_solve(r)                 # O(n² r + r³)
      rho_new = r.T @ z
      beta = rho_new / rho_old
      p = z + beta * p
      rho_old = rho_new
end
W = reshape(x, n, r)
```

*`matvec`* implements the product described in §3 (cost
\(O(qr+n^{2}r)\)).  
*`precond_solve`* implements (5) using the Cholesky factors (cost
\(O(n^{2}r+r^{3})\)).  

The total work after \(t\) CG iterations is  

\[
O\bigl(t\,(qr+n^{2}r)\bigr) \ +\  O(n^{3}+r^{3}+dr^{2}) .
\]

In practice \(t\) is very small (often \(t<30\)) because the
preconditioner clusters the eigenvalues, so the overall complexity is
essentially **linear in the number of observed entries**.

---------------------------------------------------------------------

### 6.  Complexity summary (dominant terms)

| operation                           | cost (asymptotic) |
|-------------------------------------|-------------------|
| factorise \(K\)                     | \(O(n^{3})\)      |
| compute \(Z^{T}Z\)                  | \(O(dr^{2})\)     |
| preconditioner set‑up (Cholesky)   | \(O(r^{3})\)      |
| one CG iteration (matrix‑vector)    | \(O(qr+n^{2}r)\)  |
| one CG iteration (preconditioner) | \(O(n^{2}r+r^{3})\) |
| total after \(t\) iterations        | \(O\!\bigl(t(qr+n^{2}r)\bigr) + O(n^{3}+r^{3})\) |

Since we assume \(n,r < q \ll N\) and \(t\) is modest,
the algorithm scales **linearly in the number of observed entries**
and never incurs an \(O(N)\) or \(O(N^{2})\) operation.

---------------------------------------------------------------------

### 7.  Why the method works

* The coefficient matrix in (1) is SPD, therefore CG converges to the
  exact solution in at most \(nr\) iterations; in practice far fewer
  iterations are needed.

* The matrix–vector product is performed *exactly* (no approximation) by
  exploiting the Kronecker identity (3) and the fact that only the
  observed entries survive the action of \(S\).  The cost is proportional
  to the number of observations \(q\).

* The preconditioner (5) is the exact matrix one would obtain if the
  tensor were fully observed.  Because the missing entries are sparse,
  this matrix is a very good approximation.  Its inverse is cheap to
  apply thanks to the Kronecker structure and the Cholesky
  factorisations of the two small factors \(K\) and \(G_{\lambda}\).

* All steps involve only matrices of size \(n\times n\), \(r\times r\),
  or the observed list of triples \((i,j,\text{value})\); no operation
  ever constructs a matrix of size \(N=nM\).

Consequently the PCG approach solves the infinite‑dimensional mode‑\(k\)
sub‑problem **exactly**, with a computational cost that is
*linear* in the number of observed tensor entries and avoids any
\(O(N)\) work.

---------------------------------------------------------------------

### 8.  Final recommendation

*Pre‑conditioned Conjugate Gradient* with the Kronecker‑product
preconditioner described above is the method of choice for the
mode‑\(k\) update when the factor lives in an RKHS and the data are
missing.  The dominant per‑iteration work is \(O(qr)\); the set‑up cost
is negligible compared with the size of the data, and the method scales
gracefully to tensors for which the full unfolding would be impossible
to store or manipulate