# Candidate solution: FirstProof_10 | gemma-4-31b-it | full | reasoning=max

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved
**Method sketch:** The problem is solved using the Preconditioned Conjugate Gradient (PCG) method. The core of the approach is to avoid the explicit construction of the $nr \times nr$ system matrix $A$ by utilizing the Kronecker product property $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$ and the sparsity of the selection matrix $S S^T$. The matrix-vector product $Av$ is computed through a sequence of smaller matrix multiplications, keeping the complexity $O(qr + n^2 r)$. A preconditioner based on the regularization term $P = \lambda (I_r \otimes K)$ is chosen for its invertibility and efficiency.

## Detailed Solution

### 1. Problem Setup
We are solving the linear system:
$$\left[ (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K) \right] \operatorname{vec}(W) = (I_r \otimes K) \operatorname{vec}(B)$$
where $W \in \mathbb{R}^{n \times r}$ is the unknown. Let $A$ be the system matrix and $b = (I_r \otimes K) \operatorname{vec}(B)$. The size of $A$ is $nr \times nr$. Direct inversion costs $O(n^3 r^3)$, which is prohibitive. Since $A$ is the sum of a positive semi-definite (PSD) matrix $(Z \otimes K)^T S S^T (Z \otimes K)$ and a positive definite matrix $\lambda (I_r \otimes K)$ (assuming $K$ is PD and $\lambda > 0$), $A$ is symmetric positive definite (SPD). This makes the **Preconditioned Conjugate Gradient (PCG)** method suitable.

### 2. Efficient Matrix-Vector Product
The bottleneck of PCG is the calculation of the matrix-vector product $Av$ for $v \in \mathbb{R}^{nr}$. Let $v = \operatorname{vec}(V)$ where $V \in \mathbb{R}^{n \times r}$. We decompose the product $Av$ into two parts: the data-driven term $Q$ and the regularization term $R$.

#### The Regularization Term $R$
Using the Kronecker property $(I_r \otimes K) \operatorname{vec}(V) = \operatorname{vec}(KV)$, we have:
$$R = \lambda (I_r \otimes K) \operatorname{vec}(V) = \operatorname{vec}(\lambda KV)$$
The complexity of computing $KV$ is $O(n^2 r)$.

#### The Data-Driven Term $Q$
Let $Q = (Z \otimes K)^T S S^T (Z \otimes K) \operatorname{vec}(V)$. We evaluate this step-by-step:
1. **Kronecker Product**: Let $u = (Z \otimes K) \operatorname{vec}(V)$. Using the identity $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$:
   $$u = \operatorname{vec}(K V Z^T)$$
   $K V Z^T$ is an $n \times M$ matrix. However, $S S^T$ is a diagonal masking matrix that only preserves entries corresponding to observed data.
2. **Sampling**: Let $\tilde{U} = S S^T \operatorname{vec}(KVZ^T)$ be re-interpreted as a matrix. $\tilde{U}$ is the matrix $KVZ^T$ where all entries corresponding to missing data in $\mathcal{T}$ are set to zero.
   Computing the $q$ observed entries of $KVZ^T$ requires $O(qr)$ operations (each observed entry is a dot product of a row of $KV$ and a row of $Z$).
3. **Adjoint Operation**: Using $(Z \otimes K)^T = Z^T \otimes K$:
   $$Q = (Z^T \otimes K) \operatorname{vec}(\tilde{U}) = \operatorname{vec}(K \tilde{U} Z)$$
   Computing $\tilde{U} Z$ requires $O(qr)$ operations because $\tilde{U}$ has only $q$ non-zero entries. The final multiplication $K(\tilde{U} Z)$ costs $O(n^2 r)$.

Thus, $Av = \operatorname{vec}(K \tilde{U} Z + \lambda KV)$.

### 3. Choice of Preconditioner
A highly effective and computationally cheap preconditioner for this system is the regularization term:
$$P = \lambda (I_r \otimes K)$$
This is a block-diagonal matrix. The inverse is $P^{-1} = \frac{1}{\lambda} (I_r \otimes K^{-1})$. Applying the preconditioner to a vector $v = \operatorname{vec}(V)$ yields:
$$P^{-1} \operatorname{vec}(V) = \operatorname{vec}\left( \frac{1}{\lambda} K^{-1} V \right)$$
**Computation:** We compute $K^{-1}$ once at the start of the subproblem in $O(n^3)$. Then, each application of $P^{-1}$ during the CG iterations costs $O(n^2 r)$.

### 4. Complexity Analysis
Let $k$ be the number of iterations until convergence.
- **Pre-computation:** $K^{-1}$ costs $O(n^3)$.
- **Matrix-Vector Product $Av$:**
    - Computing $KV$: $O(n^2 r)$
    - Computing $q$ entries of $KVZ^T$: $O(qr)$
    - Computing $\tilde{U}Z$: $O(qr)$
    - Computing $K(\tilde{U}Z)$: $O(n^2 r)$
    - Total per iteration: $O(qr + n^2 r)$.
- **Preconditioner application $P^{-1}v$:** $O(n^2 r)$.
- **Total Complexity:** $O(n^3 + k(qr + n^2 r))$.

Given the constraints $n, r < q \ll N$, we have completely avoided any operations of order $N$ (the total number of tensor entries), reducing the cost from $O(n^3 r^3)$ or $O(N)$ to $O(k(qr + n^2 r))$, which is efficient for large, sparse tensors.