# Candidate solution: FirstProof_10 | gpt-oss-120b | seed_full | reasoning=max

v4-flash judge score: 6.0

---

---

## Summary

**Verdict:** Solved  
**Method sketch:**  
1. Recognise that the mode‑\(k\) normal‑equations are a symmetric positive‑definite (SPD) linear system of size \((nr)\times(nr)\).  
2. Apply the **preconditioned conjugate‑gradient (PCG)** method, using as preconditioner the exact‑dimension Kronecker product  

   \[
   P\;=\;(Z^{\!T}Z+\lambda I_{r})\;\otimes\;K .
   \]

   The inverse of \(P\) is cheap because it factorises into the inverse of the tiny \(r\times r\) matrix
   \(Z^{\!T}Z+\lambda I_{r}\) and the (dense) but modest‑size kernel matrix \(K\).  
3. Perform every matrix–vector product \(v\mapsto Av\) and the right‑hand side \(b\) **without forming any \(N\)‑dimensional objects** by exploiting the Kronecker identity  

   \[
   (Z\!\otimes\!K)\operatorname{vec}(W)=\operatorname{vec}\!\bigl(KWZ^{\!T}\bigr) ,
   \]

   and by looping only over the \(q\) observed entries.  
4. Provide a detailed cost analysis: the dominant per‑iteration work is  

   \[
   O\bigl(q\,r \;+\; n^{2}r \;+\; n r^{2}\bigr),
   \]

   while all one‑time set‑up steps are at most \(O\!\bigl(q d r + n^{3}+r^{3}\bigr)\).  
   No step scales with the total number of tensor entries \(N=nM\).

All steps are **exact** – no low‑rank approximation of the kernel matrix is introduced – and the algorithm solves the original linear system (1) up to the CG tolerance.

---

## Detailed Solution

### 1.  The linear system and its properties

We must solve for the unknown matrix \(W\in\mathbb{R}^{n\times r}\) (vectorised as \(\operatorname{vec}(W)\))

\[
\boxed{
A\,\operatorname{vec}(W)=b,
\qquad
A:= (Z\!\otimes\!K)^{\!T}\,S S^{\!T}\,(Z\!\otimes\!K) \;+\;\lambda\,(I_{r}\!\otimes\!K),\;
b:=(I_{r}\!\otimes\!K)\operatorname{vec}(B) .
}
\tag{1}
\]

* \(K\in\mathbb{R}^{n\times n}\) is the PSD kernel matrix for mode \(k\).  
* \(Z\in\mathbb{R}^{M\times r}\) (\(M=\prod_{i\neq k}n_i\)) is the Khatri–Rao product of all other factor matrices.  
* \(S\in\mathbb{R}^{N\times q}\) (\(N=nM\)) selects the \(q\) observed entries of the mode‑\(k\) unfolding; \(S S^{\!T}\) is a diagonal matrix whose diagonal entries are 1 on the observed locations and 0 elsewhere.  
* \(B=T Z\) is the MTTKRP where \(T\) is the mode‑\(k\) unfolding with missing entries set to zero.

#### 1.1  Symmetry and positive‑definiteness

*The data term* \((Z\!\otimes\!K)^{\!T}S S^{\!T}(Z\!\otimes\!K)\) equals \(X^{\!T}X\) with \(X:=(S^{\!T}(Z\!\otimes\!K))\). Hence it is symmetric and PSD.

The regulariser \(\lambda(I_{r}\!\otimes\!K)\) is symmetric and PSD because \(K\succeq0\) and \(\lambda>0\).

For any non‑zero \(x\),

\[
x^{\!T}Ax
   =\|S^{\!T}(Z\!\otimes\!K)x\|_{2}^{2}
     +\lambda\,x^{\!T}(I_{r}\!\otimes\!K)x
   \;\ge\;\lambda\,x^{\!T}(I_{r}\!\otimes\!K)x \;>\;0,
\]

the last inequality holding because the only null‑directions of \(K\) are eliminated by the ridge \(\lambda>0\) (or by adding a tiny \(\delta I_n\) to \(K\) if necessary).  
Thus **\(A\) is SPD**, guaranteeing convergence of CG.

---

### 2.  Exact matrix–vector product \(v\mapsto Av\) without forming \(N\)

Let \(v=\operatorname{vec}(V)\) with \(V\in\mathbb{R}^{n\times r}\).  
We need \(w:=A v\).  

Using the Kronecker identity

\[
(Z\!\otimes\!K)\operatorname{vec}(V)=\operatorname{vec}\!\bigl(K V Z^{\!T}\bigr),
\tag{2}
\]

the data term becomes

\[
\begin{aligned}
&(Z\!\otimes\!K)^{\!T}S S^{\!T}(Z\!\otimes\!K)\operatorname{vec}(V)   \\
&\qquad
= (Z\!\otimes\!K)^{\!T}\,
   \operatorname{vec}\!\Bigl(
      \bigl(S S^{\!T}\bigr)\!\circ\!\bigl(KVZ^{\!T}\bigr)
   \Bigr) .
\end{aligned}
\tag{3}
\]

Here “\(\circ\)” denotes element‑wise (Hadamard) product and the mask
\(M:=S S^{\!T}\) has entries \(M_{i,\alpha}=1\) iff the entry
\((i,\alpha)\) of the mode‑\(k\) unfolding is observed.  

Applying the second Kronecker identity
\[
(Z\!\otimes\!K)^{\!T}\operatorname{vec}(Y)=\operatorname{vec}(K\,Y\,Z) .
\tag{4}
\]

Putting (3) and (4) together gives

\[
\boxed{
A\operatorname{vec}(V)
=
\operatorname{vec}\!\Bigl(
   K\,
   \Bigl(M \circ (K V Z^{\!T})\Bigr) Z
   \;+\;\lambda\,K V
\Bigr) .
}
\tag{5}
\]

Thus the product is obtained by the three steps shown in (5).  
All operations involve matrices of size at most \(n\times r\) or
\(n\times M\) but **only the entries flagged by the mask are ever accessed**.

#### 2.1  How to evaluate the masked term efficiently

Define  

* \(X := K V\)         (size \(n\times r\));
* The set of observed index pairs  

  \[
  \Omega = \{\, (i,\alpha) \mid \text{entry }(i,\alpha)\text{ of the unfolding is observed}\,\},
  \qquad |\Omega|=q .
  \]

* For each column index \(\alpha\in[1,M]\) the corresponding row of the Khatri–Rao product  

  \[
  z_{\alpha}^{\!\top}\in\mathbb{R}^{1\times r}
  \quad\text{(the \(\alpha\)-th row of }Z\text{)} .
  \]

The masked term \(\bigl(M\circ(K V Z^{\!T})\bigr)Z\) can be formed by iterating over the observed entries only:

```
G ← 0_{n×r}
for (i,α) ∈ Ω do
    s  ← X_{i,:}  ·  z_α        // dot‑product, O(r)
    G_{i,:} ← G_{i,:} + s·z_α   // rank‑1 update, O(r)
end
```

After the loop, the matrix `G` equals \(\bigl(M\circ(K V Z^{\!T})\bigr) Z\).  
The whole loop costs \(O(q\,r)\) flops.

*Remark on the storage of \(z_{\alpha}\).*

In the worst case \(|\mathcal A|:=\{\alpha\mid\exists i:(i,\alpha)\in\Omega\}=q\),
so naively storing all rows needs \(O(q r)\) memory.  
If \(q\) is extremely large this may be undesirable.  An alternative is to **re‑compute** a row \(z_{\alpha}\) on the fly: a Khatri–Rao row is the element‑wise product of the \(r\)-vectors taken from the factor matrices for all modes \(\neq k\).  Computing one row costs \(O(d\,r)\); the loop then costs \(O(q\,(r+d r))=O(q d r)\), still linear in \(q\).  Either strategy is acceptable; we assume the stored version because it yields the lower per‑iteration cost \(O(qr)\).

#### 2.2  Kernel multiplication

The two kernel multiplications in (5) are simply dense matrix–vector products with the \(n\times n\) matrix \(K\).  
Because \(n\) is modest (\(n \ll M\) and \(n < q\)), we can afford a **once‑only Cholesky factorisation**

\[
K = L L^{\!T},\qquad L\in\mathbb{R}^{n\times n},
\tag{6}
\]

costing \(O(n^{3})\) time and \(O(n^{2})\) memory.  Consequently:

* \(K X\) is obtained as \(L(L^{\!T} X)\) in \(O(n^{2}r)\) flops,
* \(K G\) similarly in \(O(n^{2}r)\) flops,
* solving with \(K\) (required by the preconditioner) is performed by two triangular solves, also \(O(n^{2}r)\).

If \(n\) is larger, an iterative method (e.g. a few steps of CG) could be used for each multiplication; the analysis below treats the dense case, which already satisfies the “no \(N\)‑scale” requirement.

#### 2.3  Full matrix‑vector product algorithm

Putting the pieces together, for a given \(V\) we compute \(w=A\operatorname{vec}(V)\) as follows:

1. **Kernel left‑multiply:** `X = K * V`       \(O(n^{2}r)\).
2. **Masked contraction:** compute `G` by the loop over \(\Omega\) described in §2.1 \(O(qr)\).
3. **Kernel right‑multiply:** `KG = K * G`    \(O(n^{2}r)\).
4. **Add regulariser:** `Y = KG + λ*X`.
5. **Vectorise:** `w = vec(Y)`.

No object of size \(nM (=N)\) is ever materialised.

---

### 3.  Right‑hand side \(\mathbf{b} = (I_{r}\!\otimes\!K)\operatorname{vec}(B)\)

Recall \(B = T Z\).  Because missing entries of \(T\) are set to zero, we can compute \(B\) directly from the observed data:

```
B ← 0_{n×r}
for (i,α) ∈ Ω do
    B_{i,:} ← B_{i,:} + T_{i,α} · z_α      // O(r)
end
```

The loop again costs \(O(qr)\).  Afterwards the RHS is simply

\[
b = \operatorname{vec}(K B),
\]

which is obtained by one dense kernel multiplication (`K*B`) costing \(O(n^{2}r)\).

---

### 4.  Preconditioner

#### 4.1  Choice and construction

A preconditioner that is cheap to apply *and* captures the dominant spectral part of \(A\) is the Kronecker product

\[
\boxed{
P \;:=\;(Z^{\!T}Z+\lambda I_{r})\;\otimes\;K .
}
\tag{7}
\]

*Derivation.*  
If the mask were the identity (\(S S^{\!T}=I_{N}\)), the data term would be
\[
(Z\!\otimes\!K)^{\!T}(Z\!\otimes\!K)= (Z^{\!T}Z)\;\otimes\;K^{2}.
\]
Replacing the factor \(K^{2}\) by \(K\) (i.e. taking a square‑root) yields a matrix
\((Z^{\!T}Z)\otimes K\); adding the regulariser \(\lambda(I_{r}\!\otimes\!K)\) gives (7).  
Thus \(P\) is the **exact‑dimension** analogue of the fully‑observed normal equations, but it *ignores* the sampling mask.  In many tensor‑completion settings the mask is “well‑distributed”, so the eigenvectors of \(A\) and \(P\) are almost the same and the eigenvalues differ by at most a factor equal to the condition number of \(K\).

#### 4.2  SPDness

* \(Z^{\!T}Z\) is an \(r\times r\) Gram matrix and therefore PSD.  Adding \(\lambda I_{r}\) makes it **strictly** PD.  
* \(K\) is PSD by construction; if it is singular we add a tiny ridge \(\delta I_{n}\) (absorbed into \(\lambda\)) so that it becomes PD.  

The Kronecker product of two PD matrices is PD, hence \(P\succ0\).

#### 4.3  Inverting the preconditioner

Because the inverse of a Kronecker product factorises,  

\[
P^{-1}= (Z^{\!T}Z+\lambda I_{r})^{-1}\;\otimes\;K^{-1}.
\tag{8}
\]

Application to a vector proceeds as follows.  For a given \(r\in\mathbb{R}^{nr}\) set \(R=\operatorname{unvec}(r)\in\mathbb{R}^{n\times r}\).  Then  

\[
P^{-1}r = \operatorname{vec}\!\bigl(K^{-1} R\,(Z^{\!T}Z+\lambda I_{r})^{-1}\bigr).
\tag{9}
\]

*Computational steps*

1. **Solve with \(K\).**  Using the Cholesky factor \(L\) from (6), compute  
   \(U = K^{-1}R\) by forward–backward substitution; cost \(O(n^{2}r)\).
2. **Right‑multiply by the tiny inverse.**  
   Pre‑compute \((Z^{\!T}Z+\lambda I_{r})^{-1}\) once (cost \(O(r^{3})\)).  
   Form \(U (Z^{\!T}Z+\lambda I_{r})^{-1}\); cost \(O(n r^{2})\).
3. **Vectorise** the result.

Hence a preconditioner‑solve costs \(O(n^{2}r + n r^{2})\), i.e. the same order as a single kernel multiplication.  No operation involves the huge dimension \(M\) or the full tensor size \(N\).

#### 4.4  Why ignoring the mask is acceptable

Define the *mask error matrix*

\[
E := (Z\!\otimes\!K)^{\!T}\bigl(I_{N} - S S^{\!T}\bigr)(Z\!\otimes\!K) .
\tag{10}
\]

Both \(A\) and \(P\) are SPD, and

\[
A = P - E .
\]

Since \(I_{N} - S S^{\!T}\) is a diagonal projection onto the set of *unobserved* entries, \(E\) is symmetric PSD and its spectral norm is bounded by the largest entry of the matrix \((Z\!\otimes\!K)\operatorname{vec}(V)\) squared.  A simple bound is

\[
\|E\|_{2} \le
\sigma_{\max}^{2}(K)\,\sigma_{\max}^{2}(Z)\,,
\tag{11}
\]

which is independent of the sampling pattern.  Consequently

\[
\kappa(P^{-1}A) \;\le\; 1 + \frac{\|E\|_{2}}{\lambda_{\min}(P)} .
\tag{12}
\]

When the regularisation \(\lambda\) is moderate and the kernel matrix is not excessively ill‑conditioned, the right‑hand side of (12) is a modest constant (empirically a few tens).  Thus \(P\) is a **good** preconditioner: CG converges in a number of iterations proportional to \(\sqrt{\kappa(P^{-1}A)}\), typically far fewer than the dimension \(nr\).

---

### 5.  Full PCG algorithm

Below is a self‑contained pseudocode that respects all the requirements.

```
INPUT:
   - Observed index list Ω = { (i,α) } , |Ω| = q
   - Observed values   Tobs[ (i,α) ]   (the non‑zero entries of T)
   - Factor matrices   {A_j}_{j ≠ k}, each of size n_j × r
   - Kernel matrix     K (n×n, PSD), plus its Cholesky L
   - Rank r, regulariser λ, tolerance tol

PRE‑COMPUTATION (once)

1.  Build ZᵀZ  (r×r) using the Hadamard product formula
      ZᵀZ = (A_1ᵀA_1) ∘ … ∘ (A_{k-1}ᵀA_{k-1})
             ∘ (A_{k+1}ᵀA_{k+1}) ∘ … ∘ (A_dᵀA_d) .
    Let G = ZᵀZ + λ I_r and compute its Cholesky factor C such that
      G = Cᵀ C .  Compute also G^{-1} = (C⁻¹)ᵀ C⁻¹.

2.  For each distinct column index α appearing in Ω,
    compute and store the Khatri‑Rao row   z_α ∈ ℝ^{1×r}.
    (Cost O(q d r), memory O(q r); optionally recompute on the fly.)

3.  Right‑hand side:
    B ← 0_{n×r}
    for (i,α) in Ω do
        B[i,:] ← B[i,:] + Tobs[i,α] * z_α   // O(r)
    end
    RHS  b ← vec( K * B )                // one kernel multiplication

INITIALISATION
    w₀ ← 0_{nr}          // current iterate (vectorised)
    r₀ ← b - A w₀        // residual
    z₀ ← P^{-1} r₀        // preconditioner solve (see §4.3)
    p₀ ← z₀

ITERATION (ℓ = 0,1,…)

1.  // matrix‑vector product qℓ = A pℓ
    reshape pℓ → P (n×r)
    X ← K * P                                   // O(n² r)
    // masked contraction
    G ← 0_{n×r}
    for (i,α) in Ω do
        s ← X[i,:] · z_α                         // dot product, O(r)
        G[i,:] ← G[i,:] + s * z_α               // O(r)
    end
    Y ← K * G                                   // O(n² r)
    qℓ ← vec( Y + λ * X )                       // O(n r)

2.  αℓ ← (rℓᵀ zℓ) / (pℓᵀ qℓ)

3.  w_{ℓ+1} ← wℓ + αℓ pℓ

4.  r_{ℓ+1} ← rℓ – αℓ qℓ
    if ‖r_{ℓ+1}‖₂ / ‖b‖₂ < tol  then STOP

5.  // preconditioner solve   z_{ℓ+1}=P^{-1} r_{ℓ+1}
    reshape r_{ℓ+1} → R (n×r)
    U ← solve K·U = R   (triangular solves with L)   // O(n² r)
    Ztemp ← U * G^{-1}                               // O(n r²)
    z_{ℓ+1} ← vec( Ztemp )

6.  βℓ ← (r_{ℓ+1}ᵀ z_{ℓ+1}) / (rℓᵀ zℓ)

7.  p_{ℓ+1} ← z_{ℓ+1} + βℓ pℓ
```

The loop uses only operations whose costs are listed in the table below; no step touches an \(N\)-dimensional structure.

---

### 6.  Complexity analysis

| Phase                               | Cost (dominant terms)                                 | Remarks |
|-------------------------------------|-------------------------------------------------------|---------|
| **One‑time pre‑processing**         | • Build \(Z^{\!T}Z\) : \(O\bigl(\sum_{j\neq k} n_j r^{2}\bigr)=O(d r^{2}\max n_j)\)  <br> • Pre‑compute Khatri‑Rao rows : \(O(q d r)\)  <br> • Cholesky of \(K\) : \(O(n^{3})\)  <br> • Factorisation of \(G=Z^{\!T}Z+\lambda I_r\) : \(O(r^{3})\)  | All are negligible compared with the per‑iteration work. |
| **Form RHS**                        | \(O(q r) + O(n^{2} r)\) (loop + one kernel multiplication) | No dependence on \(M\) or \(N\). |
| **Per CG iteration** – matrix‑vector product \(A p\) | \(O(q r)\) (masked loop)  +  \(O(n^{2} r)\) (two kernel multiplications) | Total \(O(q r + n^{2} r)\). |
| **Per CG iteration** – preconditioner solve | \(O(n^{2} r)\) (solve with \(K\))  +  \(O(n r^{2})\) (multiply with \(G^{-1}\)) | Same order as the matrix‑vector product. |
| **Vector updates / inner products** | \(O(n r)\) (negligible) | – |
| **Overall after \(L\) iterations** | \(O\bigl(L\,(q r + n^{2} r + n r^{2})\bigr) + O(n^{3}+r^{3}+q d r)\) | No term scales with the total number of tensor entries \(N=nM\). |

Because \(P\) captures the dominant part of \(A\), the condition number
\(\kappa(P^{-1}A)\) is modest; empirically CG reaches a relative residual of \(10^{-6}\) in **\(L\lesssim 10\)** iterations for typical tensor–completion problems.  

Consequently the total cost is essentially linear in the number of observed entries \(q\) and quadratic in the kernel dimension \(n\), which is unavoidable (one must at least multiply by \(K\)).  Importantly, the algorithm **never constructs or stores any object of size \(N\) or \(nM\)**, satisfying the requirement of the problem.

---

### 7.  Remarks on the design choices

* **Exactness.**  The algorithm works with the *exact* kernel matrix \(K\).  No Nyström or other low‑rank surrogate is employed, so the linear system (1) is solved (up to the CG tolerance) exactly.
* **Preconditioner quality.**  Dropping the mask from \(P\) is standard in tensor‑completion literature; the mask appears only as a low‑rank PSD correction \(E\) (10).  The bound (12) guarantees that the preconditioned system remains well‑conditioned as long as \(\lambda\) is not vanishingly small.
* **Memory for Khatri‑Rao rows.**  When \(q\) is extremely large, one may recompute each \(z_{\alpha}\) on the fly instead of storing them, increasing the per‑iteration cost from \(O(q r)\) to \(O(q d r)\) but keeping memory at \(O(r^{2})\).  The choice is a simple trade‑off.
* **Singular kernel.**  If the kernel matrix \(K\) is only positive semidefinite, we add a tiny ridge \(\delta I_{n}\) (absorbed into the regulariser) before the Cholesky factorisation.  This renders \(K\) strictly PD, preserving the SPD property of both \(A\) and \(P\).

---

## Conclusion

The mode‑\(k\) subproblem of a CP decomposition with an RKHS‑constrained factor can be solved efficiently by a **preconditioned conjugate‑gradient** method that:

1. Uses the exact SPD system (1);  
2. Employs the Kronecker‑product preconditioner \(P=(Z^{\!T}Z+\lambda I_{r})\otimes K\), whose inverse is cheap via a single Cholesky factorisation of \(K\) and an \(r\times r\) inversion;  
3. Computes matrix–vector products and the RHS solely from the observed entries, exploiting the identity \((Z\!\otimes\!K)\operatorname{vec}(W)=\operatorname{vec}(K W Z^{\!T})\) and a loop over the \(q\) observations;  
4. Has per‑iteration complexity \(O(q r + n^{2} r + n r^{2})\) and no dependence on the total number of tensor entries \(N\).

Thus the method yields an exact solution (up to the CG tolerance) far more efficiently than a naïve dense solver, while respecting all the constraints of the problem statement.