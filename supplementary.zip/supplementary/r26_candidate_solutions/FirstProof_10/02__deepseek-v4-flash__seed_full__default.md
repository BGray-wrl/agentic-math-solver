# Candidate solution: FirstProof_10 | deepseek-v4-flash | seed_full | reasoning=default

v4-flash judge score: 7.0

---

## Summary

**Verdict:** Solved  
**Method sketch:** We solve the \(nr \times nr\) linear system by the preconditioned conjugate gradient (PCG) method. Matrix‑vector products are computed without forming any large matrices by exploiting the Kronecker‑product structure and the sparsity of observed entries. The core computation reduces to \(O(qrd + n^2 r)\) per iteration. The preconditioner is a diagonal approximation that can be assembled in \(O(qrd + nr)\) time. The right‑hand side is computed from the observed entries in \(O(qrd + n^2 r)\). No operation of order \(N\) (the total number of tensor entries) is performed.

**Changes from previous attempt:**  
- Fixed the justification of the diagonal preconditioner (removed the incorrect scaling argument).  
- Precise complexity accounting: each matrix‑vector product includes two matrix multiplications with the kernel matrix, yielding \(O(qrd + 2n^2 r)\); constants are noted.  
- Added explicit description of how to compute the MTTKRP \(B = TZ\) from the observed entries without forming large matrices.

## Detailed Solution

### 1. Problem Restatement

We have a \(d\)-way tensor \(\mathcal{T}\in\mathbb{R}^{n_1\times\cdots\times n_d}\) with only \(q \ll N\) observed entries, where \(N = \prod_i n_i\). In the CP decomposition with rank \(r\), the mode‑\(k\) factor matrix is parameterized as \(A_k = K W\), where \(K \in \mathbb{R}^{n \times n}\) (\(n = n_k\)) is the positive definite RKHS kernel matrix and \(W \in \mathbb{R}^{n \times r}\) is unknown. Fixing all other factor matrices, the mode‑\(k\) subproblem leads to the linear system

\[
\left[(Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K)\right] \operatorname{vec}(W) = (I_r \otimes K) \operatorname{vec}(B),
\]

where  

* \(T \in \mathbb{R}^{n \times M}\) is the mode‑\(k\) unfolding of \(\mathcal{T}\) (missing entries set to zero), \(M = \prod_{i\neq k} n_i\);  
* \(S \in \mathbb{R}^{N \times q}\) selects the \(q\) observed entries from \(\operatorname{vec}(T)\);  
* \(Z = A_d \odot \cdots \odot A_{k+1} \odot A_{k-1} \odot \cdots \odot A_1 \in \mathbb{R}^{M \times r}\) is the Khatri‑Rao product of the other factor matrices;  
* \(B = T Z \in \mathbb{R}^{n \times r}\) is the MTTKRP;  
* \(\lambda > 0\) is a regularization parameter.

The system is size \(nr \times nr\). Direct solution costs \(O(n^3 r^3)\) and requires forming the matrix explicitly. We describe an efficient PCG solver.

### 2. Computing the Right‑Hand Side and the MTTKRP

The right‑hand side is \(b = \operatorname{vec}(K B)\). We first compute \(B = T Z\) from the observed entries.

*Let the observed entries be stored as triples \((\text{index in mode }k,\; \text{index of other modes},\; \text{value})\). For each observed entry \((i, j, t)\):  
  – Compute the row \(z = Z_{j,:}\) using the stored factor matrices of the other modes (elementwise product of the corresponding rows, cost \(O(rd)\)).  
  – For each \(s = 1,\dots,r\), add \(t \cdot z_s\) to \(B(i,s)\).*

After processing all \(q\) entries, \(B\) is obtained in \(O(qrd)\) time. No matrix of size \(M\times r\) is formed. Then compute \(K B\) at cost \(O(n^2 r)\). The right‑hand side \(b = \operatorname{vec}(K B)\) is ready.

### 3. Matrix‑Vector Product with the System Matrix

Let \(x = \operatorname{vec}(W) \in \mathbb{R}^{nr}\). Define  

\[
A = A_1 + A_2,\qquad 
A_1 = (Z \otimes K)^T S S^T (Z \otimes K),\qquad 
A_2 = \lambda (I_r \otimes K).
\]

#### 3.1 Computing \(A_2 x\)

\[
A_2 x = \lambda (I_r \otimes K) \operatorname{vec}(W) = \lambda \operatorname{vec}(K W).
\]

Compute \(K W\) once per iteration: \(O(n^2 r)\).

#### 3.2 Computing \(A_1 x\)

We use the identities  

\[
(Z \otimes K) \operatorname{vec}(W) = \operatorname{vec}(K W Z^T) \qquad (\text{size } n \times M),
\]
\[
(Z \otimes K)^T = Z^T \otimes K \quad (\text{since }K\text{ is symmetric}).
\]

Let \(D = S S^T\) be the \(N \times N\) diagonal matrix with ones on observed positions. Then  

\[
A_1 x = (Z \otimes K)^T D (Z \otimes K) \operatorname{vec}(W)
      = (Z^T \otimes K) \operatorname{vec}(V),
\]

where \(V\) is the \(n \times M\) matrix defined by  

\[
\operatorname{vec}(V) = D \operatorname{vec}(K W Z^T).
\]

Thus \(V\) has the same non‑zero entries as \(K W Z^T\) but only at observed locations; all other entries are zero. Then  

\[
(Z^T \otimes K) \operatorname{vec}(V) = \operatorname{vec}(K V Z).
\]

Therefore \(A_1 x = \operatorname{vec}(K V Z)\).

**Algorithm to compute \(y_1 = A_1 x\):**

1. Compute \(U = K W\) (cost \(O(n^2 r)\)).  
2. Initialize \(Y \in \mathbb{R}^{n \times r}\) to zero.  
3. For each observed entry \((i, j)\):  
   * Compute \(z = Z_{j,:}\) (elementwise product of rows of the fixed factor matrices, \(O(rd)\)).  
   * Compute \(v = \sum_{s=1}^r U_{i,s} \, z_s\) (the \((i,j)\) entry of \(K W Z^T\)). Cost \(O(r)\).  
   * For each \(s=1,\dots,r\), add \(v \cdot z_s\) to \(Y(i,s)\). Cost \(O(r)\).  
4. After the loop, \(Y = V Z\) (accumulated).  
5. Compute \(K Y\) (cost \(O(n^2 r)\)). Then \(y_1 = \operatorname{vec}(K Y)\).

Total cost per matrix‑vector product: \(O(q r d + 2 n^2 r)\).

### 4. Diagonal Preconditioner

Let \((i,s)\) index the row of \(W\) (mode‑\(k\) index \(i\), column \(s\)). The exact diagonal entry of \(A\) is  

\[
A_{(i,s),(i,s)} = \sum_{(a,b)\text{ obs}} K_{a,i}^2 \, Z_{b,s}^2 \;+\; \lambda K_{i,i}.
\]

Computing this exactly would require iterating over all observations for each \((i,s)\), costing \(O(q n r)\). Instead, we use the cheap approximation  

\[
d_{i,s} = K_{i,i} \Bigl( \sum_{j: (i,j)\text{ obs}} Z_{j,s}^2 \Bigr) \;+\; \lambda K_{i,i}.
\]

This approximation replaces \(K_{a,i}^2\) with \(K_{i,i}\) and only sums over observations where the mode‑\(k\) index equals \(i\). It is motivated by the fact that the kernel \(K\) is smooth and its diagonal entries often dominate; the resulting preconditioner is positive definite and often improves the conditioning of the system significantly. No claim of exactness or uniform scaling is needed – it is a practical, cheap heuristic.

**Computation of \(d_{i,s}\):**

* Initialize \(D \in \mathbb{R}^{n \times r}\) to zero.  
* For each observed entry \((i, j)\):  
  – Compute \(z = Z_{j,:}\) (cost \(O(rd)\)).  
  – For each \(s\), add \(z_s^2\) to \(D(i,s)\).  
* After the loop, for each \(i\):  
  – Scale row \(i\): \(D(i,:) \leftarrow K_{i,i} \cdot D(i,:)\).  
  – Add \(\lambda K_{i,i}\) to every entry of row \(i\).

Total cost: \(O(q r d + n r)\).

### 5. PCG Algorithm

We solve \(A \operatorname{vec}(W) = b\) with preconditioner \(M\) given by the diagonal matrix with entries \(d_{i,s}\).

**Precomputation:**  
* Compute \(B\) and \(K B\) as in Section 2.  
* Compute the preconditioner \(d_{i,s}\) as in Section 4.

**Initialization:**  
* Set \(x_0 = \operatorname{vec}(W_0)\) (e.g., zero).  
* Compute \(r_0 = b - A x_0\) (one matrix‑vector product).  
* Solve \(M z_0 = r_0\) (component‑wise division by \(d_{i,s}\)).  
* Set \(p_0 = z_0\).

**Main iteration** (until convergence):  

1. \(\alpha_k = \dfrac{r_k^T z_k}{p_k^T A p_k}\)  
2. \(x_{k+1} = x_k + \alpha_k p_k\)  
3. \(r_{k+1} = r_k - \alpha_k A p_k\)  
4. Solve \(M z_{k+1} = r_{k+1}\)  
5. \(\beta_k = \dfrac{r_{k+1}^T z_{k+1}}{r_k^T z_k}\)  
6. \(p_{k+1} = z_{k+1} + \beta_k p_k\)

Each iteration requires:  
* One matrix‑vector product: \(O(qrd + 2n^2 r)\).  
* Vector operations of length \(nr\): \(O(nr)\).  
* Preconditioner application: \(O(nr)\).

### 6. Complexity and Storage

**Time:**  

* Precomputation: \(O(qrd + n^2 r)\) for \(B\) and \(KB\); \(O(qrd + nr)\) for the preconditioner.  
* Per PCG iteration: \(O(qrd + 2n^2 r)\).  

Because \(q \ll N\) and typically \(n, r, d\) are orders of magnitude smaller than \(N\), the dominant term is linear in the number of observed entries.

**Storage:**  

* Kernel matrix \(K\): \(O(n^2)\).  
* Factor matrices of other modes: \(O(r \sum_{i\neq k} n_i)\).  
* List of observed entries (indices and values): \(O(q)\).  
* Current iterates \(W, Y\) and PCG vectors: \(O(nr)\).  

No matrix of size \(nr \times nr\) or \(N \times nr\) is ever formed.

### 7. Why This Works

* **Matrix‑free products:** The structured form of \((Z \otimes K)\) together with the selection matrix \(S\) allows computing \(A x\) by only working with the \(q\) observed entries and small matrix multiplications involving the kernel matrix. This avoids any explosion of dimension to \(N\).  
* **Preconditioning:** The diagonal preconditioner approximates the system matrix and is cheap to compute and apply. It improves the conditioning of the system, reducing the number of CG iterations needed.  
* **Scalability:** The dominating cost per iteration, \(O(q r d)\), scales linearly with the number of observations, which is typically much smaller than \(N\).  

The PCG solver therefore provides an efficient way to solve the mode‑\(k\) subproblem in the alternating optimization of a CP decomposition with missing data and RKHS constraints.