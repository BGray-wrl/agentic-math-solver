# Candidate solution: FirstProof_10 | gemma-4-31b-it | seed_full | reasoning=default

v4-flash judge score: 6.0

---

## Summary

**Verdict:** Solved
**Method sketch:** We reformulate the $nr \times nr$ system by treating $\operatorname{vec}(W)$ as a matrix $W \in \mathbb{R}^{n \times r}$ and utilizing the property $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$. This allows the system to be viewed as a matrix equation where the operator $(Z \otimes K)^T S S^T (Z \otimes K)$ is computed as $\operatorname{vec}(K Z^T S S^T Z K W)$, which simplifies to processing only the $q$ observed entries, reducing the complexity of matrix-vector products to $O(qr^2)$ per iteration.

---

## Detailed Solution

### 1. Problem Formulation and Matrix-Vector Product Analysis

We are tasked with solving the linear system:
$$\left[ (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K) \right] \operatorname{vec}(W) = (I_r \otimes K) \operatorname{vec}(B)$$
where $W \in \mathbb{R}^{n \times r}$, $Z \in \mathbb{R}^{M \times r}$, $K \in \mathbb{R}^{n \times n}$, $S \in \mathbb{R}^{N \times q}$, and $B \in \mathbb{R}^{n \times r}$.

Let $\mathcal{A} = (Z \otimes K)^T S S^T (Z \otimes K) + \lambda (I_r \otimes K)$. To use the Preconditioned Conjugate Gradient (PCG) method, we must be able to compute the product $\mathcal{A} \mathbf{v}$ for any $\mathbf{v} \in \mathbb{R}^{nr}$ without explicitly forming $\mathcal{A}$.

Let $\mathbf{v} = \operatorname{vec}(V)$ for some $V \in \mathbb{R}^{n \times r}$. We use the Kronecker identity $(A \otimes B) \operatorname{vec}(X) = \operatorname{vec}(B X A^T)$.

#### Step A: The Data-Term Product
Consider the term $\mathbf{y}_1 = (Z \otimes K)^T S S^T (Z \otimes K) \operatorname{vec}(V)$.
First, let $\mathbf{u} = (Z \otimes K) \operatorname{vec}(V)$. Applying the identity:
$$\mathbf{u} = \operatorname{vec}(K V Z^T)$$
Note that $K V Z^T \in \mathbb{R}^{n \times M}$. The selection matrix $S$ extracts the $q$ observed entries. Thus, $S^T \mathbf{u} \in \mathbb{R}^q$ is a vector containing only the observed elements of the unfolded tensor approximation. Let $\mathbf{s} = S^T \mathbf{u}$.

Next, we compute $(Z \otimes K)^T S \mathbf{s}$. Note that $(Z \otimes K)^T = Z^T \otimes K^T = Z^T \otimes K$ (since $K$ is a symmetric kernel matrix).
$$(Z^T \otimes K) S \mathbf{s} = \sum_{i=1}^q (Z^T \otimes K) \mathbf{e}_i s_i$$
where $\mathbf{e}_i$ is the $i$-th column of $S$. Each $\mathbf{e}_i$ corresponds to a specific entry $(j, m)$ in the $n \times M$ unfolding. Specifically, if $S^T \operatorname{vec}(X)$ picks the entry $X_{jm}$, then $(Z^T \otimes K) \mathbf{e}_i$ is a vector that, when reshaped, is a matrix with a single non-zero block.
More simply, $S S^T \operatorname{vec}(K V Z^T)$ is the vectorization of the matrix $K V Z^T$ where all unobserved entries are set to zero. Let $P_{\Omega}(X)$ denote the projection of matrix $X$ onto the set of observed indices $\Omega$.
Then $S S^T (Z \otimes K) \operatorname{vec}(V) = \operatorname{vec}(P_{\Omega}(K V Z^T))$.

Now apply $(Z^T \otimes K)$:
$$\mathbf{y}_1 = (Z^T \otimes K) \operatorname{vec}(P_{\Omega}(K V Z^T)) = \operatorname{vec}(K P_{\Omega}(K V Z^T) Z)$$
The matrix product $K P_{\Omega}(K V Z^T) Z$ is computed by:
1. Computing $X = K V Z^T$ only at observed indices $\Omega$. For each $(j, m) \in \Omega$, $X_{jm} = \sum_{l=1}^n \sum_{r'=1}^r K_{jl} V_{lr'} Z_{mr'}$.
2. Forming the sparse matrix $P_{\Omega}(X)$.
3. Computing $K P_{\Omega}(X) Z$.

#### Step B: The Regularization Term
The second term is $\mathbf{y}_2 = \lambda (I_r \otimes K) \operatorname{vec}(V) = \lambda \operatorname{vec}(K V I_r^T) = \lambda \operatorname{vec}(KV)$.

Thus, the full operator is:
$$\mathcal{A} \operatorname{vec}(V) = \operatorname{vec}(K P_{\Omega}(K V Z^T) Z + \lambda KV)$$

### 2. Complexity Analysis
Let $q$ be the number of observed entries.
1. **Computing $P_{\Omega}(K V Z^T)$**: For each of the $q$ entries, we perform a dot product of length $r$ between $(KV)_{j, \cdot}$ and $Z_{m, \cdot}$. Since $KV$ takes $O(n^2 r)$, this step takes $O(n^2 r + qr)$.
2. **Computing $K P_{\Omega}(X) Z$**: $P_{\Omega}(X) Z$ takes $O(qr)$ because $P_{\Omega}(X)$ has only $q$ non-zeros. Then multiplying by $K$ takes $O(n^2 r)$.
3. **Regularization**: $KV$ takes $O(n^2 r)$.

Total complexity per iteration: $O(n^2 r + qr)$. Given $n, r < q$, the dominant term is $O(qr)$. This is significantly better than $O(n^3 r^3)$.

### 3. Preconditioner Choice
The system is dominated by the kernel matrix $K$ and the structure of $Z$. A common and effective choice for such systems is the **diagonal preconditioner** or a **block-diagonal preconditioner**.
However, since $K$ is the primary operator appearing on both sides, we can use $\mathcal{P} = (I_r \otimes K)^{-1}$ if $K$ is easily invertible (e.g., by adding a small ridge $\epsilon I$). 
Applying $\mathcal{P}^{-1}$ involves computing $\operatorname{vec}(K^{-1} V)$, which costs $O(n^2 r)$ after an initial $O(n^3)$ Cholesky factorization of $K$. This effectively scales the system to be closer to the identity, accelerating convergence.

### 4. Conclusion
By utilizing the Kronecker-Structure property, we avoid forming the $nr \times nr$ matrix. We transform the matrix-vector product into a sequence of matrix multiplications involving the kernel $K$, the factor $Z$, and the sparse observation mask $\Omega$. The complexity per PCG iteration is reduced to $O(qr)$, making the infinite-dimensional mode subproblem computationally tractable.